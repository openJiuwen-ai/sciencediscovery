from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator, Mapping
from typing import Any

from inquirycraft.llm import (
    CompletionRequest,
    CompletionResult,
    IncompleteStreamError,
    StreamChunk,
    UnusableResponseError,
    Usage,
)
from inquirycraft.llm.base import GuardStreamChunk, StreamHandle
from inquirycraft.llm.stream_types import ChannelStreamChunk
from inquirycraft.memory import Message, coerce_message, coerce_tool_call
from inquirycraft.tools import BaseTool, ToolContext, ToolResult


def adapt_message(value: Any) -> Message:
    """Convert a structural Message or OpenAI-style mapping to the public model."""
    return coerce_message(value)


class AskLLMAdapter:
    """Expose an existing ask()/ask_tool()-compatible client as ``LLMClient``.

    This adapter lets hosts adopt the runtime contract while retaining an existing
    provider implementation, retry policy, and request parameters.
    """

    def __init__(self, backend: Any) -> None:
        self.backend = backend

    async def _with_usage(self, operation):
        try:
            return await operation
        except (UnusableResponseError, IncompleteStreamError) as error:
            if isinstance(error, UnusableResponseError):
                error.usage = self._usage(self.backend)
            error.pool_index = getattr(self.backend, "_last_call_pool_index", None)
            raise

    @staticmethod
    def _usage(backend: Any) -> Usage:
        return Usage(
            input_tokens=int(getattr(backend, "_last_call_input_tokens", 0) or 0),
            output_tokens=int(getattr(backend, "_last_call_output_tokens", 0) or 0),
            cached_input_tokens=int(getattr(backend, "_last_call_input_cached_tokens", 0) or 0),
        )

    async def complete(self, request: CompletionRequest) -> CompletionResult:
        messages = self._messages(request)
        if request.tools:
            response = await self._with_usage(
                self.backend.ask_tool(
                    messages=messages,
                    system_msgs=request.metadata.get("system_msgs"),
                    timeout=int(request.timeout or 300),
                    tools=[dict(tool) for tool in request.tools],
                    tool_choice=request.tool_choice,
                    temperature=request.temperature,
                    parallel_tool_calls=request.metadata.get("parallel_tool_calls"),
                )
            )
            raw_calls = getattr(response, "tool_calls", None) or ()
            tool_calls = tuple(
                coerce_tool_call(call).model_dump(exclude_none=True) for call in raw_calls
            )
            return CompletionResult(
                content=str(getattr(response, "content", "") or ""),
                reasoning_content=str(getattr(response, "reasoning_content", "") or ""),
                tool_calls=tool_calls,
                finish_reason=str(getattr(self.backend, "_last_finish_reason", "unknown")),
                usage=self._usage(self.backend),
                raw=response,
                pool_index=getattr(self.backend, "_last_call_pool_index", None),
            )

        content = await self._with_usage(
            self.backend.ask(
                messages=messages,
                system_msgs=request.metadata.get("system_msgs"),
                stream=False,
                temperature=request.temperature,
                timeout=request.timeout,
            )
        )
        return CompletionResult(
            content=str(content or ""),
            finish_reason=str(getattr(self.backend, "_last_finish_reason", "unknown")),
            usage=self._usage(self.backend),
            raw=content,
            pool_index=getattr(self.backend, "_last_call_pool_index", None),
        )

    async def stream(self, request: CompletionRequest) -> AsyncIterator[StreamChunk]:
        force_tool_stream = bool(request.metadata.get("force_tool_stream"))
        if (not request.tools and not force_tool_stream) or not hasattr(
            self.backend, "ask_tool_stream"
        ):
            result = await self.complete(request)
            yield StreamChunk(
                content=result.content,
                reasoning_content=result.reasoning_content,
                finish_reason=result.finish_reason,
                usage=result.usage,
                pool_index=result.pool_index,
            )
            return
        handle = StreamHandle()
        kwargs = {
            "messages": self._messages(request),
            "system_msgs": request.metadata.get("system_msgs"),
            "timeout": int(request.timeout or 300),
            "tools": [dict(tool) for tool in request.tools],
            "tool_choice": request.tool_choice,
            "handle": handle,
            "collect_all_tool_calls": True,
            "parallel_tool_calls": request.metadata.get("parallel_tool_calls"),
        }
        if request.temperature is not None:
            kwargs["temperature"] = request.temperature

        async def run_with_usage() -> tuple[Any, Usage, str, int | None]:
            # CallStatsMixin stores statistics in task-local ContextVar state. Read
            # them in the provider task and carry the typed value across the task
            # boundary instead of consulting the parent's unchanged context.
            try:
                response = await self._with_usage(self.backend.ask_tool_stream(**kwargs))
                return (
                    response,
                    self._usage(self.backend),
                    str(getattr(self.backend, "_last_finish_reason", "unknown")),
                    getattr(self.backend, "_last_call_pool_index", None),
                )
            finally:
                # Also wake the consumer when validation fails before streaming,
                # or an adapted backend returns without sending its own EOS.
                handle.finish()

        operation = asyncio.create_task(run_with_usage())
        streamed: list[str] = []
        streamed_reasoning: list[str] = []
        try:
            while True:
                chunk = await handle.queue.get()
                if chunk is None:
                    break
                if isinstance(chunk, GuardStreamChunk):
                    if chunk.channel == "reasoning":
                        streamed_reasoning.append(chunk.text)
                        yield StreamChunk(reasoning_content=chunk.text)
                    continue
                if isinstance(chunk, ChannelStreamChunk):
                    if chunk.channel == "tool_preview":
                        yield StreamChunk(tool_call_preview=str(chunk))
                    continue
                text = str(chunk)
                streamed.append(text)
                yield StreamChunk(content=text)
            response, usage, finish_reason, pool_index = await operation
        except BaseException:
            operation.cancel()
            await asyncio.gather(operation, return_exceptions=True)
            raise
        raw_calls = getattr(response, "tool_calls", None) or ()
        for index, call in enumerate(raw_calls):
            row = coerce_tool_call(call).model_dump(exclude_none=True)
            yield StreamChunk(tool_call_delta={"index": index, **row})
        response_content = str(getattr(response, "content", "") or "")
        preview = "".join(streamed)
        trailing = response_content[len(preview) :] if response_content.startswith(preview) else ""
        response_reasoning = str(getattr(response, "reasoning_content", "") or "")
        reasoning_preview = "".join(streamed_reasoning)
        trailing_reasoning = (
            response_reasoning[len(reasoning_preview) :]
            if response_reasoning.startswith(reasoning_preview)
            else response_reasoning
        )
        yield StreamChunk(
            content=trailing,
            reasoning_content=trailing_reasoning,
            finish_reason=finish_reason,
            usage=usage,
            pool_index=pool_index,
        )

    @staticmethod
    def _messages(request: CompletionRequest) -> list[Any]:
        if request.metadata.get("message_objects"):
            return [Message.from_dict(message) for message in request.messages]
        return [dict(message) for message in request.messages]

    async def aclose(self) -> None:
        instances = getattr(self.backend, "_instances", None)
        targets = instances if isinstance(instances, list) else [self.backend]
        for target in targets:
            client = getattr(target, "client", None)
            close = getattr(client, "close", None)
            if close is not None:
                result = close()
                if hasattr(result, "__await__"):
                    await result


class ToolAdapter(BaseTool):
    """Expose an execute-compatible tool through the context-aware contract."""

    def __init__(self, tool: Any) -> None:
        self.tool = tool
        self.name = str(tool.name)
        self.description = str(tool.description)
        self.input_schema = dict(getattr(tool, "parameters", None) or {})

    async def execute(self, arguments: Mapping[str, Any], context: ToolContext) -> ToolResult:
        context.cancellation.raise_if_cancelled()
        raw = await self.tool.execute(**dict(arguments))
        if hasattr(raw, "output") or hasattr(raw, "error"):
            output = getattr(raw, "output", "")
            error = getattr(raw, "error", None)
            system = getattr(raw, "system", None)
            metadata = {"system": system} if system is not None else {}
            return ToolResult(
                output=str(output or ""),
                error=str(error) if error else None,
                metadata=metadata,
            )
        return ToolResult(output=str(raw or ""))
