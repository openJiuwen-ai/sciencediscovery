from __future__ import annotations

import asyncio
import json
import threading
from dataclasses import replace
from pathlib import Path
from typing import Iterable, Protocol, TextIO, runtime_checkable

from .models import RuntimeEvent


def _recover_event_file(path: Path) -> int:
    if not path.exists():
        return 0
    raw = path.read_bytes()
    lines = raw.splitlines(keepends=True)
    offset = 0
    last_valid_offset = 0
    sequence = 0
    for index, line in enumerate(lines):
        next_offset = offset + len(line)
        stripped = line.strip()
        if not stripped:
            last_valid_offset = next_offset
            offset = next_offset
            continue
        try:
            event = RuntimeEvent.from_dict(json.loads(stripped))
        except (json.JSONDecodeError, TypeError, ValueError):
            is_trailing_partial = index == len(lines) - 1 and not raw.endswith((b"\n", b"\r"))
            if not is_trailing_partial:
                raise ValueError(f"Invalid runtime event while reopening {path}")
            with path.open("r+b") as handle:
                handle.truncate(last_valid_offset)
            break
        sequence = max(sequence, int(event.sequence or 0))
        last_valid_offset = next_offset
        offset = next_offset
    return sequence


def _write_event(handle: TextIO, event: RuntimeEvent) -> None:
    handle.write(json.dumps(event.to_dict(), ensure_ascii=False, separators=(",", ":")))
    handle.write("\n")


@runtime_checkable
class EventSink(Protocol):
    async def emit(self, event: RuntimeEvent) -> RuntimeEvent: ...

    async def flush(self) -> None: ...

    async def aclose(self) -> None: ...


class NullEventSink:
    async def emit(self, event: RuntimeEvent) -> RuntimeEvent:
        return event

    async def flush(self) -> None:
        return None

    async def aclose(self) -> None:
        return None


class JsonlEventSink:
    """Ordered single-writer JSONL sink with deterministic sequence numbers."""

    _FLUSH_EVENT_SUFFIXES = (".completed", ".failed")

    def __init__(self, path: str | Path, *, flush_each_event: bool = False) -> None:
        self.path = Path(path)
        self.flush_each_event = flush_each_event
        self._lock = asyncio.Lock()
        self._file: TextIO | None = None
        self._sequence = 0
        self._closed = False
        self._recovered = False

    def _recover_existing(self) -> None:
        if self._recovered:
            return
        self._recovered = True
        self._sequence = max(self._sequence, _recover_event_file(self.path))

    def _ensure_open(self) -> TextIO:
        self._recover_existing()
        if self._file is None:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self._file = self.path.open("a", encoding="utf-8")
        return self._file

    async def emit(self, event: RuntimeEvent) -> RuntimeEvent:
        async with self._lock:
            if self._closed:
                raise RuntimeError("Cannot emit to a closed JsonlEventSink")
            self._recover_existing()
            self._sequence = max(self._sequence + 1, int(event.sequence or 0))
            sequenced = replace(event, sequence=self._sequence)
            handle = self._ensure_open()
            _write_event(handle, sequenced)
            if self.flush_each_event or sequenced.type.endswith(self._FLUSH_EVENT_SUFFIXES):
                handle.flush()
            return sequenced

    async def flush(self) -> None:
        async with self._lock:
            if self._file is not None:
                self._file.flush()

    async def aclose(self) -> None:
        async with self._lock:
            if self._closed:
                return
            self._closed = True
            if self._file is not None:
                self._file.flush()
                self._file.close()
                self._file = None


class SyncJsonlEventSink:
    """Thread-safe sync adapter for legacy producers that cannot await a sink."""

    _FLUSH_EVENT_SUFFIXES = JsonlEventSink._FLUSH_EVENT_SUFFIXES

    def __init__(self, path: str | Path, *, flush_each_event: bool = False) -> None:
        self.path = Path(path)
        self.flush_each_event = flush_each_event
        self._lock = threading.Lock()
        self._file: TextIO | None = None
        self._sequence = _recover_event_file(self.path)
        self._closed = False

    def emit(self, event: RuntimeEvent) -> RuntimeEvent:
        with self._lock:
            if self._closed:
                raise RuntimeError("Cannot emit to a closed SyncJsonlEventSink")
            self._sequence = max(self._sequence + 1, int(event.sequence or 0))
            sequenced = replace(event, sequence=self._sequence)
            if self._file is None:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                self._file = self.path.open("a", encoding="utf-8")
            _write_event(self._file, sequenced)
            if self.flush_each_event or sequenced.type.endswith(self._FLUSH_EVENT_SUFFIXES):
                self._file.flush()
            return sequenced

    def flush(self) -> None:
        with self._lock:
            if self._file is not None:
                self._file.flush()

    def close(self) -> None:
        with self._lock:
            if self._closed:
                return
            self._closed = True
            if self._file is not None:
                self._file.flush()
                self._file.close()
                self._file = None


class CompositeEventSink:
    """Fan out events while isolating individual observer failures by default."""

    def __init__(self, sinks: Iterable[EventSink], *, raise_on_error: bool = False) -> None:
        self.sinks = tuple(sinks)
        self.raise_on_error = raise_on_error
        self.errors: list[Exception] = []

    async def emit(self, event: RuntimeEvent) -> RuntimeEvent:
        emitted = event
        for sink in self.sinks:
            try:
                emitted = await sink.emit(event)
            except Exception as exc:
                self.errors.append(exc)
                if self.raise_on_error:
                    raise
        return emitted

    async def flush(self) -> None:
        for sink in self.sinks:
            try:
                await sink.flush()
            except Exception as exc:
                self.errors.append(exc)
                if self.raise_on_error:
                    raise

    async def aclose(self) -> None:
        for sink in self.sinks:
            try:
                await sink.aclose()
            except Exception as exc:
                self.errors.append(exc)
                if self.raise_on_error:
                    raise


def load_events(path: str | Path, *, event_type: str | None = None) -> list[RuntimeEvent]:
    events: list[RuntimeEvent] = []
    source = Path(path)
    if not source.exists():
        return events
    raw = source.read_bytes()
    lines = raw.splitlines(keepends=True)
    for line_number, line in enumerate(lines, start=1):
        try:
            text = line.decode("utf-8")
        except UnicodeDecodeError as exc:
            is_partial = line_number == len(lines) and not raw.endswith((b"\n", b"\r"))
            if is_partial:
                break
            raise ValueError(f"Invalid runtime event at {source}:{line_number}: {exc}") from exc
        if not text.strip():
            continue
        try:
            event = RuntimeEvent.from_dict(json.loads(text))
        except (json.JSONDecodeError, TypeError, ValueError) as exc:
            is_partial = line_number == len(lines) and not raw.endswith((b"\n", b"\r"))
            if is_partial:
                break
            raise ValueError(f"Invalid runtime event at {source}:{line_number}: {exc}") from exc
        if event_type is None or event.type == event_type:
            events.append(event)
    return events
