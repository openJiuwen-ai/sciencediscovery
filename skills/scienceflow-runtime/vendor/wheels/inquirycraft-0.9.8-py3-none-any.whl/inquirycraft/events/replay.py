"""Deterministic LLM recording and replay for runtime compatibility gates."""

from __future__ import annotations

import asyncio
import json
from collections.abc import AsyncIterator, Iterable, Mapping
from pathlib import Path
from typing import Any

from inquirycraft.llm import CompletionRequest, CompletionResult, LLMClient, StreamChunk, Usage

from .models import RuntimeEvent

RECORDING_SCHEMA_VERSION = "1.0"


class ReplayMismatchError(AssertionError):
    """Raised when replay input diverges from the recorded provider request."""


def _json_value(value: Any) -> Any:
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, Mapping):
        return {str(key): _json_value(child) for key, child in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_value(child) for child in value]
    raise TypeError(f"Replay data is not JSON serializable: {type(value).__name__}")


def request_to_dict(request: CompletionRequest) -> dict[str, Any]:
    return {
        "messages": _json_value(request.messages),
        "model": request.model,
        "tools": _json_value(request.tools),
        "tool_choice": _json_value(request.tool_choice),
        "temperature": request.temperature,
        "max_tokens": request.max_tokens,
        "timeout": request.timeout,
        "metadata": _json_value(request.metadata),
    }


def usage_to_dict(usage: Usage) -> dict[str, int]:
    return {
        "input_tokens": usage.input_tokens,
        "output_tokens": usage.output_tokens,
        "cached_input_tokens": usage.cached_input_tokens,
    }


def usage_from_dict(row: Mapping[str, Any] | None) -> Usage:
    row = row or {}
    return Usage(
        input_tokens=int(row.get("input_tokens", 0)),
        output_tokens=int(row.get("output_tokens", 0)),
        cached_input_tokens=int(row.get("cached_input_tokens", 0)),
    )


def result_to_dict(result: CompletionResult) -> dict[str, Any]:
    return {
        "content": result.content,
        "reasoning_content": result.reasoning_content,
        "tool_calls": _json_value(result.tool_calls),
        "finish_reason": result.finish_reason,
        "usage": usage_to_dict(result.usage),
    }


def result_from_dict(row: Mapping[str, Any]) -> CompletionResult:
    return CompletionResult(
        content=str(row.get("content") or ""),
        reasoning_content=str(row.get("reasoning_content") or ""),
        tool_calls=tuple(row.get("tool_calls") or ()),
        finish_reason=str(row.get("finish_reason") or "unknown"),
        usage=usage_from_dict(row.get("usage")),
    )


def chunk_to_dict(chunk: StreamChunk) -> dict[str, Any]:
    return {
        "content": chunk.content,
        "reasoning_content": chunk.reasoning_content,
        "tool_call_preview": chunk.tool_call_preview,
        "tool_call_delta": _json_value(chunk.tool_call_delta),
        "finish_reason": chunk.finish_reason,
        "usage": usage_to_dict(chunk.usage) if chunk.usage is not None else None,
    }


def chunk_from_dict(row: Mapping[str, Any]) -> StreamChunk:
    usage = row.get("usage")
    return StreamChunk(
        content=str(row.get("content") or ""),
        reasoning_content=str(row.get("reasoning_content") or ""),
        tool_call_preview=str(row.get("tool_call_preview") or ""),
        tool_call_delta=row.get("tool_call_delta"),
        finish_reason=(str(row["finish_reason"]) if row.get("finish_reason") is not None else None),
        usage=usage_from_dict(usage) if isinstance(usage, Mapping) else None,
    )


def load_recording(path: str | Path) -> list[dict[str, Any]]:
    source = Path(path)
    if not source.exists():
        return []
    rows: list[dict[str, Any]] = []
    with source.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid LLM recording at {source}:{line_number}: {exc}") from exc
            if not isinstance(row, dict):
                raise ValueError(f"Invalid LLM recording object at {source}:{line_number}")
            if row.get("schema_version") != RECORDING_SCHEMA_VERSION:
                raise ValueError(
                    f"Unsupported LLM recording schema at {source}:{line_number}: "
                    f"{row.get('schema_version')!r}"
                )
            rows.append(row)
    return rows


class RecordingLLMClient:
    """Wrap an LLM client and append provider-visible requests/results to JSONL."""

    def __init__(self, client: LLMClient, path: str | Path) -> None:
        self.client = client
        self.path = Path(path)
        existing = load_recording(self.path)
        self._sequence = max((int(row.get("sequence", 0)) for row in existing), default=0)
        self._lock = asyncio.Lock()

    async def _append(self, operation: str, request: CompletionRequest, **payload: Any) -> None:
        async with self._lock:
            self._sequence += 1
            row = {
                "schema_version": RECORDING_SCHEMA_VERSION,
                "sequence": self._sequence,
                "operation": operation,
                "request": request_to_dict(request),
                **_json_value(payload),
            }
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.open("a", encoding="utf-8") as handle:
                handle.write(
                    json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
                )
                handle.write("\n")
                handle.flush()

    async def complete(self, request: CompletionRequest) -> CompletionResult:
        result = await self.client.complete(request)
        await self._append("complete", request, result=result_to_dict(result))
        return result

    def stream(self, request: CompletionRequest) -> AsyncIterator[StreamChunk]:
        async def generate() -> AsyncIterator[StreamChunk]:
            chunks: list[dict[str, Any]] = []
            completed = False
            try:
                async for chunk in self.client.stream(request):
                    chunks.append(chunk_to_dict(chunk))
                    yield chunk
                completed = True
            finally:
                await self._append(
                    "stream",
                    request,
                    chunks=chunks,
                    stream_complete=completed,
                )

        return generate()

    async def aclose(self) -> None:
        await self.client.aclose()


class ReplayLLMClient:
    """Serve a finite recording and fail immediately on request drift."""

    def __init__(
        self,
        path: str | Path,
        *,
        strict: bool = True,
        start_sequence: int | None = None,
    ) -> None:
        self.path = Path(path)
        self.rows = load_recording(self.path)
        self.strict = strict
        if start_sequence is None:
            self._cursor = 0
        else:
            matches = [
                index
                for index, row in enumerate(self.rows)
                if int(row.get("sequence", 0)) == int(start_sequence)
            ]
            if len(matches) != 1:
                raise ValueError(
                    f"Recording must contain exactly one sequence {start_sequence}, "
                    f"found {len(matches)}"
                )
            self._cursor = matches[0]
        self._start_cursor = self._cursor
        self.closed = False

    def _next(self, operation: str, request: CompletionRequest) -> dict[str, Any]:
        if self._cursor >= len(self.rows):
            raise ReplayMismatchError(
                f"Recording exhausted before {operation} request #{self._cursor + 1}"
            )
        row = self.rows[self._cursor]
        if row.get("operation") != operation:
            raise ReplayMismatchError(
                f"Replay operation mismatch at sequence {row.get('sequence')}: "
                f"expected {row.get('operation')!r}, got {operation!r}"
            )
        actual = request_to_dict(request)
        expected = row.get("request")
        if self.strict and actual != expected:
            expected_json = json.dumps(expected, ensure_ascii=False, sort_keys=True)
            actual_json = json.dumps(actual, ensure_ascii=False, sort_keys=True)
            raise ReplayMismatchError(
                f"Replay request mismatch at sequence {row.get('sequence')}:\n"
                f"expected={expected_json}\nactual={actual_json}"
            )
        self._cursor += 1
        return row

    @property
    def consumed(self) -> int:
        return self._cursor - self._start_cursor

    @property
    def remaining(self) -> int:
        return len(self.rows) - self._cursor

    async def complete(self, request: CompletionRequest) -> CompletionResult:
        row = self._next("complete", request)
        result = row.get("result")
        if not isinstance(result, Mapping):
            raise ValueError(f"Recorded completion has no result at sequence {row.get('sequence')}")
        return result_from_dict(result)

    def stream(self, request: CompletionRequest) -> AsyncIterator[StreamChunk]:
        async def generate() -> AsyncIterator[StreamChunk]:
            row = self._next("stream", request)
            if not row.get("stream_complete", False):
                raise ReplayMismatchError(
                    f"Cannot replay incomplete stream at sequence {row.get('sequence')}"
                )
            for chunk in row.get("chunks") or ():
                if not isinstance(chunk, Mapping):
                    raise ValueError(
                        f"Invalid stream chunk at recording sequence {row.get('sequence')}"
                    )
                yield chunk_from_dict(chunk)

        return generate()

    def assert_exhausted(self) -> None:
        if self._cursor != len(self.rows):
            raise ReplayMismatchError(
                f"Replay left {len(self.rows) - self._cursor} unconsumed request(s)"
            )

    async def aclose(self) -> None:
        self.closed = True


def canonicalize_runtime_events(
    events: Iterable[RuntimeEvent | Mapping[str, Any]],
) -> list[dict[str, Any]]:
    """Normalize only runtime-generated event IDs/timestamps for strict comparison."""

    rows = [event.to_dict() if isinstance(event, RuntimeEvent) else dict(event) for event in events]
    id_map = {
        str(row.get("event_id")): f"event:{index}"
        for index, row in enumerate(rows, start=1)
        if row.get("event_id")
    }
    normalized: list[dict[str, Any]] = []
    for index, row in enumerate(rows, start=1):
        current = dict(row)
        current["timestamp"] = "<timestamp>"
        current["event_id"] = id_map.get(str(row.get("event_id")), f"event:{index}")
        parent = row.get("parent_event_id")
        current["parent_event_id"] = id_map.get(str(parent)) if parent is not None else None
        normalized.append(current)
    return normalized
