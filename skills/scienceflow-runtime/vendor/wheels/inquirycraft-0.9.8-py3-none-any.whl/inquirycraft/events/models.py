from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Mapping
from uuid import uuid4

EVENT_SCHEMA_VERSION = "1.0"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


@dataclass(frozen=True, slots=True, kw_only=True)
class RuntimeEvent:
    """Stable JSONL envelope for InquiryCraft runtime events."""

    type: str
    session_id: str
    run_id: str
    agent_id: str
    payload: Mapping[str, Any] = field(default_factory=dict)
    sequence: int = 0
    event_id: str = field(default_factory=lambda: f"evt_{uuid4().hex}")
    timestamp: str = field(default_factory=utc_now)
    turn_id: int | None = None
    parent_event_id: str | None = None
    schema_version: str = EVENT_SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        row: dict[str, Any] = {
            "schema_version": self.schema_version,
            "sequence": self.sequence,
            "event_id": self.event_id,
            "timestamp": self.timestamp,
            "session_id": self.session_id,
            "run_id": self.run_id,
            "agent_id": self.agent_id,
            "turn_id": self.turn_id,
            "parent_event_id": self.parent_event_id,
            "type": self.type,
            "payload": dict(self.payload),
        }
        return row

    @classmethod
    def from_dict(cls, row: Mapping[str, Any]) -> "RuntimeEvent":
        required = ("type", "session_id", "run_id", "agent_id")
        missing = [key for key in required if not str(row.get(key, "")).strip()]
        if missing:
            raise ValueError(f"Runtime event is missing required fields: {', '.join(missing)}")
        version = str(row.get("schema_version", EVENT_SCHEMA_VERSION))
        if version != EVENT_SCHEMA_VERSION:
            raise ValueError(f"Unsupported runtime event schema_version: {version}")
        return cls(
            schema_version=version,
            sequence=int(row.get("sequence", 0)),
            event_id=str(row.get("event_id") or f"evt_{uuid4().hex}"),
            timestamp=str(row.get("timestamp") or utc_now()),
            session_id=str(row["session_id"]),
            run_id=str(row["run_id"]),
            agent_id=str(row["agent_id"]),
            turn_id=int(row["turn_id"]) if row.get("turn_id") is not None else None,
            parent_event_id=(
                str(row["parent_event_id"]) if row.get("parent_event_id") is not None else None
            ),
            type=str(row["type"]),
            payload=dict(row.get("payload") or {}),
        )
