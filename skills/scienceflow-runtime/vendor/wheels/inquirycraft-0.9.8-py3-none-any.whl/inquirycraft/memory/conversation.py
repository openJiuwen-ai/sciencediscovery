from __future__ import annotations

import json
import os
from collections.abc import Callable, Iterable, Sequence
from pathlib import Path

from .message import Message


class Conversation:
    """In-memory conversation with a stable JSONL persistence format."""

    def __init__(self, messages: Iterable[Message] = ()) -> None:
        self._messages = list(messages)

    @property
    def messages(self) -> tuple[Message, ...]:
        return tuple(self._messages)

    def append(self, message: Message) -> None:
        self._messages.append(message)

    def clear(self) -> None:
        self._messages.clear()

    def replace(self, messages: Iterable[Message]) -> None:
        self._messages[:] = list(messages)

    def fork(
        self,
        projector: Callable[[Sequence[Message]], Iterable[Message]] | None = None,
    ) -> "Conversation":
        source = tuple(self._messages)
        return Conversation(projector(source) if projector is not None else source)

    def to_openai(self) -> list[dict]:
        return [message.to_dict() for message in self._messages]


class JsonlConversationStore:
    SCHEMA_VERSION = "1.0"

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self._sequence: int | None = None

    def append(self, message: Message) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._sequence = (self._last_sequence() if self._sequence is None else self._sequence) + 1
        row = {
            "schema_version": self.SCHEMA_VERSION,
            "sequence": self._sequence,
            "message": message.to_dict(),
        }
        descriptor = os.open(self.path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
        with os.fdopen(descriptor, "a", encoding="utf-8") as handle:
            handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")

    def load(self) -> Conversation:
        messages: list[Message] = []
        last_sequence = 0
        if not self.path.exists():
            return Conversation()
        with self.path.open("r", encoding="utf-8") as handle:
            for line_number, line in enumerate(handle, start=1):
                if not line.strip():
                    continue
                try:
                    row = json.loads(line)
                    if str(row.get("schema_version")) != self.SCHEMA_VERSION:
                        raise ValueError(f"unsupported schema {row.get('schema_version')!r}")
                    last_sequence = max(last_sequence, int(row.get("sequence", 0)))
                    messages.append(Message.from_dict(row["message"]))
                except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
                    raise ValueError(
                        f"Invalid conversation record at {self.path}:{line_number}: {exc}"
                    ) from exc
        self._sequence = last_sequence
        return Conversation(messages)

    def _last_sequence(self) -> int:
        if not self.path.exists():
            return 0
        last = 0
        with self.path.open("r", encoding="utf-8") as handle:
            for line in handle:
                if line.strip():
                    try:
                        last = int(json.loads(line).get("sequence", last))
                    except (json.JSONDecodeError, TypeError, ValueError):
                        continue
        return last
