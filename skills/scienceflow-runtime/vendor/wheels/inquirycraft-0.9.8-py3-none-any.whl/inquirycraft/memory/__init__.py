from importlib import import_module
from typing import Any

from .conversation import Conversation, JsonlConversationStore
from .message import (
    Function,
    Message,
    Role,
    ToolCall,
    coerce_function,
    coerce_message,
    coerce_tool_call,
)
from .record_store import (
    MessageRecord,
    dedupe_message_records,
    message_record_content,
    message_record_has_tool_calls,
    message_record_message,
    message_record_role,
    message_record_window_score,
    read_message_records,
    repair_message_record_window,
    write_message_records,
)

__all__ = [
    "Conversation",
    "Function",
    "JsonlConversationStore",
    "JsonKeyValueStorage",
    "MessageRecord",
    "Message",
    "Role",
    "ToolCall",
    "coerce_function",
    "coerce_message",
    "coerce_tool_call",
    "dedupe_message_records",
    "message_record_content",
    "message_record_has_tool_calls",
    "message_record_message",
    "message_record_role",
    "message_record_window_score",
    "read_message_records",
    "repair_message_record_window",
    "write_message_records",
    "BaseChatHistoryMemory",
    "BaseContextCreator",
    "ContextRecord",
    "Memory",
    "MemoryRecord",
]

_LAZY_EXPORTS = {
    "BaseChatHistoryMemory": ("inquirycraft.memory.history", "BaseChatHistoryMemory"),
    "BaseContextCreator": ("inquirycraft.memory.context", "BaseContextCreator"),
    "ContextRecord": ("inquirycraft.memory.records", "ContextRecord"),
    "Memory": ("inquirycraft.memory.history", "Memory"),
    "MemoryRecord": ("inquirycraft.memory.records", "MemoryRecord"),
    "JsonKeyValueStorage": ("inquirycraft.memory.kv_storage", "JsonKeyValueStorage"),
}


def __getattr__(name: str) -> Any:
    if name not in _LAZY_EXPORTS:
        raise AttributeError(name)
    module_name, attribute = _LAZY_EXPORTS[name]
    value = getattr(import_module(module_name), attribute)
    globals()[name] = value
    return value
