"""Historical bounded chat memory owned by InquiryCraft."""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field

from inquirycraft.memory.kv_storage import (
    BaseKeyValueStorage,
    InMemoryKeyValueStorage,
)
from inquirycraft.memory.message import Message, Role, coerce_message

from .context import BaseContextCreator
from .records import ContextRecord, MemoryRecord

logger = logging.getLogger(__name__)


class BaseChatHistoryMemory:
    def __init__(
        self,
        storage: BaseKeyValueStorage | None = None,
        max_messages: int | None = None,
        keep_rate: float | None = 0.9,
    ) -> None:
        if keep_rate > 1.0 or keep_rate < 0.0:
            raise ValueError("`keep_rate` should be in [0,1]")
        self.storage = storage or InMemoryKeyValueStorage()
        self.keep_rate = keep_rate
        self._max_records = max_messages
        self._num_records = 0

    def set_memory_limit(self, max_messages: int | None = None, **kwargs: Any) -> None:
        self._max_records = max_messages

    def exceed_memory_limit(self) -> bool:
        if not self._max_records:
            return False
        return self._num_records >= self._max_records

    def add_record(self, record: MemoryRecord) -> None:
        self.storage.save(records=[record.to_dict()])
        self._num_records += 1

    def clear(self) -> None:
        self.storage.clear()
        self._num_records = 0

    def compress(self) -> None:
        if not self.exceed_memory_limit():
            return
        saved_records = self.retrieve(window_size=self._max_records - 1)
        self.clear()
        for record in saved_records:
            self.add_record(record.memory_record)

    def retrieve(
        self,
        query: Message | None = None,
        window_size: int | None = None,
    ) -> list[ContextRecord]:
        record_dicts = self.storage.load()
        if len(record_dicts) == 0:
            logger.info("The `BaseChatHistoryMemory` is empty.")
            return []
        if window_size is not None and window_size >= 0:
            start_index = 1 if record_dicts and record_dicts[0]["role"] in {Role.SYSTEM} else 0
            preserved_messages = record_dicts[:start_index]
            sliding_messages = record_dicts[start_index:]
            truncated_messages = sliding_messages[-window_size:]
            final_records = preserved_messages + truncated_messages
        else:
            final_records = record_dicts
        chat_records = [MemoryRecord.from_dict(record) for record in final_records]
        output_records: list[ContextRecord] = []
        score = 1.0
        for record in reversed(chat_records):
            if record.role == Role.SYSTEM:
                output_records.append(
                    ContextRecord(
                        memory_record=record,
                        score=1.0,
                        timestamp=record.timestamp,
                    )
                )
            else:
                score *= self.keep_rate
                output_records.append(
                    ContextRecord(
                        memory_record=record,
                        score=score,
                        timestamp=record.timestamp,
                    )
                )
        output_records.reverse()
        return output_records


class Memory(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True, extra="allow")

    max_messages: int = Field(default=100)
    long_term_log: str | None = Field(default=None)
    chat_history_memory: BaseChatHistoryMemory = Field(default_factory=BaseChatHistoryMemory)
    context_creator: BaseContextCreator = Field(default_factory=BaseContextCreator)
    window_size: int | None = Field(default=None)

    def model_post_init(self, __context: Any) -> None:
        if self.window_size is not None and not isinstance(self.window_size, int):
            raise TypeError("`window_size` must be an integer or None.")
        if self.window_size is not None and self.window_size < 0:
            raise ValueError("`window_size` must be non-negative.")
        self.chat_history_memory.set_memory_limit(max_messages=self.max_messages)

    def add_message(
        self,
        message: Message,
        extra_info: dict[str, Any] | None = None,
        uuid: UUID | None = None,
        timestamp: float | None = None,
        agent_id: str | None = "",
        **kwargs: Any,
    ) -> None:
        normalized = coerce_message(message)
        record = MemoryRecord(
            message=normalized,
            role=normalized.role,
            extra_info=extra_info or {},
            uuid=uuid or uuid4(),
            timestamp=timestamp or datetime.now(timezone.utc).timestamp(),
            agent_id=agent_id,
        )
        self.chat_history_memory.add_record(record)
        if self.chat_history_memory.exceed_memory_limit():
            self.chat_history_memory.compress()
        if self.long_term_log is not None:
            record_dict = record.to_dict()
            with open(self.long_term_log, "a", encoding="utf-8") as handle:
                handle.write(json.dumps(record_dict, ensure_ascii=False) + "\n")

    def add_messages(self, messages: list[Message], **kwargs: Any) -> None:
        for message in messages:
            self.add_message(message, **kwargs)

    def clear(self) -> None:
        self.chat_history_memory.clear()

    def get_context(self, query: str | Message, **kwargs: Any) -> list[Message] | None:
        if query is not None:
            return None
        return self.get_recent_records()

    def get_recent_records(self, n: int | None = None, **kwargs: Any) -> list[Message]:
        n = n or self.window_size
        retrieved_chat_records = self.chat_history_memory.retrieve(window_size=n)
        return self.context_creator.create_context(
            chat_history_records=retrieved_chat_records,
            **kwargs,
        )

    @property
    def messages(self) -> list[Message]:
        return self.get_recent_records(n=self.window_size)

    @messages.setter
    def messages(self, value: list[Message]) -> None:
        self.clear()
        self.add_messages(value)

    @property
    def context_messages(self) -> str:
        output = ""
        for message in self.messages:
            output += f"{message.content}; "
        return output
