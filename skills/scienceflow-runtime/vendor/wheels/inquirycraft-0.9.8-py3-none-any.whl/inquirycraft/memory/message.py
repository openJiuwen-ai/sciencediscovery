"""Canonical dependency-light message and tool-call value objects."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, replace
from enum import Enum
from typing import Any, ClassVar, Literal


class Role(str, Enum):
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"


ROLE_VALUES = tuple(role.value for role in Role)
ROLE_TYPE = Literal[ROLE_VALUES]  # type: ignore[valid-type]


def _mapping(value: Any) -> dict[str, Any]:
    if isinstance(value, Mapping):
        return dict(value)
    if hasattr(value, "model_dump"):
        return dict(value.model_dump())
    if hasattr(value, "to_dict"):
        return dict(value.to_dict())
    if hasattr(value, "__dict__"):
        return {key: child for key, child in vars(value).items() if not str(key).startswith("_")}
    raise TypeError(f"Unsupported model value: {type(value)!r}")


@dataclass
class Function:
    name: str
    arguments: str

    model_fields: ClassVar[dict[str, None]] = {"name": None, "arguments": None}

    def model_dump(self, *, exclude_none: bool = False, **_: Any) -> dict[str, Any]:
        row = {"name": self.name, "arguments": self.arguments}
        return (
            {key: value for key, value in row.items() if value is not None} if exclude_none else row
        )

    def model_copy(self, *, update: Mapping[str, Any] | None = None, **_: Any) -> "Function":
        return replace(self, **dict(update or {}))

    @classmethod
    def model_validate(cls, value: Any) -> "Function":
        return coerce_function(value)


@dataclass
class ToolCall:
    id: str
    function: Function
    type: str = "function"

    model_fields: ClassVar[dict[str, None]] = dict.fromkeys("id type function".split())

    def __post_init__(self) -> None:
        self.function = coerce_function(self.function)

    def model_dump(self, *, exclude_none: bool = False, **_: Any) -> dict[str, Any]:
        row = {
            "id": self.id,
            "type": self.type,
            "function": self.function.model_dump(exclude_none=exclude_none),
        }
        return (
            {key: value for key, value in row.items() if value is not None} if exclude_none else row
        )

    def model_copy(self, *, update: Mapping[str, Any] | None = None, **_: Any) -> "ToolCall":
        return replace(self, **dict(update or {}))

    @classmethod
    def model_validate(cls, value: Any) -> "ToolCall":
        return coerce_tool_call(value)


def coerce_function(value: Any) -> Function:
    if isinstance(value, Function):
        return value
    row = _mapping(value)
    return Function(name=str(row.get("name") or ""), arguments=str(row.get("arguments") or ""))


def coerce_tool_call(value: Any) -> ToolCall:
    if isinstance(value, ToolCall):
        return value
    row = _mapping(value)
    return ToolCall(
        id=str(row.get("id") or ""),
        type=str(row.get("type") or "function"),
        function=coerce_function(row.get("function")),
    )


@dataclass
class Message:
    role: ROLE_TYPE
    content: str | list[dict] | None = None
    tool_calls: list[ToolCall] | None = None
    name: str | None = None
    tool_call_id: str | None = None
    reasoning_content: str | None = None

    model_fields: ClassVar[dict[str, None]] = dict.fromkeys(
        "role content tool_calls name tool_call_id reasoning_content".split()
    )

    def __post_init__(self) -> None:
        role = self.role.value if isinstance(self.role, Role) else str(self.role)
        if role not in ROLE_VALUES:
            raise ValueError(f"Unsupported message role: {role!r}")
        self.role = role  # type: ignore[assignment]
        if self.tool_calls is not None:
            self.tool_calls = [coerce_tool_call(call) for call in self.tool_calls]

    def __add__(self, other: Any) -> list["Message"]:
        if isinstance(other, list):
            return [self] + other
        if isinstance(other, Message):
            return [self, other]
        raise TypeError(
            f"unsupported operand type(s) for +: '{type(self).__name__}' "
            f"and '{type(other).__name__}'"
        )

    def __radd__(self, other: Any) -> list["Message"]:
        if isinstance(other, list):
            return other + [self]
        raise TypeError(
            f"unsupported operand type(s) for +: '{type(other).__name__}' "
            f"and '{type(self).__name__}'"
        )

    def model_dump(self, *, exclude_none: bool = False, **_: Any) -> dict[str, Any]:
        row: dict[str, Any] = {
            "role": self.role,
            "content": self.content,
            "tool_calls": (
                [call.model_dump(exclude_none=exclude_none) for call in self.tool_calls]
                if self.tool_calls is not None
                else None
            ),
            "name": self.name,
            "tool_call_id": self.tool_call_id,
            "reasoning_content": self.reasoning_content,
        }
        return (
            {key: value for key, value in row.items() if value is not None} if exclude_none else row
        )

    def model_copy(self, *, update: Mapping[str, Any] | None = None, **_: Any) -> "Message":
        return replace(self, **dict(update or {}))

    @classmethod
    def model_validate(cls, value: Any) -> "Message":
        return coerce_message(value)

    def to_dict(self) -> dict[str, Any]:
        row = self.model_dump(exclude_none=True)
        if not self.tool_calls:
            row.pop("tool_calls", None)
        return row

    @classmethod
    def from_dict(cls, row: Mapping[str, Any]) -> "Message":
        return cls.model_validate(row)

    @classmethod
    def user_message(cls, content: str | list[dict]) -> "Message":
        return cls(role="user", content=content)

    @classmethod
    def system_message(cls, content: str | list[dict]) -> "Message":
        return cls(role="system", content=content)

    @classmethod
    def assistant_message(
        cls,
        content: str | list[dict] | None = None,
        *,
        reasoning_content: str | None = None,
    ) -> "Message":
        return cls(
            role="assistant",
            content=content,
            reasoning_content=reasoning_content,
        )

    @classmethod
    def tool_message(cls, content: str, name: Any, tool_call_id: str) -> "Message":
        return cls(role="tool", content=content, name=name, tool_call_id=tool_call_id)

    @classmethod
    def from_tool_calls(
        cls,
        tool_calls: list[Any],
        content: str | list[str] = "",
        **kwargs: Any,
    ) -> "Message":
        formatted_calls = [
            {"id": call.id, "function": call.function.model_dump(), "type": "function"}
            for call in tool_calls
        ]
        return cls(
            role="assistant",
            content=content,  # type: ignore[arg-type]
            tool_calls=formatted_calls,  # type: ignore[arg-type]
            **kwargs,
        )


def coerce_message(value: Any) -> Message:
    if isinstance(value, Message):
        return value
    row = _mapping(value)
    return Message(
        role=row.get("role", ""),
        content=row.get("content"),
        tool_calls=row.get("tool_calls"),
        name=row.get("name"),
        tool_call_id=row.get("tool_call_id"),
        reasoning_content=row.get("reasoning_content"),
    )
