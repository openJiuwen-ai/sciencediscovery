"""Historical chat-context projection owned by InquiryCraft."""

from __future__ import annotations

from pydantic import BaseModel

from inquirycraft.memory.message import Message, Role

from .records import ContextRecord


class _ContextUnit(BaseModel):
    idx: int
    record: ContextRecord
    num_tokens: int = 0


class BaseContextCreator:
    def create_context(
        self,
        chat_history_records: list[ContextRecord],
        **kwargs: object,
    ) -> list[Message]:
        system_unit, regular_units = self._extract_system_message(chat_history_records)
        seen_uuids = set()
        if system_unit:
            seen_uuids.add(system_unit.record.memory_record.uuid)
        for index, record in enumerate(chat_history_records):
            if record.memory_record.uuid in seen_uuids:
                continue
            seen_uuids.add(record.memory_record.uuid)
            regular_units.append(_ContextUnit(idx=index, record=record, num_tokens=0))
        sorted_units = sorted(regular_units, key=self._conversation_sort_key)
        return self._assemble_output(sorted_units, system_unit)

    def _extract_system_message(
        self,
        records: list[ContextRecord],
    ) -> tuple[_ContextUnit | None, list[_ContextUnit]]:
        if not records:
            return None, []
        first_record = records[0]
        if first_record.memory_record.role != Role.SYSTEM:
            return None, []
        return _ContextUnit(idx=0, record=first_record, num_tokens=0), []

    def _conversation_sort_key(self, unit: _ContextUnit) -> tuple[float, float]:
        return (unit.record.timestamp, -unit.record.score)

    def _assemble_output(
        self,
        context_units: list[_ContextUnit],
        system_unit: _ContextUnit | None,
    ) -> list[Message]:
        messages: list[Message] = []
        if system_unit:
            messages.append(system_unit.record.memory_record.message)
        for unit in context_units:
            messages.append(unit.record.memory_record.message)
        return messages
