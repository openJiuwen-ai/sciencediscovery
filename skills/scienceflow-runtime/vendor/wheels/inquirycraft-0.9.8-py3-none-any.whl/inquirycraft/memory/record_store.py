"""Canonical helpers for InquiryCraft JSON/JSONL message records.

The memory store writes one JSON object per line to files commonly
named ``short_term.json`` and ``long_term.jsonl``. The helpers in this module are
domain independent; hosts may apply policy-specific filtering around these operations.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Iterable

MessageRecord = dict[str, Any]


def _records_from_json_value(value: Any) -> list[MessageRecord]:
    if isinstance(value, dict):
        return [value]
    if isinstance(value, list):
        return [item for item in value if isinstance(item, dict)]
    return []


def _read_json_lines(
    text: str,
    *,
    path: Path,
    logger: logging.Logger | None,
) -> list[MessageRecord]:
    records: list[MessageRecord] = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            if logger is not None:
                logger.debug("[memory] bad jsonl row skipped in %s", path)
            continue
        records.extend(_records_from_json_value(value))
    return records


def message_record_message(record: MessageRecord) -> MessageRecord:
    message = record.get("message")
    return message if isinstance(message, dict) else record


def message_record_role(record: MessageRecord) -> str:
    message = message_record_message(record)
    return str(message.get("role") or record.get("role") or "").strip()


def message_record_content(record: MessageRecord) -> str:
    content = message_record_message(record).get("content")
    return content if isinstance(content, str) else str(content or "")


def message_record_has_tool_calls(record: MessageRecord) -> bool:
    message = message_record_message(record)
    return bool(message.get("tool_calls") or record.get("tool_calls"))


def dedupe_message_records(records: Iterable[MessageRecord]) -> list[MessageRecord]:
    """Deduplicate records by UUID, falling back to canonical message content."""

    output: list[MessageRecord] = []
    seen: set[str] = set()
    for record in records:
        key = str(record.get("uuid") or "")
        if not key:
            try:
                key = json.dumps(record.get("message", record), sort_keys=True, default=str)
            except TypeError:
                key = str(record)
        if key in seen:
            continue
        seen.add(key)
        output.append(record)
    return output


def read_message_records(
    path: str | Path,
    *,
    logger: logging.Logger | None = None,
) -> list[MessageRecord]:
    """Read JSONL, JSON-list, or single-object memory files.

    Malformed rows are skipped to retain best-effort recovery
    behavior. Missing, unreadable, and empty files produce an empty list.
    """

    record_path = Path(path)
    if not record_path.is_file():
        return []
    try:
        text = record_path.read_text(encoding="utf-8")
    except OSError:
        if logger is not None:
            logger.debug("[memory] failed reading %s", record_path, exc_info=True)
        return []
    if not text.strip():
        return []

    records = _read_json_lines(text, path=record_path, logger=logger)
    if records:
        return dedupe_message_records(records)

    try:
        value = json.loads(text)
    except json.JSONDecodeError:
        return []
    return dedupe_message_records(_records_from_json_value(value))


def write_message_records(path: str | Path, records: Iterable[MessageRecord]) -> None:
    """Write compact one-object-per-line JSON without schema changes."""

    record_path = Path(path)
    record_path.parent.mkdir(parents=True, exist_ok=True)
    data = "".join(
        json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n" for record in records
    )
    record_path.write_text(data, encoding="utf-8")


def _drop_to_first_task_prefix(records: list[MessageRecord]) -> list[MessageRecord]:
    if not records:
        return []
    if message_record_role(records[0]) in {"system", "user"}:
        return records
    for index, record in enumerate(records):
        if message_record_role(record) in {"system", "user"}:
            return records[index:]
    output = list(records)
    while output and message_record_role(output[0]) == "tool":
        output.pop(0)
    return output


def _leading_task_prefix_len(records: list[MessageRecord]) -> int:
    end = 0
    for record in records:
        if message_record_role(record) in {"system", "user"}:
            end += 1
            continue
        break
    return end


def repair_message_record_window(
    records: Iterable[MessageRecord],
    *,
    max_messages: int,
) -> list[MessageRecord]:
    """Bound a message history while retaining its task prefix and tool-call safety."""

    repaired = _drop_to_first_task_prefix(dedupe_message_records(records))
    if not repaired:
        return []
    if max_messages <= 0 or len(repaired) <= max_messages:
        return repaired
    prefix_end = _leading_task_prefix_len(repaired)
    if prefix_end <= 0:
        kept = repaired[-max_messages:]
        while kept and message_record_role(kept[0]) == "tool":
            kept = kept[1:]
        return kept
    tail_budget = max(0, max_messages - prefix_end)
    if tail_budget <= 0:
        return repaired[:max_messages]
    suffix = repaired[prefix_end:]
    start = max(0, len(suffix) - tail_budget)
    kept = suffix[start:]
    while start > 0 and kept and message_record_role(kept[0]) == "tool":
        start -= 1
        kept = suffix[start:]
    while kept and message_record_role(kept[0]) == "tool":
        kept = kept[1:]
    return repaired[:prefix_end] + kept


def message_record_window_score(records: list[MessageRecord]) -> tuple[int, int, int, int]:
    """Rank recovery windows without imposing an upper-layer selection policy."""

    if not records:
        return (0, 0, 0, 0)
    first_role = message_record_role(records[0])
    starts_with_task = 1 if first_role in {"system", "user"} else 0
    has_user = 1 if any(message_record_role(record) == "user" for record in records) else 0

    def contains_l0_anchor(record: MessageRecord) -> bool:
        try:
            return "l0_anchor_" in json.dumps(record, ensure_ascii=False, default=str)
        except TypeError:
            return "l0_anchor_" in str(record)

    has_l0 = 1 if any(contains_l0_anchor(record) for record in records) else 0
    not_tool_start = 1 if first_role != "tool" else 0
    return (starts_with_task, has_l0, has_user + not_tool_start, len(records))
