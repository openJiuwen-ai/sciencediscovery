"""Historical Pydantic memory records owned by InquiryCraft."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, ClassVar
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field

from inquirycraft.memory.message import ROLE_TYPE, Message


class MemoryRecord(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    message: Message
    role: ROLE_TYPE
    uuid: UUID = Field(default_factory=uuid4)
    extra_info: dict[str, Any] = Field(default_factory=dict)
    timestamp: float = Field(default_factory=lambda: datetime.now(timezone.utc).timestamp())
    agent_id: str = Field(default="")

    _MESSAGE_TYPES: ClassVar[dict[str, type[Message]]] = {"Message": Message}

    @classmethod
    def from_dict(cls, record_dict: dict[str, Any]) -> "MemoryRecord":
        message_cls = cls._MESSAGE_TYPES[record_dict["message"]["__class__"]]
        kwargs = record_dict["message"].copy()
        kwargs.pop("__class__")
        reconstructed_message = message_cls(**kwargs)
        return cls(
            uuid=UUID(record_dict["uuid"]),
            message=reconstructed_message,
            role=record_dict["role"],
            extra_info=record_dict["extra_info"],
            timestamp=record_dict["timestamp"],
            agent_id=record_dict["agent_id"],
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "uuid": str(self.uuid),
            "message": {
                "__class__": self.message.__class__.__name__,
                **self.message.to_dict(),
            },
            "role": self.role,
            "extra_info": self.extra_info,
            "timestamp": self.timestamp,
            "agent_id": self.agent_id,
        }

    def to_message_dict(self) -> dict[str, Any]:
        return self.message.to_dict()


class ContextRecord(BaseModel):
    memory_record: MemoryRecord
    score: float
    timestamp: float = Field(default_factory=lambda: datetime.now(timezone.utc).timestamp())
