"""Non-blocking OS locks; lock files stay in place to preserve inode identity."""

import errno
import os
from contextlib import contextmanager
from pathlib import Path


class FileInUseError(RuntimeError):
    """Another writer owns the requested file."""


def _set_lock(handle, *, acquire: bool) -> None:
    if os.name == 'nt':
        import msvcrt

        handle.seek(0)
        msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK if acquire else msvcrt.LK_UNLCK, 1)
    else:
        import fcntl

        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB if acquire else fcntl.LOCK_UN)


@contextmanager
def exclusive_file_lock(path: Path):
    """Release ownership on exit or process death, without deleting the lock file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor = os.open(path, os.O_CREAT | os.O_RDWR, 0o600)
    with os.fdopen(descriptor, 'r+b') as handle:
        if os.name == 'nt':
            if not os.fstat(handle.fileno()).st_size:
                handle.write(b'\0')
                handle.flush()
        try:
            _set_lock(handle, acquire=True)
        except OSError as exc:
            if exc.errno in {errno.EACCES, errno.EAGAIN, errno.EDEADLK}:
                raise FileInUseError(f'File is already in use by another writer: {path}') from exc
            raise
        try:
            yield
        finally:
            _set_lock(handle, acquire=False)
