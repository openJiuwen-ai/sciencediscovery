"""Canonical key-value storage contracts owned by InquiryCraft."""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from copy import deepcopy
from pathlib import Path
from typing import Any


class BaseKeyValueStorage(ABC):
    @abstractmethod
    def save(self, records: list[dict[str, Any]]) -> None:
        pass

    @abstractmethod
    def load(self) -> list[dict[str, Any]]:
        pass

    @abstractmethod
    def clear(self) -> None:
        pass


class InMemoryKeyValueStorage(BaseKeyValueStorage):
    def __init__(self) -> None:
        self.memory_list: list[dict] = []

    def save(self, records: list[dict[str, Any]]) -> None:
        self.memory_list.extend(deepcopy(records))

    def load(self) -> list[dict[str, Any]]:
        return deepcopy(self.memory_list)

    def clear(self) -> None:
        self.memory_list.clear()


class JsonKeyValueStorage(BaseKeyValueStorage):
    def __init__(
        self,
        path: str | None = "./chat_history.json",
        mode: str | None = "a",
    ) -> None:
        self.json_path = Path(path)
        self.json_path.parent.mkdir(parents=True, exist_ok=True)
        self.json_path.touch()
        if mode == "w":
            self.clear()

    def save(self, records: list[dict[str, Any]]) -> None:
        self.json_path.parent.mkdir(parents=True, exist_ok=True)
        with self.json_path.open("a", encoding="utf-8") as handle:
            handle.writelines([json.dumps(record, ensure_ascii=False) + "\n" for record in records])

    def load(self) -> list[dict[str, Any]]:
        if not self.json_path.exists():
            return []
        with self.json_path.open("r", encoding="utf-8") as handle:
            return [json.loads(record) for record in handle.readlines()]

    def clear(self) -> None:
        self.json_path.parent.mkdir(parents=True, exist_ok=True)
        with self.json_path.open("w"):
            pass
