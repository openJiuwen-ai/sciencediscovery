from __future__ import annotations

import hashlib
import logging
import re
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)


def _safe_prefix(value: str) -> str:
    text = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value or "")).strip("._-")
    return f"{text}_" if text and not text.endswith("_") else text


def _safe_tool_name(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", str(name or "tool")).strip("._-") or "tool"


def _safe_value(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.:-]+", "_", str(value or "none")).strip("_") or "none"


@dataclass(frozen=True, slots=True)
class ToolOutputArtifactRef:
    seq: int
    raw_id: str
    tool_name: str
    raw_chars: int
    sha256_short: str


class RawToolOutputStore:
    """Append-only raw output and deterministic index store."""

    def __init__(
        self,
        workspace_dir: str | Path,
        *,
        output_parts: tuple[str, ...] | None = None,
        mirror_parts: tuple[str, ...] | None = None,
        mirror_raw_id_prefix: str = "",
        log_dir_override: str | Path | None = None,
    ) -> None:
        self.workspace_dir = Path(workspace_dir)
        self.output_parts = tuple(output_parts or ("tool_outputs",))
        self.mirror_parts = tuple(mirror_parts or ())
        self.mirror_raw_id_prefix = _safe_prefix(mirror_raw_id_prefix)
        log_dir = (
            Path(log_dir_override) if log_dir_override is not None else self.workspace_dir / ".logs"
        )
        self.output_dir = log_dir.joinpath(*self.output_parts)
        self.mirror_output_dir = log_dir.joinpath(*self.mirror_parts) if self.mirror_parts else None
        self.index_path = self.output_dir / "index.txt"
        self.stage_log_dir: Path | None = None
        self._next_seq = self._discover_next_seq()

    def set_mirror_raw_id_prefix(self, prefix: str) -> None:
        self.mirror_raw_id_prefix = _safe_prefix(prefix)

    def set_stage_log_dir(self, path: str | Path | None) -> None:
        self.stage_log_dir = Path(path) if path is not None and str(path).strip() else None

    def _mirror_raw_id(self, raw_id: str) -> str:
        prefix = self.mirror_raw_id_prefix
        return f"{prefix}{raw_id}" if prefix else raw_id

    def _discover_next_seq(self) -> int:
        try:
            if not self.output_dir.is_dir():
                return 1
            maximum = 0
            for path in self.output_dir.glob("tool_*.txt"):
                match = re.match(r"^tool_(\d{6})_", path.name)
                if match:
                    maximum = max(maximum, int(match.group(1)))
            return maximum + 1
        except Exception:
            logger.debug("tool output artifact seq discovery failed", exc_info=True)
            return 1

    def reserve(self, tool_name: str, raw_text: str) -> ToolOutputArtifactRef | None:
        try:
            safe_tool = _safe_tool_name(tool_name)
            seq = self._next_seq
            self._next_seq += 1
            raw_id = f"tool_{seq:06d}_{safe_tool}.txt"
            digest = hashlib.sha256(raw_text.encode("utf-8", errors="replace")).hexdigest()[:16]
            return ToolOutputArtifactRef(
                seq=seq,
                raw_id=raw_id,
                tool_name=safe_tool,
                raw_chars=len(raw_text),
                sha256_short=digest,
            )
        except Exception:
            logger.debug("tool output artifact reserve failed", exc_info=True)
            return None

    def write_raw(self, ref: ToolOutputArtifactRef, raw_text: str) -> bool:
        try:
            self.output_dir.mkdir(parents=True, exist_ok=True)
            (self.output_dir / ref.raw_id).write_text(raw_text, encoding="utf-8", errors="replace")
            if self.mirror_output_dir is not None:
                self.mirror_output_dir.mkdir(parents=True, exist_ok=True)
                (self.mirror_output_dir / self._mirror_raw_id(ref.raw_id)).write_text(
                    raw_text, encoding="utf-8", errors="replace"
                )
            return True
        except Exception:
            logger.debug("tool output artifact write failed", exc_info=True)
            return False

    def append_index(
        self,
        ref: ToolOutputArtifactRef,
        *,
        reducer_name: str,
        compressed_chars: int,
    ) -> None:
        try:
            self.output_dir.mkdir(parents=True, exist_ok=True)
            line = (
                f"seq={ref.seq} raw_id={ref.raw_id} tool={ref.tool_name} "
                f"raw_chars={ref.raw_chars} compressed_chars={int(compressed_chars)} "
                f"sha256={ref.sha256_short} reducer={_safe_value(reducer_name)}"
            )
            with self.index_path.open("a", encoding="utf-8") as stream:
                stream.write(line + "\n")
            if self.mirror_output_dir is not None:
                self.mirror_output_dir.mkdir(parents=True, exist_ok=True)
                mirror_raw_id = self._mirror_raw_id(ref.raw_id)
                mirror_line = (
                    f"seq={ref.seq} raw_id={mirror_raw_id} source_raw_id={ref.raw_id} "
                    f"tool={ref.tool_name} raw_chars={ref.raw_chars} "
                    f"compressed_chars={int(compressed_chars)} sha256={ref.sha256_short} "
                    f"reducer={_safe_value(reducer_name)}"
                )
                with (self.mirror_output_dir / "index.txt").open("a", encoding="utf-8") as stream:
                    stream.write(mirror_line + "\n")
        except Exception:
            logger.debug("tool output artifact index append failed", exc_info=True)
