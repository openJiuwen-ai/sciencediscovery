from __future__ import annotations

from collections.abc import Callable
from typing import Any

from ..base import ToolResult

ToolOutputReducer = Callable[..., tuple[str, str]]


class ToolOutputReducerRegistry:
    """Host-configured reducer lookup without domain-specific policies."""

    def __init__(self) -> None:
        self._reducers: dict[str, ToolOutputReducer] = {}

    def register(self, tool_name: str, reducer: ToolOutputReducer) -> None:
        name = str(tool_name or "").strip()
        if not name:
            raise ValueError("tool_name must not be empty")
        self._reducers[name] = reducer

    def reduce(
        self,
        *,
        tool_name: str,
        args: dict[str, Any],
        feedback: str,
        raw_text: str,
        tool_error: bool,
        result: ToolResult | None = None,
    ) -> tuple[str, str]:
        reducer = self._reducers.get(str(tool_name or "").strip())
        if reducer is None:
            return feedback, "none"
        return reducer(
            args=args,
            feedback=feedback,
            raw_text=raw_text,
            tool_error=tool_error,
            result=result,
        )
