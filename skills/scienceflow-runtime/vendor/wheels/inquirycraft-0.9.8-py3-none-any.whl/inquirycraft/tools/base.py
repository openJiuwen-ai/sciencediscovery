from __future__ import annotations

import inspect
from abc import ABC
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field, replace
from enum import Enum
from pathlib import Path
from typing import Any, ClassVar, Literal, Mapping

from inquirycraft.events import EventSink
from inquirycraft.runtime.cancellation import CancellationToken


@dataclass(frozen=True, slots=True)
class ToolContext:
    session_id: str
    run_id: str
    agent_id: str
    workspace: Path
    event_sink: EventSink
    cancellation: CancellationToken
    metadata: Mapping[str, Any] = field(default_factory=dict)
    on_update: Callable[[str], Awaitable[None]] | None = None

    async def report_progress(self, chunk: str) -> None:
        if self.on_update is not None:
            await self.on_update(chunk)


@dataclass
class ToolResult:
    """Tool outcome shared by the runtime and compatibility adapters.

    ``system`` carries lossless output that should be persisted but not rendered
    into the model conversation. It deliberately does not participate in
    :meth:`render`, preserving model-visible context behavior.
    """

    output: Any = None
    error: str | None = None
    system: str | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)

    model_fields: ClassVar[dict[str, None]] = dict.fromkeys("output error system".split())

    @property
    def is_error(self) -> bool:
        return self.error is not None

    def render(self) -> str:
        if self.error and self.output:
            return f"Error: {self.error}\n{self.output}"
        if self.error:
            return f"Error: {self.error}"
        return str(self.output or "")

    def __bool__(self) -> bool:
        return bool(self.output or self.error or self.system)

    def __str__(self) -> str:
        return self.render()

    def __add__(self, other: "ToolResult") -> "ToolResult":
        def combine_fields(
            value: str | None,
            other_value: str | None,
            *,
            concatenate: bool = True,
        ) -> str | None:
            if value and other_value:
                if concatenate:
                    return value + other_value
                raise ValueError("Cannot combine tool results")
            return value or other_value

        return ToolResult(
            output=combine_fields(self.output, other.output),
            error=combine_fields(self.error, other.error),
            system=combine_fields(self.system, other.system),
        )

    def replace(self, **changes: Any) -> "ToolResult":
        return replace(self, **changes)

    def model_copy(self, *, update: Mapping[str, Any] | None = None) -> "ToolResult":
        """Small compatibility equivalent of Pydantic's ``model_copy``."""
        return self.replace(**dict(update or {}))

    def model_dump(self, *, exclude_none: bool = False, **_: Any) -> dict[str, Any]:
        row = {"output": self.output, "error": self.error, "system": self.system}
        return (
            {key: value for key, value in row.items() if value is not None} if exclude_none else row
        )


class CLIResult(ToolResult):
    """A tool result that can be rendered as CLI output."""


class ToolFailure(ToolResult):
    """A recoverable tool failure."""


class ToolError(Exception):
    """A user-visible tool execution error."""

    def __init__(self, message: str):
        self.message = message


class ToolChoice(str, Enum):
    NONE = "none"
    AUTO = "auto"
    REQUIRED = "required"


TOOL_CHOICE_VALUES = tuple(choice.value for choice in ToolChoice)
TOOL_CHOICE_TYPE = Literal[TOOL_CHOICE_VALUES]  # type: ignore[valid-type]


def _tool_field(kind: str, description: str = "") -> dict[str, str]:
    field = {"type": kind}
    if description:
        field["description"] = description
    return field


def _tool_schema(*required: str, closed: bool = False, **properties: Any) -> dict[str, Any]:
    schema = {"type": "object", "properties": properties, "required": list(required)}
    if closed:
        schema["additionalProperties"] = False
    return schema


def coerce_tool_result(value: Any) -> ToolResult:
    if isinstance(value, ToolResult):
        return value
    if all(hasattr(value, name) for name in ("output", "error", "system")):
        return ToolResult(output=value.output, error=value.error, system=value.system)
    return ToolResult(output=str(value))


class BaseTool(ABC):
    """Canonical tool contract supporting context-aware and kwargs tools."""

    name: ClassVar[str]
    description: ClassVar[str]
    input_schema: ClassVar[Mapping[str, Any]] = {}
    execution_mode: ClassVar[Literal["sequential", "parallel"]] = "parallel"
    replay_policy: ClassVar[Literal["safe", "never"]] = "never"

    def _schema(self) -> Mapping[str, Any]:
        parameters = getattr(self, "parameters", None)
        return parameters if parameters is not None else getattr(self, "input_schema", {})

    def to_openai(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": dict(self._schema()),
            },
        }

    def to_param(self) -> dict[str, Any]:
        """Compatibility name used by pre-1.0 InquiryCraft tool collections."""
        return self.to_openai()

    def prepare_arguments(self, arguments: Mapping[str, Any]) -> Mapping[str, Any]:
        """Normalize historical input before validation."""

        return dict(arguments)

    async def __call__(self, **kwargs: Any) -> Any:
        """Call historical keyword-style tools directly."""
        return await self.execute(**kwargs)

    async def invoke(
        self,
        arguments: Mapping[str, Any],
        context: ToolContext | None = None,
        **kwargs: Any,
    ) -> Any:
        """Invoke either the canonical or historical keyword execution shape."""

        parameters = inspect.signature(self.execute).parameters
        if "arguments" in parameters and "context" in parameters:
            if context is None:
                raise TypeError(f"Tool {self.name!r} requires a ToolContext")
            return await self.execute(arguments, context)
        return await self.execute(**dict(arguments), **kwargs)

    async def execute(self, *args: Any, **kwargs: Any) -> Any:
        raise NotImplementedError
