"""Streaming foreground shell execution with lossless output artifacts.

This executor is only used by the ordinary chat ShellTool. It does not retry
commands or change the resource/deadline policies of host-managed research tools.
"""

from __future__ import annotations

import asyncio
import codecs
import hashlib
import math
import os
import signal
import time
from contextlib import ExitStack
from pathlib import Path
from typing import Any, Mapping
from uuid import uuid4

from .base import ToolContext, ToolResult
from .path_policy import PathGuard

OUTPUT_TAIL_BYTES = 32_768
DRAIN_GRACE_SECONDS = 2.0


class _Output:
    def __init__(self, stack: ExitStack, path: Path, workspace: Path):
        self.path = str(path.relative_to(workspace))
        self.file = stack.enter_context(os.fdopen(
            os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), 'wb'
        ))
        self.tail = bytearray()
        self.size = 0
        self.digest = hashlib.sha256()

    async def read(self, stream: asyncio.StreamReader, context: ToolContext):
        decoder = codecs.getincrementaldecoder('utf-8')(errors='replace')
        while chunk := await stream.read(8192):
            self.file.write(chunk)
            self.file.flush()
            self.size += len(chunk)
            self.digest.update(chunk)
            self.tail.extend(chunk)
            del self.tail[:-OUTPUT_TAIL_BYTES]
            text = decoder.decode(chunk)
            if text:
                await context.report_progress(text)
        remaining = decoder.decode(b'', final=True)
        if remaining:
            await context.report_progress(remaining)

    def preview(self):
        text = self.tail.decode('utf-8', errors='replace')
        if self.size > len(self.tail):
            text = f'[showing last {len(self.tail)} of {self.size} bytes; full output: {self.path}]\n{text}'
        return text

    def reference(self):
        return {'path': self.path, 'bytes': self.size, 'sha256': self.digest.hexdigest()}


def _kill_tree(process):
    from inquirycraft.runtime.subprocess import _psutil_kill_children

    # Reuse the runtime's best-effort descendant snapshot while the leader
    # still exists, including children that escaped the original session.
    _psutil_kill_children(process.pid)
    try:
        if os.name == 'posix':
            # The shell starts a new session; this also kills its descendants
            # after the group leader has already exited.
            os.killpg(process.pid, signal.SIGKILL)
        elif process.returncode is None:
            process.kill()
    except ProcessLookupError:
        pass


async def _wait_for_exit(process):
    # Process.wait() can wait for EOF on inherited pipes even after the shell
    # exits. Observe the exit code independently, then drain pipes separately.
    while process.returncode is None:
        await asyncio.sleep(0.02)


async def _drain(process, readers):
    done, pending = await asyncio.wait(readers, timeout=DRAIN_GRACE_SECONDS)
    if pending:
        _kill_tree(process)
        done, pending = await asyncio.wait(readers, timeout=DRAIN_GRACE_SECONDS)
    for reader in pending:
        reader.cancel()
    results = await asyncio.gather(*readers, return_exceptions=True)
    for result in results:
        if isinstance(result, Exception):
            raise result
    return not pending


async def run_shell(arguments: Mapping[str, Any], context: ToolContext) -> ToolResult:
    from inquirycraft.runtime.subprocess import spawn_shell, unregister_process_group

    command = str(arguments.get('command') or '').strip()
    if not command:
        return ToolResult(error='command is required')
    timeout = arguments.get('timeout')
    if timeout is not None:
        try:
            timeout = float(timeout)
        except (ValueError, TypeError):
            return ToolResult(error='timeout must be a finite number between 0.1 and 3600 seconds')
        if not math.isfinite(timeout) or not 0.1 <= timeout <= 3600:
            return ToolResult(error='timeout must be a finite number between 0.1 and 3600 seconds')
    if context.cancellation.cancelled:
        return ToolResult(error='command cancelled', metadata={'shell_execution': {'status': 'cancelled'}})

    started = time.monotonic()
    workspace = context.workspace.resolve()
    directory = PathGuard(workspace).resolve(f'.logs/shell_outputs/{uuid4().hex}')
    directory.mkdir(mode=0o700, parents=True)
    with ExitStack() as stack:
        stdout = _Output(stack, directory / 'stdout.log', workspace)
        stderr = _Output(stack, directory / 'stderr.log', workspace)
        try:
            spawn = asyncio.create_task(spawn_shell(
                command, cwd=workspace, stdin=asyncio.subprocess.DEVNULL,
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            ))
            try:
                process = await asyncio.shield(spawn)
            except asyncio.CancelledError:
                # A cancellation during spawn must still acquire the process
                # handle so it can be terminated and its tool result settled.
                context.cancellation.cancel()
                process = await spawn
        except (OSError, ValueError) as exc:
            return ToolResult(error=f'command could not start: {type(exc).__name__}: {exc}', metadata={
                'shell_execution': {
                    'status': 'spawn_failed', 'exit_code': None, 'timeout_sec': timeout,
                    'elapsed_sec': time.monotonic() - started,
                    'stdout': stdout.reference(), 'stderr': stderr.reference(),
                },
            })

        readers = [asyncio.create_task(output.read(stream, context)) for output, stream in (
            (stdout, process.stdout), (stderr, process.stderr)
        )]
        exited = asyncio.create_task(_wait_for_exit(process))
        cancelled = asyncio.create_task(context.cancellation.wait())
        status = 'exited'
        complete = False
        try:
            done, _ = await asyncio.wait(
                {exited, cancelled, *readers}, timeout=timeout,
                return_when=asyncio.FIRST_COMPLETED,
            )
            # A stream can reach EOF before the process exits. Do not confuse
            # that with command completion, and fail promptly on reader errors.
            while exited not in done and cancelled not in done and done:
                for reader in done.intersection(readers):
                    reader.result()
                remaining = None if timeout is None else max(0, timeout - (time.monotonic() - started))
                live = {exited, cancelled, *(reader for reader in readers if not reader.done())}
                done, _ = await asyncio.wait(live, timeout=remaining, return_when=asyncio.FIRST_COMPLETED)
            if exited in done:
                status = 'failed' if process.returncode else 'exited'
            elif cancelled in done:
                status = 'cancelled'
                _kill_tree(process)
            else:
                status = 'timed_out'
                _kill_tree(process)
            complete = await _drain(process, readers)
        except asyncio.CancelledError:
            # Settle the tool result before the runtime observes cancellation,
            # so its journal and conversation keep the original tool-call pair.
            context.cancellation.cancel()
            status = 'cancelled'
            _kill_tree(process)
            complete = await _drain(process, readers)
        finally:
            if process.returncode is None:
                _kill_tree(process)
            for task in (exited, cancelled, *readers):
                if not task.done():
                    task.cancel()
            await asyncio.gather(exited, cancelled, *readers, return_exceptions=True)
            # Readers were drained or cancelled before closing their log files.
            try:
                await asyncio.wait_for(process.wait(), timeout=DRAIN_GRACE_SECONDS)
            finally:
                unregister_process_group(process.pid)

        metadata = {
            'status': status, 'exit_code': process.returncode, 'timeout_sec': timeout,
            'process_group_id': process.pid,
            'elapsed_sec': time.monotonic() - started, 'output_complete': complete,
            'stdout': stdout.reference(), 'stderr': stderr.reference(),
        }
        output = stdout.preview()
        if stderr.size:
            output += ('\n' if output else '') + '[stderr]\n' + stderr.preview()
        error = None
        if status == 'timed_out':
            error = f'command timed out after {timeout:g}s'
        elif status == 'cancelled':
            error = 'command cancelled'
        elif process.returncode:
            error = f'exit {process.returncode}'
        if not complete:
            error = error or 'command output did not finish draining'
        return ToolResult(output=output, error=error, metadata={'shell_execution': metadata})
