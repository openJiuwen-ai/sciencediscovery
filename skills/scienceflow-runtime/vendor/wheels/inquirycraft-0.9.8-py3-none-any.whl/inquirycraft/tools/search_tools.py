"""Configurable filesystem search and listing tools."""

from __future__ import annotations

from typing import Any

from .base import ToolResult, _tool_field, _tool_schema
from .file_tools import FileTool
from .filesystem import glob_paths, grep_path, list_path


class GrepTool(FileTool):
    name = "grep"
    description = (
        "Search for a regex pattern under the workspace. "
        "Uses ripgrep (rg) and returns matching lines with file paths and line numbers."
    )
    parameters = _tool_schema(
        "pattern",
        pattern=_tool_field("string", "Regular expression to search for."),
        path=_tool_field("string", "File or directory relative to workspace. Default '.'"),
        include=_tool_field("string", "Optional glob passed to rg -g, e.g. '*.py'."),
        file_type=_tool_field("string", "Optional ripgrep file type passed to rg -t, e.g. 'py'."),
    )
    defaults = {**FileTool.defaults, "max_results_lines": 50}

    async def execute(
        self,
        pattern: str,
        path: str = ".",
        include: str = "",
        file_type: str = "",
        **kwargs: Any,
    ) -> ToolResult:
        kwargs.pop("config", None)
        return await grep_path(
            self.root_dir,
            pattern,
            path=path,
            include=include,
            file_type=file_type,
            max_results_lines=self.max_results_lines,
            sandbox=self.sandbox,
            extra_roots=self.path_guard_extra_roots,
            denied_prefixes=self.path_guard_denied_prefixes,
            logical_paths=bool(self.display_paths_relative),
            display_root=self.display_root,
            result_factory=ToolResult,
            path_policy=self.path_policy,
        )


class GlobTool(FileTool):
    name = "glob"
    description = (
        "Find files and optionally directories under the workspace using a glob pattern. "
        "Use patterns like '*.py', '**/*.csv', or 'dataset/**/*.json'."
    )
    parameters = _tool_schema(
        "pattern",
        pattern=_tool_field("string", "Glob pattern relative to path, e.g. '*.py' or '**/*.csv'."),
        path=_tool_field("string", "Directory to search, relative to workspace. Default '.'."),
        include_dirs=_tool_field(
            "boolean", "Whether to include matching directories. Default false."
        ),
        include_hidden=_tool_field(
            "boolean",
            "Whether to include dotfiles and files inside dot directories. Default false.",
        ),
        limit=_tool_field("integer", "Maximum matches to return. Default 200."),
    )
    defaults = {**FileTool.defaults, "max_results": 1000}

    async def execute(
        self,
        pattern: str,
        path: str = ".",
        include_dirs: bool = False,
        include_hidden: bool = False,
        limit: int = 200,
        **kwargs: Any,
    ) -> ToolResult:
        kwargs.pop("config", None)
        return glob_paths(
            self.root_dir,
            pattern,
            path=path,
            include_dirs=include_dirs,
            include_hidden=include_hidden,
            limit=limit,
            max_results=self.max_results,
            sandbox=self.sandbox,
            extra_roots=self.path_guard_extra_roots,
            denied_prefixes=self.path_guard_denied_prefixes,
            logical_paths=bool(self.display_paths_relative),
            display_root=self.display_root,
            result_factory=ToolResult,
            path_policy=self.path_policy,
        )


class LsTool(FileTool):
    name = "ls"
    description = (
        "List files and directories under a workspace path with stable ordering. "
        "Use recursive=true and depth to inspect nested directories."
    )
    parameters = _tool_schema(
        path=_tool_field("string", "File or directory path relative to workspace. Default '.'."),
        recursive=_tool_field("boolean", "Whether to recurse into subdirectories. Default false."),
        depth=_tool_field("integer", "Maximum recursion depth when recursive=true. Default 2."),
        include_hidden=_tool_field(
            "boolean", "Whether to include dotfiles and dot directories. Default false."
        ),
        limit=_tool_field("integer", "Maximum entries to return. Default 200."),
    )
    defaults = {**FileTool.defaults, "max_results": 1000, "max_depth": 8}

    async def execute(
        self,
        path: str = ".",
        recursive: bool = False,
        depth: int = 2,
        include_hidden: bool = False,
        limit: int = 200,
        **kwargs: Any,
    ) -> ToolResult:
        kwargs.pop("config", None)
        return list_path(
            self.root_dir,
            path=path,
            recursive=recursive,
            depth=depth,
            include_hidden=include_hidden,
            limit=limit,
            max_results=self.max_results,
            max_depth=self.max_depth,
            sandbox=self.sandbox,
            extra_roots=self.path_guard_extra_roots,
            denied_prefixes=self.path_guard_denied_prefixes,
            logical_paths=bool(self.display_paths_relative),
            display_root=self.display_root,
            result_factory=ToolResult,
            path_policy=self.path_policy,
        )
