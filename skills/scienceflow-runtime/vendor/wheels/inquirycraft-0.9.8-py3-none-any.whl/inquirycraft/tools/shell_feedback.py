"""Stable model-visible feedback for managed shell execution."""

from __future__ import annotations

from .base import ToolResult


def build_spawn_failure_tool_result(
    exc: Exception,
    *,
    elapsed_sec: float,
) -> ToolResult:
    reason = f"{type(exc).__name__}: {exc}".strip()
    block = "\n".join(
        [
            f"[spawn-failed, {max(0.0, elapsed_sec):.1f}s]",
            (
                "[infra-error] Bash could not start a subprocess. "
                "This is an infrastructure/resource pressure signal, not evidence "
                "about the solution quality."
            ),
            f"reason: {reason}",
            (
                "Continue the search until the wall-clock budget expires; wait, retry, "
                "or reduce local concurrency before running another heavy command."
            ),
        ]
    )
    return ToolResult(output=block, error=f"bash spawn failed: {type(exc).__name__}")


def build_command_timeout_feedback(
    *,
    timeout_sec: float,
    resource_class: str = "",
    gpu_ids: list[str] | None = None,
    saw_progress: bool = False,
    saw_artifact: bool = False,
    current_phase: str = "",
) -> str:
    timeout = max(0.0, float(timeout_sec or 0.0))
    cls = str(resource_class or "unknown")
    ids = [str(value) for value in (gpu_ids or []) if str(value).strip()]
    phase = str(current_phase or "unknown")
    progress = "yes" if saw_progress else "no"
    artifact = "yes" if saw_artifact else "no"
    location = f" on GPU {','.join(ids)}" if ids else ""
    if saw_progress or saw_artifact:
        reason = (
            "it was still running when the bash budget ended, "
            "so the run was too large for one command budget"
        )
    else:
        reason = (
            "no useful progress finished before the bash budget ended, "
            "so the run was too large or too quiet for one command budget"
        )
    return (
        f"RESOURCE_FEEDBACK: command timed out because the {timeout:.0f}s bash budget was exhausted "
        f"while {cls}{location} was in phase {phase}; progress_seen={progress}, "
        f"artifact_seen={artifact}; {reason}.\n"
    )
