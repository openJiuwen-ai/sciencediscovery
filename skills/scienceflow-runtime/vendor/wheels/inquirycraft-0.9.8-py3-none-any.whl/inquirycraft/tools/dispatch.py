from __future__ import annotations

from collections.abc import Awaitable, Callable, Sequence
from typing import Any, Literal, TypeVar

from .tool_calls import tool_call_arguments_dict, tool_call_function_name

ToolBundleMode = Literal[
    "single",
    "parallel_readonly",
    "parallel_bash",
    "blocked_write_edit_bundle",
    "sequential",
]

_T = TypeVar("_T")
_R = TypeVar("_R")


def classify_tool_call_bundle(
    tool_calls: Sequence[Any],
    *,
    readonly_tool_names: frozenset[str] | set[str],
    mutation_tool_names: frozenset[str] | set[str],
    force_sequential: bool = False,
    parallel_bash_enabled: bool = False,
    bash_parallel_safe: Callable[[str], bool] | None = None,
) -> ToolBundleMode:
    """Classify an OpenAI-style tool-call bundle without executing it.

    The runtime mechanism is domain-neutral: callers provide the tool policy sets
    and the shell safety predicate.  The returned mode deliberately contains no
    logging, memory, budget, or workspace side effects.
    """

    if len(tool_calls) <= 1:
        return "single"
    if force_sequential:
        return "sequential"

    names = [tool_call_function_name(call, allow_mapping=False) or "" for call in tool_calls]
    if any(name in mutation_tool_names for name in names):
        return "blocked_write_edit_bundle"
    if all(name in readonly_tool_names for name in names):
        return "parallel_readonly"
    if (
        parallel_bash_enabled
        and bash_parallel_safe is not None
        and all(name == "bash" for name in names)
    ):
        commands = [
            str(tool_call_arguments_dict(call, allow_mapping=False).get("command") or "").strip()
            for call in tool_calls
        ]
        if all(bash_parallel_safe(command) for command in commands):
            return "parallel_bash"
    return "sequential"


async def execute_concurrently_in_order(
    items: Sequence[_T],
    runner: Callable[[_T], Awaitable[_R]],
) -> list[_R]:
    """Run independent items concurrently while preserving their input order."""

    import asyncio

    return list(await asyncio.gather(*(runner(item) for item in items)))
