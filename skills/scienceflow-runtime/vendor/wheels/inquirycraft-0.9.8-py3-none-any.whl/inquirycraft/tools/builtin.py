from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

from .base import BaseTool, ToolContext, ToolResult, _tool_field, _tool_schema
from .path_policy import PathGuard, atomic_write


def _workspace_path(context: ToolContext, raw: Any):
    value = str(raw or "").strip()
    if not value:
        raise ValueError("path is required")
    if Path(value).is_absolute():
        raise ValueError("absolute paths are not allowed")
    return PathGuard(context.workspace).resolve(value)


class ReadTextTool(BaseTool):
    name = "read_text"
    description = "Read a UTF-8 text file inside the workspace."
    input_schema = _tool_schema("path", closed=True, path=_tool_field("string"))

    async def execute(self, arguments: Mapping[str, Any], context: ToolContext) -> ToolResult:
        path = _workspace_path(context, arguments.get("path"))
        return ToolResult(output=path.read_text(encoding="utf-8"))


class WriteTextTool(BaseTool):
    name = "write_text"
    description = "Write a UTF-8 text file inside the workspace."
    input_schema = _tool_schema(
        "path", "content", closed=True, path=_tool_field("string"), content=_tool_field("string")
    )

    async def execute(self, arguments: Mapping[str, Any], context: ToolContext) -> ToolResult:
        path = _workspace_path(context, arguments.get("path"))
        content = str(arguments.get("content", ""))
        atomic_write(path, content)
        return ToolResult(
            output=f"wrote {len(content.encode('utf-8'))} bytes to {path.relative_to(context.workspace.resolve())}"
        )


class ShellTool(BaseTool):
    name = "shell"
    description = (
        "Run a foreground shell command in the workspace and stream its output. "
        "No default timeout; optionally provide timeout in seconds."
    )
    input_schema = _tool_schema(
        "command",
        closed=True,
        command=_tool_field("string"),
        timeout={"type": "number", "minimum": 0.1, "maximum": 3600,
                 "description": "Optional timeout in seconds; no default timeout."},
    )

    async def execute(self, arguments: Mapping[str, Any], context: ToolContext) -> ToolResult:
        from .shell_execution import run_shell

        return await run_shell(arguments, context)


def default_tools():
    from .collection import ToolCollection

    return ToolCollection((ReadTextTool(), WriteTextTool(), ShellTool()))
