from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any


def _field(value: Any, name: str, *, allow_mapping: bool) -> Any:
    if allow_mapping and isinstance(value, Mapping):
        return value.get(name)
    return getattr(value, name, None)


def tool_call_function_name(
    tool_call: Any,
    *,
    allow_mapping: bool = True,
) -> str | None:
    """Read an OpenAI-style function name from mappings or SDK objects."""

    function = _field(tool_call, "function", allow_mapping=allow_mapping)
    name = _field(function, "name", allow_mapping=allow_mapping)
    return str(name) if name else None


def tool_call_arguments_dict(
    tool_call: Any,
    *,
    allow_mapping: bool = True,
) -> dict[str, Any]:
    """Leniently decode OpenAI-style tool arguments.

    Legacy runtimes treat missing, malformed, and non-object arguments as an
    empty mapping while deciding whether a compatibility rewrite is possible.
    Execution-time validation remains the responsibility of ``ToolInvocation``.
    """

    function = _field(tool_call, "function", allow_mapping=allow_mapping)
    raw = _field(function, "arguments", allow_mapping=allow_mapping)
    if allow_mapping and isinstance(raw, Mapping):
        return dict(raw)
    if not isinstance(raw, str):
        raw = str(raw or "{}")
    try:
        value = json.loads(raw or "{}")
    except (json.JSONDecodeError, TypeError, ValueError):
        return {}
    return value if isinstance(value, dict) else {}
