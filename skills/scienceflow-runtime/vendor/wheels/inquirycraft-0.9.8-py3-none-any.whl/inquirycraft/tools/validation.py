from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any, Protocol, runtime_checkable


class ToolArgumentValidationError(ValueError):
    """Raised when model-provided tool arguments do not match the tool schema."""


@runtime_checkable
class ToolArgumentValidator(Protocol):
    def validate(self, arguments: Mapping[str, Any], schema: Mapping[str, Any]) -> None: ...


class BuiltinToolArgumentValidator:
    """Dependency-free validator for the JSON Schema subset used by tools.

    Unsupported assertion keywords fail closed instead of being silently ignored.
    Annotation keywords are accepted.
    """

    _ANNOTATIONS = {"description", "title", "default", "examples", "$schema"}
    _SUPPORTED = frozenset(
        "type properties required additionalProperties items enum const minimum maximum "
        "minLength maxLength minItems maxItems anyOf oneOf allOf".split()
    )

    def validate(self, arguments: Mapping[str, Any], schema: Mapping[str, Any]) -> None:
        self._validate_value(arguments, schema, path="arguments")

    def _validate_value(self, value: Any, schema: Mapping[str, Any], *, path: str) -> None:
        unknown = set(schema) - self._SUPPORTED - self._ANNOTATIONS
        if unknown:
            names = ", ".join(sorted(unknown))
            raise ToolArgumentValidationError(f"{path}: unsupported schema keyword(s): {names}")

        if "const" in schema and value != schema["const"]:
            raise ToolArgumentValidationError(f"{path}: must equal {schema['const']!r}")
        if "enum" in schema and value not in schema["enum"]:
            raise ToolArgumentValidationError(f"{path}: must be one of {list(schema['enum'])!r}")

        for keyword in ("allOf", "anyOf", "oneOf"):
            if keyword not in schema:
                continue
            children = schema[keyword]
            if not isinstance(children, Sequence) or isinstance(children, (str, bytes)):
                raise ToolArgumentValidationError(f"{path}: {keyword} must be an array")
            matches = sum(self._matches(value, child, path) for child in children)
            if keyword == "allOf" and matches != len(children):
                raise ToolArgumentValidationError(f"{path}: does not match every allOf schema")
            if keyword == "anyOf" and matches == 0:
                raise ToolArgumentValidationError(f"{path}: does not match any allowed schema")
            if keyword == "oneOf" and matches != 1:
                raise ToolArgumentValidationError(f"{path}: must match exactly one schema")

        expected = schema.get("type")
        if expected is not None and not self._has_type(value, expected):
            raise ToolArgumentValidationError(
                f"{path}: expected {expected}, got {type(value).__name__}"
            )
        if expected == "object" or isinstance(value, Mapping):
            self._validate_object(value, schema, path=path)
        elif expected == "array" or isinstance(value, list):
            self._validate_array(value, schema, path=path)
        elif expected == "string" or isinstance(value, str):
            self._validate_string(value, schema, path=path)
        elif expected in {"number", "integer"} or self._is_number(value):
            self._validate_number(value, schema, path=path)

    def _matches(self, value: Any, schema: Any, path: str) -> bool:
        if not isinstance(schema, Mapping):
            raise ToolArgumentValidationError(f"{path}: child schema must be an object")
        try:
            self._validate_value(value, schema, path=path)
        except ToolArgumentValidationError:
            return False
        return True

    @staticmethod
    def _is_number(value: Any) -> bool:
        return isinstance(value, (int, float)) and not isinstance(value, bool)

    def _has_type(self, value: Any, expected: Any) -> bool:
        if isinstance(expected, list):
            return any(self._has_type(value, child) for child in expected)
        checks = {
            "object": lambda: isinstance(value, Mapping),
            "array": lambda: isinstance(value, list),
            "string": lambda: isinstance(value, str),
            "number": lambda: self._is_number(value),
            "integer": lambda: isinstance(value, int) and not isinstance(value, bool),
            "boolean": lambda: isinstance(value, bool),
            "null": lambda: value is None,
        }
        if expected not in checks:
            raise ToolArgumentValidationError(f"unsupported schema type: {expected!r}")
        return checks[expected]()

    def _validate_object(self, value: Any, schema: Mapping[str, Any], *, path: str) -> None:
        if not isinstance(value, Mapping):
            return
        properties = schema.get("properties") or {}
        required = schema.get("required") or ()
        if not isinstance(properties, Mapping):
            raise ToolArgumentValidationError(f"{path}: properties must be an object")
        if not isinstance(required, Sequence) or isinstance(required, (str, bytes)):
            raise ToolArgumentValidationError(f"{path}: required must be an array")
        missing = [name for name in required if name not in value]
        if missing:
            raise ToolArgumentValidationError(
                f"{path}: missing required field(s): {', '.join(missing)}"
            )
        additional = schema.get("additionalProperties", True)
        extras = sorted(str(name) for name in set(value) - set(properties))
        if additional is False:
            if extras:
                raise ToolArgumentValidationError(
                    f"{path}: unexpected field(s): {', '.join(extras)}"
                )
        elif isinstance(additional, Mapping):
            for name in extras:
                self._validate_value(value[name], additional, path=f"{path}.{name}")
        elif additional is not True:
            raise ToolArgumentValidationError(
                f"{path}: additionalProperties must be a boolean or schema"
            )
        for name, child in properties.items():
            if not isinstance(child, Mapping):
                raise ToolArgumentValidationError(f"{path}.{name}: schema must be an object")
            if name in value:
                self._validate_value(value[name], child, path=f"{path}.{name}")

    def _validate_array(self, value: Any, schema: Mapping[str, Any], *, path: str) -> None:
        if not isinstance(value, list):
            return
        self._check_bounds(len(value), schema, path, "Items")
        child = schema.get("items")
        if isinstance(child, Mapping):
            for index, item in enumerate(value):
                self._validate_value(item, child, path=f"{path}[{index}]")
        elif child is not None:
            raise ToolArgumentValidationError(f"{path}: items must be a schema object")

    def _validate_string(self, value: Any, schema: Mapping[str, Any], *, path: str) -> None:
        if isinstance(value, str):
            self._check_bounds(len(value), schema, path, "Length")

    def _validate_number(self, value: Any, schema: Mapping[str, Any], *, path: str) -> None:
        if not self._is_number(value):
            return
        if "minimum" in schema and value < schema["minimum"]:
            raise ToolArgumentValidationError(f"{path}: must be >= {schema['minimum']}")
        if "maximum" in schema and value > schema["maximum"]:
            raise ToolArgumentValidationError(f"{path}: must be <= {schema['maximum']}")

    @staticmethod
    def _check_bounds(value: int, schema: Mapping[str, Any], path: str, suffix: str) -> None:
        minimum = schema.get(f"min{suffix}")
        maximum = schema.get(f"max{suffix}")
        if minimum is not None and value < minimum:
            raise ToolArgumentValidationError(f"{path}: length must be >= {minimum}")
        if maximum is not None and value > maximum:
            raise ToolArgumentValidationError(f"{path}: length must be <= {maximum}")
