"""Python traceback reducers for model-visible shell output."""

from __future__ import annotations

import re
from pathlib import Path

_TB_HEADER_RE = re.compile(r"^Traceback \(most recent call last\):\s*$")


_PYTHON_EXEC_TOKEN_RE = re.compile(r"\b(?:python3?|ipython)\b")


_FILE_LINE_RE = re.compile(r'^  File "(?P<path>[^"]+)", line (?P<line>\d+), in (?P<func>.+)$')


def _has_masked_python_traceback(command: str, output: str, rc: int) -> bool:
    """Detect Python failures hidden by shell pipelines such as ``python3 x.py | cat``."""
    if rc != 0 or not output:
        return False
    if "Traceback (most recent call last):" not in output:
        return False
    return "|" in (command or "") and bool(_PYTHON_EXEC_TOKEN_RE.search(command or ""))


def _is_user_workspace_path(path_str: str, workspace: Path) -> bool:
    """True if *path_str* refers to a file under *workspace* (resolved)."""
    try:
        ws = workspace.resolve()
        p = Path(path_str)
        if not p.is_absolute():
            p = (ws / p).resolve()
        else:
            p = p.resolve()
        p.relative_to(ws)
        return True
    except (ValueError, OSError):
        return False


def _path_relative_to_workspace_str(path_str: str, workspace: Path) -> str | None:
    """Return *path_str* as a path relative to *workspace* (posix), or None if not under it."""
    try:
        ws = workspace.resolve()
        p = Path(path_str)
        if not p.is_absolute():
            p = (ws / p).resolve()
        else:
            p = p.resolve()
        rel = p.relative_to(ws)
        return rel.as_posix()
    except (ValueError, OSError):
        return None


def _rewrite_tb_file_line_to_relative(line: str, workspace: Path) -> str:
    """Rewrite ``  File \"...\", line N, in ...`` to use workspace-relative path when applicable."""
    m = _FILE_LINE_RE.match(line)
    if not m:
        return line
    path = m.group("path")
    rel = _path_relative_to_workspace_str(path, workspace)
    if rel is None:
        return line
    return f'  File "{rel}", line {m.group("line")}, in {m.group("func")}'


def _tb_collapse_label(first_path: str, last_path: str) -> str:
    """Short labels for collapsed library frames (e.g. sklearn.base -> sklearn.utils.validation)."""

    def short(p: str) -> str:
        parts = Path(p).parts
        if "site-packages" in parts:
            idx = parts.index("site-packages")
            rest = parts[idx + 1 :]
            if not rest:
                return Path(p).name
            return ".".join(x.replace(".py", "") for x in rest)
        return Path(p).name

    return f"{short(first_path)} -> {short(last_path)}"


def _is_tb_frame_continuation(line: str) -> bool:
    if line.startswith("    "):
        return True
    stripped = line.lstrip()
    if stripped.startswith("^"):
        return True
    return False


def _is_tb_exception_line(line: str) -> bool:
    if not line.strip():
        return False
    if line.startswith("  "):
        return False
    if line.startswith("During handling"):
        return False
    if line.startswith("Traceback"):
        return False
    if line.strip() == "KeyboardInterrupt":
        return True
    if re.match(
        r"^[\w.]+(?:Error|Exception|Exit|Interrupt|Warning|DeprecationWarning)\s*:",
        line,
    ):
        return True
    return False


def _format_distilled_tb(frames: list[dict], exc_line: str) -> str:
    out = ["Traceback (most recent call last):"]
    i = 0
    n = len(frames)
    while i < n:
        if frames[i]["user"]:
            out.extend(frames[i]["block"])
            i += 1
            continue
        j = i
        while j < n and not frames[j]["user"]:
            j += 1
        count = j - i
        first = frames[i]["path"]
        last = frames[j - 1]["path"]
        out.append(f"  [... {count} library frames collapsed ({_tb_collapse_label(first, last)})]")
        i = j
    out.append(exc_line)
    return "\n".join(out)


def _consume_and_distill_one_tb(
    lines: list[str],
    start: int,
    workspace: Path,
) -> tuple[int, str]:
    """Parse one traceback starting at *start* (header line index). Returns (next_index, distilled_text)."""
    assert _TB_HEADER_RE.match(lines[start])
    i = start + 1
    frames: list[dict] = []
    while i < len(lines):
        m = _FILE_LINE_RE.match(lines[i])
        if m:
            path = m.group("path")
            block = [lines[i]]
            i += 1
            while i < len(lines) and _is_tb_frame_continuation(lines[i]):
                block.append(lines[i])
                i += 1
            user = _is_user_workspace_path(path, workspace)
            if user:
                block[0] = _rewrite_tb_file_line_to_relative(block[0], workspace)
            frames.append(
                {
                    "user": user,
                    "block": block,
                    "path": path,
                }
            )
            continue
        line = lines[i]
        if not line.strip():
            i += 1
            continue
        if _is_tb_exception_line(line):
            exc = line
            i += 1
            distilled = _format_distilled_tb(frames, exc)
            parts: list[str] = [distilled]
            while i < len(lines):
                while i < len(lines) and not lines[i].strip():
                    i += 1
                if i >= len(lines):
                    break
                if "During handling" in lines[i] and "another exception" in lines[i]:
                    parts.append(lines[i])
                    i += 1
                    while i < len(lines) and not lines[i].strip():
                        i += 1
                    if i < len(lines) and _TB_HEADER_RE.match(lines[i]):
                        j, nested = _consume_and_distill_one_tb(lines, i, workspace)
                        parts.append(nested)
                        i = j
                        continue
                    break
                break
            return i, "\n\n".join(parts)
        # Unrecognized line while parsing frames (malformed traceback): keep remainder verbatim.
        return len(lines), "\n".join(lines[start:])
    return i, "\n".join(lines[start:i])


def _distill_tracebacks(
    text: str,
    workspace_dir: Path,
    *,
    enabled: bool = True,
) -> str:
    """Collapse library-internal frames in Python tracebacks; keep user workspace frames + exception."""
    if not enabled or not text:
        return text
    lines = text.splitlines()
    if not lines:
        return text
    out: list[str] = []
    i = 0
    n = len(lines)
    while i < n:
        if _TB_HEADER_RE.match(lines[i]):
            j, distilled = _consume_and_distill_one_tb(lines, i, workspace_dir)
            out.extend(distilled.splitlines())
            i = j
        else:
            out.append(lines[i])
            i += 1
    result = "\n".join(out)
    if text.endswith("\n") and result and not result.endswith("\n"):
        result += "\n"
    return result


# Public names for host applications; private aliases remain for compatibility.
distill_tracebacks = _distill_tracebacks
has_masked_python_traceback = _has_masked_python_traceback
