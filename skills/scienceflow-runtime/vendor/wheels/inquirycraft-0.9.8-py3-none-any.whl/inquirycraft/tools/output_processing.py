from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from .artifacts import RawToolOutputStore, ToolOutputReducerRegistry
from .base import ToolResult
from .shell_output import trim_shell_output
from .shell_reducer import _dedup_repeated_blocks, _maybe_lossless_observation_summary


@dataclass(frozen=True, slots=True)
class ToolOutputPolicy:
    """Bound model-visible tool output while retaining the exact raw artifact."""

    enabled: bool = True
    max_model_chars: int = 12_000
    preserve_raw: bool = True
    include_artifact_note: bool = True
    always_reduce: bool = False

    def __post_init__(self) -> None:
        if self.enabled and self.max_model_chars < 1_200:
            raise ValueError("max_model_chars must be at least 1200 when output policy is enabled")


class ToolOutputProcessor:
    def __init__(
        self,
        *,
        store: RawToolOutputStore,
        policy: ToolOutputPolicy | None = None,
        reducers: ToolOutputReducerRegistry | None = None,
    ) -> None:
        self.store = store
        self.policy = policy or ToolOutputPolicy()
        self.reducers = reducers or default_tool_output_reducers(self.policy)

    def process(
        self,
        *,
        tool_name: str,
        arguments: Mapping[str, Any],
        result: ToolResult,
    ) -> ToolResult:
        raw = result.render()
        policy = self.policy
        if not policy.enabled or (not policy.always_reduce and len(raw) <= policy.max_model_chars):
            return result
        visible, reducer_name = self.reducers.reduce(
            tool_name=tool_name,
            args=dict(arguments),
            feedback=raw,
            raw_text=raw,
            tool_error=result.is_error,
            result=result,
        )
        if visible == raw:
            visible = trim_shell_output(raw, policy.max_model_chars)
            reducer_name = "generic_head_tail_v1"
        if policy.preserve_raw:
            ref = self.store.reserve(tool_name, raw)
            if ref is None or not self.store.write_raw(ref, raw):
                return result
            note = self._artifact_note(ref) if policy.include_artifact_note else ""
            visible = self._fit_with_note(visible, note)
            self.store.append_index(
                ref,
                reducer_name=reducer_name,
                compressed_chars=len(visible),
            )
            metadata = {
                **dict(result.metadata),
                "raw_output_artifact": {
                    "raw_id": ref.raw_id,
                    "raw_chars": ref.raw_chars,
                    "sha256": ref.sha256_short,
                    "reducer": reducer_name,
                },
            }
        else:
            visible = _bounded_head_tail(visible, policy.max_model_chars)
            metadata = {**dict(result.metadata), "output_reducer": reducer_name}
        return self._visible_result(result, visible, metadata)

    def _fit_with_note(self, visible: str, note: str) -> str:
        if not note:
            return _bounded_head_tail(visible, self.policy.max_model_chars)
        separator = "\n" if visible else ""
        budget = self.policy.max_model_chars - len(separator) - len(note)
        return f"{_bounded_head_tail(visible, budget)}{separator}{note}"

    @staticmethod
    def _artifact_note(ref: Any) -> str:
        return (
            f"[full tool output saved: .logs/tool_outputs/{ref.raw_id}; "
            f"raw_chars={ref.raw_chars}; sha256={ref.sha256_short}]"
        )

    @staticmethod
    def _visible_result(
        original: ToolResult,
        visible: str,
        metadata: Mapping[str, Any],
    ) -> ToolResult:
        if original.is_error:
            error = visible.removeprefix("Error: ")
            return ToolResult(
                error=error,
                system=original.system,
                metadata=metadata,
            )
        return ToolResult(
            output=visible,
            system=original.system,
            metadata=metadata,
        )


def default_tool_output_reducers(policy: ToolOutputPolicy) -> ToolOutputReducerRegistry:
    registry = ToolOutputReducerRegistry()

    def reduce_shell(
        *,
        args: dict[str, Any],
        feedback: str,
        raw_text: str,
        tool_error: bool,
        **_: Any,
    ) -> tuple[str, str]:
        visible, observation_raw = _maybe_lossless_observation_summary(
            command=str(args.get("command", "")),
            output=raw_text,
            enabled=True,
            max_chars=policy.max_model_chars,
            returncode=1 if tool_error else 0,
        )
        if observation_raw is not None:
            return visible, "shell_observation_head_tail_v1"
        deduplicated = _dedup_repeated_blocks(raw_text)
        reduced = trim_shell_output(deduplicated, policy.max_model_chars)
        name = "shell_dedup_head_tail_v1" if deduplicated != raw_text else "shell_head_tail_v1"
        return reduced, name

    registry.register("shell", reduce_shell)
    registry.register("bash", reduce_shell)
    return registry


def _bounded_head_tail(text: str, max_chars: int) -> str:
    """Return an exact-length-bounded head/tail view, including its marker."""

    if len(text) <= max_chars:
        return text
    marker = f"\n... [truncated to max_model_chars={max_chars}; showing head+tail] ...\n"
    available = max_chars - len(marker)
    head_chars = available // 2
    tail_chars = available - head_chars
    return f"{text[:head_chars]}{marker}{text[-tail_chars:]}"
