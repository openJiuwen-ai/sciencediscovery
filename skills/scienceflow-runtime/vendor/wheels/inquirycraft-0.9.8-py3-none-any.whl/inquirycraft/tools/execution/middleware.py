from __future__ import annotations

from typing import Any


class ToolExecutionMiddleware:
    """No-op middleware contract with a fixed observable hook order."""

    async def _noop(self, *_: Any) -> None:
        return None

    before_bundle = before_tool = invoke = after_tool = record_tool_message = after_bundle = _noop
