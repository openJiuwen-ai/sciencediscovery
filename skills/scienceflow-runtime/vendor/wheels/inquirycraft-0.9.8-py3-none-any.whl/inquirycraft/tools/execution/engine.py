from __future__ import annotations

import asyncio
import json
from collections.abc import Awaitable, Callable, Mapping, Sequence
from functools import partial
from typing import Any

from ..base import ToolContext, ToolResult, coerce_tool_result
from ..collection import ToolCollection
from ..executor import ToolInvocation
from ..validation import BuiltinToolArgumentValidator, ToolArgumentValidator
from .middleware import ToolExecutionMiddleware
from .models import ToolExecutionRecord, ToolPostprocessDecision, ToolPreflightDecision

ToolKwargsFactory = Callable[[ToolExecutionRecord], Mapping[str, Any] | None]
ToolArgumentsTransform = Callable[[ToolExecutionRecord, dict[str, Any]], Mapping[str, Any]]
ToolBeforeExecute = Callable[[ToolExecutionRecord], Awaitable[ToolPreflightDecision | None]]
ToolAfterExecute = Callable[
    [ToolExecutionRecord], Awaitable[ToolResult | ToolPostprocessDecision | None]
]
ToolCompleted = Callable[[ToolExecutionRecord], Awaitable[None]]
ToolContextFactory = Callable[[ToolExecutionRecord], ToolContext]
ToolStarted = Callable[[ToolExecutionRecord], Awaitable[None]]
ToolFinalize = Callable[[ToolExecutionRecord], Awaitable[ToolResult | None]]


def _fallback_invocation(call: Any) -> ToolInvocation:
    function = getattr(call, "function", None)
    if isinstance(call, Mapping):
        function = call.get("function")
    name = (
        function.get("name", "") if isinstance(function, Mapping) else getattr(function, "name", "")
    )
    call_id = call.get("id", "") if isinstance(call, Mapping) else getattr(call, "id", "")
    return ToolInvocation(id=str(call_id or ""), name=str(name or ""), arguments={})


def _parse_invocation(call: Any, *, strict: bool) -> tuple[ToolInvocation, str | None]:
    try:
        return ToolInvocation.from_openai(call), None
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        invocation = _fallback_invocation(call)
        return invocation, f"Invalid tool arguments: {exc}" if strict else None


class ToolExecutionEngine:
    """Preflight and execute a tool bundle with deterministic persistence order."""

    def __init__(
        self,
        tools: ToolCollection,
        *,
        middleware: Sequence[ToolExecutionMiddleware] = (),
        validator: ToolArgumentValidator | None = None,
    ) -> None:
        self.tools = tools
        self.middleware = tuple(middleware)
        self.validator = validator or BuiltinToolArgumentValidator()

    async def execute(
        self,
        calls: Sequence[Any],
        *,
        context: ToolContext | None = None,
        concurrent: bool = False,
        kwargs_factory: ToolKwargsFactory | None = None,
        arguments_transform: ToolArgumentsTransform | None = None,
        validate_arguments: bool = False,
        strict_arguments: bool = False,
        before_execute: ToolBeforeExecute | None = None,
        after_execute: ToolAfterExecute | None = None,
        on_complete: ToolCompleted | None = None,
        context_factory: ToolContextFactory | None = None,
        on_start: ToolStarted | None = None,
        finalize: ToolFinalize | None = None,
    ) -> list[ToolExecutionRecord]:
        records: list[ToolExecutionRecord] = []
        for index, call in enumerate(calls):
            invocation, parse_error = _parse_invocation(call, strict=strict_arguments)
            record = ToolExecutionRecord(index=index, call=call, invocation=invocation)
            if parse_error:
                self._fail(record, parse_error, category="arguments")
            records.append(record)

        for middleware in self.middleware:
            await middleware.before_bundle(records)
        for record in records:
            await self._preflight(
                record,
                arguments_transform=arguments_transform,
                validate_arguments=validate_arguments,
                before_execute=before_execute,
            )

        allowed_concurrency = concurrent and all(
            self._execution_mode(record) == "parallel" for record in records
        )
        run = partial(
            self._run,
            context=context,
            kwargs_factory=kwargs_factory,
            after_execute=after_execute,
            on_complete=on_complete,
            context_factory=context_factory,
            on_start=on_start,
            finalize=finalize,
        )
        if allowed_concurrency:
            await asyncio.gather(*(run(record) for record in records))
        else:
            for record in records:
                await run(record)

        for record in records:
            for middleware in self.middleware:
                await middleware.record_tool_message(record)
        for middleware in self.middleware:
            await middleware.after_bundle(records)
        return records

    async def _preflight(
        self,
        record: ToolExecutionRecord,
        *,
        arguments_transform: ToolArgumentsTransform | None,
        validate_arguments: bool,
        before_execute: ToolBeforeExecute | None,
    ) -> None:
        if record.result is not None:
            return
        try:
            tool = self.tools.get(record.invocation.name)
            for middleware in self.middleware:
                await middleware.before_tool(record)
            for middleware in self.middleware:
                await middleware.invoke(record)
            arguments = dict(tool.prepare_arguments(record.invocation.arguments))
            if arguments_transform is not None:
                arguments = dict(arguments_transform(record, arguments))
            record.invocation = ToolInvocation(
                id=record.invocation.id,
                name=record.invocation.name,
                arguments=arguments,
            )
            if validate_arguments:
                self.validator.validate(arguments, tool._schema())
            if before_execute is not None:
                decision = await before_execute(record)
                if decision is not None and decision.result is not None:
                    record.result = coerce_tool_result(decision.result)
                    record.terminate = decision.terminate
                    record.metadata["recovered"] = True
                elif decision is not None and decision.block:
                    record.blocked = True
                    record.terminate = decision.terminate
                    self._fail(
                        record,
                        decision.reason or "Tool execution blocked",
                        category="blocked",
                    )
        except Exception as exc:
            self._fail(record, f"{type(exc).__name__}: {exc}", category="preflight")

    async def _run(
        self,
        record: ToolExecutionRecord,
        *,
        context: ToolContext | None,
        kwargs_factory: ToolKwargsFactory | None,
        after_execute: ToolAfterExecute | None,
        on_complete: ToolCompleted | None,
        context_factory: ToolContextFactory | None,
        on_start: ToolStarted | None,
        finalize: ToolFinalize | None,
    ) -> None:
        if record.result is None:
            try:
                active_context = context_factory(record) if context_factory else context
                if active_context is not None:
                    active_context.cancellation.raise_if_cancelled()
                if on_start is not None:
                    await on_start(record)
                extra = dict(kwargs_factory(record) or {}) if kwargs_factory else {}
                record.result = coerce_tool_result(
                    await self.tools.execute(
                        name=record.invocation.name,
                        tool_input=dict(record.invocation.arguments),
                        context=active_context,
                        **extra,
                    )
                )
            except Exception as exc:
                self._fail(record, f"{type(exc).__name__}: {exc}", category="execution")
        record.is_error = bool(record.result and record.result.is_error)
        if after_execute is not None:
            replacement = await after_execute(record)
            if isinstance(replacement, ToolPostprocessDecision):
                record.terminate = record.terminate or replacement.terminate
                if replacement.result is not None:
                    record.result = coerce_tool_result(replacement.result)
                    record.is_error = record.result.is_error
            elif replacement is not None:
                record.result = coerce_tool_result(replacement)
                record.is_error = record.result.is_error
        if finalize is not None:
            finalized = await finalize(record)
            if finalized is not None:
                record.result = coerce_tool_result(finalized)
                record.is_error = record.result.is_error
        for middleware in self.middleware:
            await middleware.after_tool(record)
        if on_complete is not None:
            await on_complete(record)

    def _execution_mode(self, record: ToolExecutionRecord) -> str:
        tool = self.tools.get_tool(record.invocation.name)
        return getattr(tool, "execution_mode", "sequential") if tool else "sequential"

    @staticmethod
    def _fail(record: ToolExecutionRecord, error: str, *, category: str) -> None:
        record.result = ToolResult(error=error, metadata={"category": category})
        record.is_error = True
        record.metadata["error_category"] = category
