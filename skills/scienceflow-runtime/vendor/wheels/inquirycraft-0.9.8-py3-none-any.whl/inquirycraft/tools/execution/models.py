from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..base import ToolResult
from ..executor import ToolInvocation


@dataclass(slots=True)
class ToolExecutionRecord:
    index: int
    call: Any
    invocation: ToolInvocation
    result: ToolResult | None = None
    is_error: bool = False
    blocked: bool = False
    terminate: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ToolPreflightDecision:
    block: bool = False
    reason: str = ""
    terminate: bool = False
    result: ToolResult | None = None


@dataclass(frozen=True, slots=True)
class ToolPostprocessDecision:
    result: ToolResult | None = None
    terminate: bool = False
