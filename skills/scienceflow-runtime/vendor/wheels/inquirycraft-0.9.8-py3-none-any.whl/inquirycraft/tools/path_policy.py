"""Filesystem path policy, validation, and atomic-write helpers."""

from __future__ import annotations

import hashlib
import os
from collections.abc import Sequence
from pathlib import Path, PurePosixPath


def normalize_extra_roots(extra_roots: Sequence[str | Path] | None) -> tuple[Path, ...]:
    out: list[Path] = []
    for raw in extra_roots or ():
        value = str(raw).strip()
        if value:
            out.append(Path(value).expanduser().resolve())
    return tuple(out)


def normalize_denied_prefixes(
    prefixes: Sequence[str | Path] | None,
) -> tuple[PurePosixPath, ...]:
    out: list[PurePosixPath] = []
    for raw in prefixes or ():
        text = str(raw or "").strip().replace("\\", "/").lstrip("/")
        parts = [part for part in text.split("/") if part not in ("", ".")]
        if not parts or any(part == ".." for part in parts):
            continue
        path = PurePosixPath(*parts)
        if path not in out:
            out.append(path)
    return tuple(out)


def _path_has_prefix(path: PurePosixPath, prefixes: tuple[PurePosixPath, ...]) -> bool:
    parts = path.parts
    return any(
        len(parts) >= len(prefix.parts) and parts[: len(prefix.parts)] == prefix.parts
        for prefix in prefixes
    )


def _logical_path_denied(value: str | Path, prefixes: tuple[PurePosixPath, ...]) -> bool:
    text = str(value or "").strip().replace("\\", "/")
    if not text or PurePosixPath(text).is_absolute():
        return False
    parts = [part for part in text.split("/") if part not in ("", ".")]
    return bool(parts) and _path_has_prefix(PurePosixPath(*parts), prefixes)


class PathPolicy:
    """Resolve paths under a configured root and optional explicitly allowed roots.

    The policy is independent from any task or workspace model. Hosts may configure
    ``root`` as a strict containment boundary, disable containment, or add explicit
    roots.
    """

    def __init__(
        self,
        root: str | Path,
        *,
        enabled: bool = True,
        extra_roots: Sequence[str | Path] | None = None,
        denied_prefixes: Sequence[str | Path] | None = None,
    ) -> None:
        self.root = Path(root).resolve()
        self._enabled = enabled
        self._extra_roots = normalize_extra_roots(extra_roots)
        self._denied_prefixes = normalize_denied_prefixes(denied_prefixes)

    @property
    def containment_enabled(self) -> bool:
        """Whether paths are restricted to the root and explicit extra roots."""
        return self._enabled

    @property
    def extra_roots(self) -> tuple[Path, ...]:
        """Additional roots explicitly admitted by this policy."""
        return self._extra_roots

    @property
    def denied_prefixes(self) -> tuple[PurePosixPath, ...]:
        """Root-relative prefixes hidden from file tools."""
        return self._denied_prefixes

    def _under_any_extra(self, candidate: Path) -> bool:
        resolved = candidate.resolve()
        for prefix in self._extra_roots:
            try:
                resolved.relative_to(prefix)
                return True
            except ValueError:
                continue
        return False

    def resolve(self, path: str | Path) -> Path:
        """Resolve a path and reject root escapes when containment is enabled."""
        if isinstance(path, Path) and path.is_absolute():
            candidate = path.resolve()
        else:
            candidate = (self.root / path).resolve()
        if self._enabled:
            try:
                candidate.relative_to(self.root)
            except ValueError as exc:
                if not self._under_any_extra(candidate):
                    raise ValueError(f"Path escapes workspace: {path!r}") from exc
        if self.is_denied(candidate, requested=path):
            raise ValueError(f"Path is hidden from agent tools: {path!r}")
        return candidate

    def is_denied(self, path: str | Path, *, requested: str | Path | None = None) -> bool:
        if not self._denied_prefixes:
            return False
        if requested is not None and _logical_path_denied(requested, self._denied_prefixes):
            return True
        try:
            candidate = Path(path)
            resolved = (
                candidate.resolve()
                if candidate.is_absolute()
                else (self.root / candidate).resolve()
            )
            relative = resolved.relative_to(self.root)
        except (OSError, ValueError):
            return False
        logical = PurePosixPath(*relative.parts) if relative.parts else PurePosixPath(".")
        return _path_has_prefix(logical, self._denied_prefixes)


def display_under_root(root: Path, resolved: Path) -> str:
    """Return a root-relative display path, falling back to an absolute path."""
    try:
        return resolved.relative_to(root).as_posix() or "."
    except ValueError:
        return resolved.as_posix()


def normalize_display_path(path: str | Path | None) -> str:
    """Normalize a model-visible path without resolving symlinks."""
    value = str(path or ".").strip().replace("\\", "/")
    if not value:
        return "."
    if PurePosixPath(value).is_absolute():
        return PurePosixPath(value).as_posix()
    parts = [part for part in value.split("/") if part not in ("", ".")]
    return "/".join(parts) or "."


def _display_under_any_root(resolved: Path, roots: Sequence[Path]) -> str | None:
    for root in roots:
        try:
            return resolved.relative_to(root.resolve()).as_posix() or "."
        except ValueError:
            continue
    return None


def display_from_request(
    root: Path,
    resolved: Path,
    requested: str | Path | None,
    *,
    logical_paths: bool = True,
    display_root: str | Path | None = None,
) -> str:
    """Keep model-visible paths stable while filesystem checks use resolved paths."""
    roots = [root]
    if display_root is not None:
        roots.insert(0, Path(display_root))
    if not logical_paths:
        return display_under_root(roots[0].resolve(), resolved)
    if requested is not None and Path(str(requested)).is_absolute():
        relative = _display_under_any_root(resolved, roots)
        return relative if relative is not None else (resolved.name or ".")
    logical = normalize_display_path(requested)
    if logical != "." or normalize_display_path(root) == ".":
        return logical
    relative = _display_under_any_root(resolved, roots)
    return relative if relative is not None else (resolved.name or ".")


def join_display_path(base: str | Path | None, child: str | Path | None = "") -> str:
    """Join logical display fragments without introducing absolute paths."""
    base_value = normalize_display_path(base)
    child_value = normalize_display_path(child)
    if child_value == ".":
        return base_value
    if base_value == ".":
        return child_value
    return f"{base_value.rstrip('/')}/{child_value.lstrip('/')}"


def validate_syntax(path: Path, content: str) -> str | None:
    """Return a lightweight extension-specific syntax error, if any."""
    extension = path.suffix.lower()
    if extension == ".py":
        try:
            compile(content, str(path), "exec")
        except SyntaxError as exc:
            return f"Python syntax error: {exc}"
    elif extension == ".json":
        import json

        try:
            json.loads(content)
        except json.JSONDecodeError as exc:
            return f"JSON parse error: {exc}"
    elif extension in (".yaml", ".yml"):
        try:
            import yaml
        except ImportError:
            return None
        try:
            yaml.safe_load(content)
        except Exception as exc:
            return f"YAML parse error: {exc}"
    return None


def atomic_write(path: Path, content: str, *, encoding: str = "utf-8") -> dict:
    """Write via a sibling temporary file and return stable file metadata."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.parent / f"{path.name}.tmp.{os.getpid()}"
    try:
        temporary.write_text(content, encoding=encoding)
        os.replace(str(temporary), str(path))
    finally:
        if temporary.exists():
            try:
                temporary.unlink()
            except OSError:
                pass
    raw = content.encode(encoding)
    return {
        "path": str(path),
        "lines": len(content.splitlines()),
        "bytes": len(raw),
        "sha256_short": hashlib.sha256(raw).hexdigest()[:16],
    }


def file_summary(path: Path, max_lines: int = 200) -> str:
    """Return a bounded text preview suitable for tool diagnostics."""
    if not path.is_file():
        return f"(not a file: {path})"
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    total = len(lines)
    if total <= max_lines:
        body = "\n".join(lines)
    else:
        half = max_lines // 2
        body = "\n".join(lines[:half])
        body += f"\n... ({total} lines total) ...\n"
        body += "\n".join(lines[-half:])
    return f"[{path.name}: {total} lines]\n{body}"


# Compatibility name retained for hosts importing the historical API. New code
# should use PathPolicy: containment is a configurable policy, not Tool ownership.
PathGuard = PathPolicy
