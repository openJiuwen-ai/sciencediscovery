"""Recognize display-only or compressed-memory text that must not be written."""

from __future__ import annotations

import re

INTERACTION_LOG_WRITE_BODY_OMITTED_RE = re.compile(
    r"^\[interaction-log: write body omitted; \d+ chars applied by tool\]$",
    re.IGNORECASE,
)
CHAT_MEMORY_WRITE_PAYLOAD_OMITTED_RE = re.compile(
    r"^# \[chat-memory: write payload omitted \(\d+ bytes\); "
    r"following write tool result confirms on-disk file\.\]$",
    re.IGNORECASE,
)
NEW_DISPLAY_STUB_INTERACTION_RE = re.compile(
    r"^\[DO NOT COPY - display-only stub: real \d+-char body applied to disk\]$",
    re.IGNORECASE,
)
NEW_DISPLAY_STUB_CHAT_MEMORY_RE = re.compile(
    r"^# \[DO NOT COPY - display-only stub: real \d+-byte solution body on disk;",
    re.IGNORECASE,
)
WRITE_OK_INTERACTION_RE = re.compile(
    r"^\[WRITE_OK memory-compression: \d+ chars",
    re.IGNORECASE,
)
WRITE_OK_CHAT_MEMORY_RE = re.compile(
    r"^# \[WRITE_OK memory-compression: \d+ bytes",
    re.IGNORECASE,
)
WRITE_PLACEHOLDER_ANCHOR_RE = re.compile(
    r"^(?:"
    r"<\d+\s+chars>"
    r"|\[file content omitted - \d+ chars written to disk\]"
    r"|<<<WRITE_PLACEHOLDER:[^>]*>>>"
    r"|<<<WRITE_CONTENT:[^>]*>>>"
    r")$",
    re.IGNORECASE,
)

MEMORY_COMPRESSED_MARKER = "# [MEMORY_COMPRESSED:"
MEMORY_COMPRESSED_MARKER_V2 = "# <<<MEMORY_COMPRESSED:"
WRITE_OK_MARKER = "# <<<WRITE_OK:"
WRITE_PLACEHOLDER_MIMICRY_RE = WRITE_PLACEHOLDER_ANCHOR_RE
_MAX_MEMORY_LIKE_WRITE_CHARS = 768


def looks_like_write_placeholder_mimicry(content: str) -> bool:
    """Return whether content is a display placeholder rather than a real file body."""
    if not isinstance(content, str):
        return False
    value = content.strip()
    if not value:
        return False
    patterns = (
        WRITE_PLACEHOLDER_ANCHOR_RE,
        INTERACTION_LOG_WRITE_BODY_OMITTED_RE,
        CHAT_MEMORY_WRITE_PAYLOAD_OMITTED_RE,
        NEW_DISPLAY_STUB_INTERACTION_RE,
        NEW_DISPLAY_STUB_CHAT_MEMORY_RE,
        WRITE_OK_INTERACTION_RE,
        WRITE_OK_CHAT_MEMORY_RE,
    )
    if any(pattern.match(value) for pattern in patterns):
        return True
    if value.startswith("# [REJECTED: placeholder mimicry") or value.startswith("# <<<REJECTED:"):
        return True
    markers = (
        MEMORY_COMPRESSED_MARKER,
        MEMORY_COMPRESSED_MARKER_V2,
        WRITE_OK_MARKER,
    )
    return any(marker in value for marker in markers) and len(value) <= _MAX_MEMORY_LIKE_WRITE_CHARS
