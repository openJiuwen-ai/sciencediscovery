"""Stable, host-independent rendering for shell output."""

from __future__ import annotations

import re
from collections.abc import Sequence
from pathlib import Path


def sanitize_workspace_prefix(text: str, workspace: Path) -> str:
    """Replace an absolute workspace prefix with ``.`` at path boundaries."""
    workspace_value = str(workspace.resolve())
    if not workspace_value:
        return text
    return re.sub(re.escape(workspace_value) + r"(?=/|$)", ".", text)


def sanitize_root_prefix(text: str, root: Path, marker: str) -> str:
    root_value = str(root.resolve()).rstrip("/")
    if not text or not root_value or root_value == "/":
        return text
    return re.sub(re.escape(root_value) + r"(?=/|$)", marker.rstrip("/"), text)


def sanitize_python_env_paths(text: str) -> str:
    """Replace virtualenv/site-package absolute paths with a stable label."""
    if not text:
        return text

    def replace(match: re.Match[str]) -> str:
        path = match.group(0)
        for marker in ("/site-packages/", "/dist-packages/"):
            index = path.find(marker)
            if index >= 0:
                return "<python-env>" + path[index:]
        return "<python-env>/" + Path(path).name

    return re.sub(
        r"/(?:[^\s\"'<>:]+/)+(?:site-packages|dist-packages)/[^\s\"'<>),]+",
        replace,
        text,
    )


def sanitize_host_absolute_paths(text: str) -> str:
    """Hide remaining host-specific absolute paths."""
    if not text:
        return text

    def replace(match: re.Match[str]) -> str:
        name = Path(match.group(0)).name
        return f"<abs-path>/{name}" if name else "<abs-path>"

    return re.sub(r"(?<![\w.])/(?:home|work|mnt|kaggle|tmp)/[^\s\"'<>),]+", replace, text)


def strip_symlink_targets(text: str) -> str:
    """Remove absolute symlink targets while preserving link names."""
    return re.sub(r" -> /\S+", "", text)


_strip_targets = strip_symlink_targets


def sanitize_shell_output_paths(
    text: str,
    workspace: Path,
    extra_roots: Sequence[Path | str] = (),
    *,
    strip_symlink_targets: bool = True,
) -> str:
    """Apply stable path rendering to final output and live stream mirrors."""
    if not text:
        return text
    output = sanitize_workspace_prefix(text, workspace)
    for index, root in enumerate(extra_roots or (), start=1):
        output = sanitize_root_prefix(output, Path(root), f"<extra-root-{index}>")
    if strip_symlink_targets:
        output = _strip_targets(output)
    output = sanitize_python_env_paths(output)
    return sanitize_host_absolute_paths(output)


def trim_shell_output(text: str, max_chars: int) -> str:
    """Keep exact head and tail slices within a model-visible character budget."""
    if max_chars <= 0 or len(text) <= max_chars:
        return text
    edge = max(max_chars // 2 - 40, 800)
    if 2 * edge + 80 > max_chars:
        edge = max((max_chars - 80) // 2, 400)
    omitted = len(text) - 2 * edge
    line_count = len(text.splitlines())
    return (
        f"{text[:edge]}\n"
        f"... [truncated {omitted} of {len(text)} chars, {line_count} lines total; "
        f"showing head+tail within max_output_chars={max_chars}] ...\n"
        f"{text[-edge:]}"
    )
