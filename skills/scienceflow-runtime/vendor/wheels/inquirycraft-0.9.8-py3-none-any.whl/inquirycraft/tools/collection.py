from __future__ import annotations

from collections.abc import Iterable
from typing import Any, overload

from .base import BaseTool, ToolContext, ToolError, ToolFailure, ToolResult, coerce_tool_result


class ToolCollection:
    """Ordered canonical collection for public and historical tool shapes."""

    @overload
    def __init__(self, tools: Iterable[BaseTool] = ()) -> None: ...

    @overload
    def __init__(self, tools: BaseTool, *additional: BaseTool) -> None: ...

    def __init__(
        self,
        tools: Iterable[BaseTool] | BaseTool = (),
        *additional: BaseTool,
    ) -> None:
        initial = (tools, *additional) if isinstance(tools, BaseTool) else (*tools, *additional)
        self.tools: tuple[BaseTool, ...] = ()
        self.tool_map: dict[str, BaseTool] = {}
        for tool in initial:
            self.register(tool)

    def register(self, tool: BaseTool, *, replace: bool = False) -> None:
        if not tool.name or (tool.name in self.tool_map and not replace):
            raise ValueError(f"Duplicate or empty tool name: {tool.name!r}")
        self.tool_map[tool.name] = tool
        self.tools = tuple(self.tool_map.values())

    def get(self, name: str) -> BaseTool:
        try:
            return self.tool_map[name]
        except KeyError as exc:
            raise KeyError(f"Unknown tool: {name}") from exc

    def schemas(self) -> tuple[dict[str, Any], ...]:
        return tuple(tool.to_openai() for tool in self.tools)

    def to_params(self) -> list[dict[str, Any]]:
        return list(self.schemas())

    def names(self) -> tuple[str, ...]:
        return tuple(self.tool_map)

    def __len__(self) -> int:
        return len(self.tools)

    def __iter__(self):
        return iter(self.tools)

    def get_tool(self, name: str) -> BaseTool | None:
        return self.tool_map.get(name)

    def add_tool(self, tool: BaseTool) -> "ToolCollection":
        self.register(tool)
        return self

    def add_tools(self, *tools: BaseTool) -> "ToolCollection":
        for tool in tools:
            self.register(tool)
        return self

    async def execute(
        self,
        *,
        name: str,
        tool_input: dict[str, Any] | None = None,
        context: ToolContext | None = None,
        **kwargs: Any,
    ) -> ToolResult:
        tool = self.tool_map.get(name)
        if tool is None:
            return ToolFailure(error=f"Tool {name} is invalid")
        arguments = tool_input or {}
        if name == "bash":
            command = arguments.get("command")
            if command is None or not str(command).strip():
                return ToolFailure(error="bash tool requires non-empty 'command' argument")
        try:
            value = await tool.invoke(arguments, context, **kwargs)
            return coerce_tool_result(value)
        except ToolError as exc:
            return ToolFailure(error=exc.message)

    async def execute_all(self, *, context: ToolContext | None = None) -> list[ToolResult]:
        results: list[ToolResult] = []
        for tool in self.tools:
            try:
                results.append(coerce_tool_result(await tool.invoke({}, context)))
            except ToolError as exc:
                results.append(ToolFailure(error=exc.message))
        return results
