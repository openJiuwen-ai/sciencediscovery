"""Composable tool-result guard protocol and lifecycle manager."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from .base import ToolResult


class ToolGuard(ABC):
    name: str = "tool_guard"

    @abstractmethod
    def on_tool_result(
        self,
        tool_name: str,
        args: dict[str, Any],
        result: ToolResult,
    ) -> str | None:
        """Return coaching text to append, or ``None``."""

    def on_round_complete(
        self,
        tool_names: list[str] | None,
        **kwargs: Any,
    ) -> list[str]:
        _ = tool_names, kwargs
        return []

    def should_block_budget_expansion(
        self,
        tool_name: str,
        args: dict[str, Any],
        result: ToolResult,
    ) -> bool:
        _ = tool_name, args, result
        return False

    def should_terminate_run(self) -> bool:
        return False

    def on_peer_round_messages(self, messages: list[str]) -> None:
        """Observe coaching emitted by other guards in the same round."""

        _ = messages

    def reset(self) -> None:
        """Reset run-scoped state at the start of each run."""


class GuardManager:
    """Run and aggregate multiple tool guards in declared order."""

    def __init__(self, guards: list[ToolGuard], *, phase_header: str = "") -> None:
        self._guards = list(guards)
        self._phase_header = (phase_header or "").strip()
        self._write_success_count = 0
        self._edit_success_count = 0
        self._round_write_edit_success = False

    def process_tool_result(
        self,
        tool_name: str,
        args: dict[str, Any],
        result: ToolResult,
    ) -> str:
        if not result.error:
            if tool_name == "write":
                self._write_success_count += 1
            elif tool_name == "edit":
                self._edit_success_count += 1
            if tool_name in {"write", "edit"}:
                self._round_write_edit_success = True
        parts: list[str] = []
        for guard in self._guards:
            message = guard.on_tool_result(tool_name, args, result)
            if isinstance(message, str) and message.strip():
                parts.append(message.strip())
        return "\n\n".join(parts)

    def process_round_complete(self, tool_names: list[str] | None) -> list[str]:
        out: list[str] = []
        round_kwargs: dict[str, Any] = {"write_edit_success": bool(self._round_write_edit_success)}
        for guard in self._guards:
            messages = guard.on_round_complete(tool_names, peer_injected=bool(out), **round_kwargs)
            clean = [
                message.strip()
                for message in messages
                if isinstance(message, str) and message.strip()
            ]
            if clean:
                for peer in self._guards:
                    if peer is not guard:
                        peer.on_peer_round_messages(clean)
                out.extend(clean)
        self._round_write_edit_success = False
        if not self._phase_header:
            return out
        return [
            f"{self._phase_header}\n\n{message}" if message.strip() else message for message in out
        ]

    def any_blocks_budget_expansion(
        self,
        tool_name: str,
        args: dict[str, Any],
        result: ToolResult,
    ) -> bool:
        return any(
            guard.should_block_budget_expansion(tool_name, args, result) for guard in self._guards
        )

    def should_terminate_run(self) -> bool:
        return any(guard.should_terminate_run() for guard in self._guards)

    def productivity_counters(self) -> dict[str, int]:
        return {
            "write_success_count": int(self._write_success_count),
            "edit_success_count": int(self._edit_success_count),
        }

    def reset_all(self) -> None:
        self._write_success_count = 0
        self._edit_success_count = 0
        self._round_write_edit_success = False
        for guard in self._guards:
            guard.reset()
