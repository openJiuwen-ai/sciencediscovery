from __future__ import annotations

import json
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from .base import ToolContext, ToolResult, coerce_tool_result
from .collection import ToolCollection


@dataclass(frozen=True, slots=True)
class ToolInvocation:
    id: str
    name: str
    arguments: Mapping[str, Any]

    @classmethod
    def from_openai(cls, value: Any) -> "ToolInvocation":
        function = (
            value.get("function")
            if isinstance(value, Mapping)
            else getattr(value, "function", None)
        ) or {}
        raw = (
            function.get("arguments")
            if isinstance(function, Mapping)
            else getattr(function, "arguments", "{}")
        ) or "{}"
        arguments = json.loads(raw) if isinstance(raw, str) else dict(raw)
        if not isinstance(arguments, dict):
            raise ValueError("Tool arguments must decode to a JSON object")
        call_id = value.get("id") if isinstance(value, Mapping) else getattr(value, "id", "")
        name = (
            function.get("name") if isinstance(function, Mapping) else getattr(function, "name", "")
        )
        return cls(
            id=str(call_id or ""),
            name=str(name or ""),
            arguments=arguments,
        )


class ToolExecutor:
    def __init__(self, tools: ToolCollection) -> None:
        self.tools = tools

    async def execute(self, invocation: ToolInvocation, context: ToolContext) -> ToolResult:
        context.cancellation.raise_if_cancelled()
        try:
            tool = self.tools.get(invocation.name)
            return coerce_tool_result(await tool.invoke(invocation.arguments, context))
        except Exception as exc:
            return ToolResult(error=f"{type(exc).__name__}: {exc}")
