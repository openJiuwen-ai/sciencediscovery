"""Configurable file tools shared by InquiryCraft hosts."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, ClassVar

from .base import BaseTool, ToolResult, _tool_field, _tool_schema
from .filesystem import (
    DEFAULT_RETURN_FULL_MAX_CHARS,
    DEFAULT_RETURN_FULL_MAX_LINES,
    DEFAULT_RETURN_HEAD_TAIL_LINES,
    edit_file,
    format_file_snapshot,
    looks_like_write_placeholder_mimicry,
    read_path,
    write_file,
)
from .filesystem.edit import (
    change_context,
    context_around_lines,
    diagnose_not_found,
    python_symbol_for_line,
    suggest_old_str_anchor,
    top_line_block_matches,
)
from .filesystem.search import rewrite_rg_line_path as rewrite_rg_line_path
from .path_policy import PathPolicy

logger = logging.getLogger(__name__)

_CONTENT_ALIASES = ("body", "text", "file_contents")
format_file_snapshot_for_tool_return = format_file_snapshot


class FileTool(BaseTool):
    """Dependency-light base for file tools with an injected path policy."""

    defaults: ClassVar[dict[str, Any]] = {
        "sandbox": True,
        "path_guard_extra_roots": (),
        "path_guard_denied_prefixes": (),
        "display_paths_relative": True,
        "display_root": None,
    }

    def __init__(
        self,
        *,
        root_dir: str | Path | None = None,
        path_policy: PathPolicy | None = None,
        workspace_dir: str | Path | None = None,
        **kwargs: Any,
    ) -> None:
        values = {**self.defaults, **kwargs}
        for key, value in values.items():
            setattr(self, key, value)
        root = root_dir if root_dir is not None else workspace_dir
        if path_policy is None:
            path_policy = PathPolicy(
                Path.cwd() if root is None else root,
                enabled=bool(self.sandbox),
                extra_roots=self.path_guard_extra_roots,
                denied_prefixes=self.path_guard_denied_prefixes,
            )
        elif root is not None and Path(root).resolve() != path_policy.root:
            raise ValueError("root_dir/workspace_dir conflicts with path_policy.root")
        self.path_policy = path_policy
        self.root_dir = path_policy.root
        self.sandbox = path_policy.containment_enabled
        self.path_guard_extra_roots = path_policy.extra_roots
        self.path_guard_denied_prefixes = path_policy.denied_prefixes
        # Read-only compatibility for hosts that inspect the historical field.
        self.workspace_dir = self.root_dir


class ReadTool(FileTool):
    name = "read"
    description = (
        "Read a text file with line numbers, or list a directory tree. "
        "Use offset/limit to page through large files (default 200 lines per call). "
        "Always provide path on every call; when paging, repeat the same path with the new offset."
    )
    parameters = _tool_schema(
        "path",
        path=_tool_field(
            "string", "Path relative to workspace. Required on every call, including paging calls."
        ),
        offset=_tool_field("integer", "1-based start line. Default 1."),
        limit=_tool_field(
            "integer", "Max lines to return; default 200. Use 0 for entire file (careful)."
        ),
    )

    async def execute(
        self,
        path: str | None = None,
        offset: int = 1,
        limit: int = 200,
        **kwargs: Any,
    ) -> ToolResult:
        kwargs.pop("config", None)
        return read_path(
            self.root_dir,
            path,
            offset=offset,
            limit=limit,
            sandbox=self.sandbox,
            extra_roots=self.path_guard_extra_roots,
            denied_prefixes=self.path_guard_denied_prefixes,
            logical_paths=bool(self.display_paths_relative),
            display_root=self.display_root,
            path_policy=self.path_policy,
            result_factory=ToolResult,
        )


class WriteTool(FileTool):
    name = "write"
    description = (
        "Create or overwrite a file under the workspace with the given full content. "
        "Syntax is validated for .py / .json / .yaml before write."
    )
    parameters = _tool_schema(
        "path",
        "content",
        path=_tool_field("string", "Path relative to workspace root."),
        content=_tool_field("string", "Complete new file contents."),
    )
    defaults = {
        **FileTool.defaults,
        "return_full_max_chars": DEFAULT_RETURN_FULL_MAX_CHARS,
        "return_full_max_lines": DEFAULT_RETURN_FULL_MAX_LINES,
        "return_head_tail_lines": DEFAULT_RETURN_HEAD_TAIL_LINES,
    }

    async def execute(
        self,
        path: str | None = None,
        content: str | None = None,
        **kwargs: Any,
    ) -> ToolResult:
        kwargs.pop("config", None)
        if content is None:
            for alias in _CONTENT_ALIASES:
                if alias in kwargs and kwargs[alias] is not None:
                    content = kwargs.pop(alias)
                    break
        path_value = str(path).strip() if path is not None else ""
        if not path_value:
            return ToolResult(error="write requires non-empty 'path' (relative to workspace root).")
        if content is None:
            extra_keys = sorted(key for key in kwargs if key not in _CONTENT_ALIASES)
            logger.warning(
                "write missing 'content'; path=%r; other_kwarg_keys=%s",
                path_value,
                extra_keys,
            )
            return ToolResult(
                error=(
                    "write requires 'content' (complete file body). "
                    "If content is missing, the model may have omitted it in the tool JSON, "
                    "used a non-standard key, or the tool arguments were truncated by the API."
                )
            )
        if looks_like_write_placeholder_mimicry(content):
            return ToolResult(
                error=(
                    "write rejected: `content` looks like a log/memory placeholder or compressed "
                    "memory snippet (e.g. `<<<WRITE_PLACEHOLDER: ...>>>`, `<<<WRITE_CONTENT: ...>>>`, "
                    "`[interaction-log: write body omitted; N chars applied by tool]`, "
                    "`# [chat-memory: write payload omitted (N bytes); ...]`, "
                    "`<N chars>`, or lines with `# <<<WRITE_OK:` / `# <<<MEMORY_COMPRESSED:` / "
                    "`# [MEMORY_COMPRESSED:`), not real file text. "
                    "Put the **complete** file body in the `content` field (use **read** if needed)."
                )
            )
        return write_file(
            self.root_dir,
            path_value,
            content,
            sandbox=self.sandbox,
            extra_roots=self.path_guard_extra_roots,
            denied_prefixes=self.path_guard_denied_prefixes,
            return_full_max_chars=self.return_full_max_chars,
            return_full_max_lines=self.return_full_max_lines,
            return_head_tail_lines=self.return_head_tail_lines,
            path_policy=self.path_policy,
            result_factory=ToolResult,
        )


class EditTool(FileTool):
    name = "edit"
    description = (
        "Replace exactly one occurrence of old_str with new_str in a workspace file. "
        "old_str must match the file byte-for-byte once; include enough context to be unique."
    )
    parameters = _tool_schema(
        "path",
        "old_str",
        "new_str",
        path=_tool_field("string", "File path relative to workspace."),
        old_str=_tool_field("string", "Exact text to find (must appear exactly once)."),
        new_str=_tool_field("string", "Replacement text."),
    )
    defaults = {
        **FileTool.defaults,
        "return_full_max_chars": DEFAULT_RETURN_FULL_MAX_CHARS,
        "return_full_max_lines": DEFAULT_RETURN_FULL_MAX_LINES,
        "return_head_tail_lines": DEFAULT_RETURN_HEAD_TAIL_LINES,
        "return_change_ctx_lines": 8,
        "failure_top_k_candidates": 3,
        "failure_diag_max_chars": 2000,
    }
    _diagnose_not_found = staticmethod(diagnose_not_found)
    _top_k_line_block_matches = staticmethod(top_line_block_matches)
    _context_around_lines = staticmethod(context_around_lines)
    _python_symbol_for_line = staticmethod(python_symbol_for_line)
    _suggest_old_str_anchor = staticmethod(suggest_old_str_anchor)
    _change_context = staticmethod(change_context)

    async def execute(
        self,
        path: str,
        old_str: str,
        new_str: str,
        **kwargs: Any,
    ) -> ToolResult:
        kwargs.pop("config", None)
        return edit_file(
            self.root_dir,
            path,
            old_str,
            new_str,
            sandbox=self.sandbox,
            extra_roots=self.path_guard_extra_roots,
            denied_prefixes=self.path_guard_denied_prefixes,
            return_full_max_chars=self.return_full_max_chars,
            return_full_max_lines=self.return_full_max_lines,
            return_head_tail_lines=self.return_head_tail_lines,
            return_change_ctx_lines=self.return_change_ctx_lines,
            failure_top_k_candidates=self.failure_top_k_candidates,
            failure_diag_max_chars=self.failure_diag_max_chars,
            path_policy=self.path_policy,
            result_factory=ToolResult,
        )
