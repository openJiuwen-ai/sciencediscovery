# SPDX-License-Identifier: MIT

"""Loss-preserving reducers for model-visible shell output."""

from __future__ import annotations

import hashlib
import re

from .shell_output import (
    sanitize_host_absolute_paths as _sanitize_host_absolute_paths,  # noqa: F401
)
from .shell_output import (
    sanitize_python_env_paths as _sanitize_python_env_paths,  # noqa: F401
)
from .shell_output import (
    sanitize_root_prefix as _sanitize_root_prefix_in_output,  # noqa: F401
)
from .shell_output import (
    sanitize_shell_output_paths as _sanitize_model_visible_output_paths,  # noqa: F401
)
from .shell_output import (
    sanitize_workspace_prefix as _sanitize_workspace_prefix_in_output,  # noqa: F401
)
from .shell_output import (
    strip_symlink_targets as _strip_symlink_targets,  # noqa: F401
)
from .shell_output import (
    trim_shell_output as _trim_output,  # noqa: F401
)
from .shell_traceback import distill_tracebacks, has_masked_python_traceback

_OBSERVATION_EXEC_RE = re.compile(
    r"(^|[;\n&|()]\s*)(?:timeout\s+\S+\s+)?(?:env\s+\S+=\S+\s+)*"
    r"(?:ls|find|cat|head|tail|sed|wc|du|stat|ps)\b",
)


_CAT_WRITE_OR_HEREDOC_RE = re.compile(r"(^|[;\n&|()]\s*)cat\s*(?:>|>>|<<)")


_COMPUTE_EXEC_RE = re.compile(
    r"(^|[;\n&|()]\s*)(?:timeout\s+\S+\s+)?(?:env\s+\S+=\S+\s+)*"
    r"(?:python(?:3)?|uv|pip(?:3)?|pytest|mlebench|kaggle|git)\b",
)


def _looks_like_lossless_observation_command(command: str) -> bool:
    """Return true for read-only observation commands worth summarizing losslessly.

    This is intentionally conservative: it never rewrites or blocks execution,
    and it avoids Python/training/install/git commands where stdout carries
    progress or error semantics better handled by existing reducers.
    """
    cmd = str(command or "").strip()
    if not cmd:
        return False
    if _CAT_WRITE_OR_HEREDOC_RE.search(cmd):
        return False
    if _COMPUTE_EXEC_RE.search(cmd):
        return False
    return bool(_OBSERVATION_EXEC_RE.search(cmd))


def _edge_lines_for_lossless_summary(
    lines: list[str],
    *,
    max_chars: int,
) -> tuple[list[str], list[str]]:
    if not lines:
        return [], []
    # Keep the visible summary comfortably below exec_feedback_max_chars while
    # preserving exact prefix/suffix evidence. The full raw output is carried
    # separately in ToolResult.system for artifact storage.
    budget = max(1200, min(max_chars if max_chars > 0 else 6000, 6000))
    edge_lines = max(8, min(40, budget // 180))
    if len(lines) <= edge_lines * 2:
        return lines, []
    return lines[:edge_lines], lines[-edge_lines:]


def _lossless_observation_summary(
    text: str,
    *,
    command: str,
    max_chars: int,
) -> str:
    raw_bytes = len(text.encode("utf-8", errors="replace"))
    raw_chars = len(text)
    raw_lines = len(text.splitlines())
    sha = hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()
    lines = text.splitlines()
    head, tail = _edge_lines_for_lossless_summary(lines, max_chars=max_chars)
    omitted = max(0, raw_lines - len(head) - len(tail))
    command_one_line = re.sub(r"\s+", " ", str(command or "")).strip()
    if len(command_one_line) > 240:
        command_one_line = command_one_line[:237].rstrip() + "..."
    parts = [
        (
            "[tool-output compressed: reducer=bash_observation_head_tail_v1 "
            f"raw_chars={raw_chars} raw_bytes={raw_bytes} raw_lines={raw_lines} "
            f"sha256={sha[:16]}]"
        ),
        "Visible output is an exact head/tail projection, not the complete output.",
        f"command: {command_one_line}",
    ]
    if head:
        parts.append(f"--- head first {len(head)} lines ---")
        parts.extend(head)
    if tail:
        parts.append(f"--- omitted middle: {omitted} lines ---")
        parts.append(f"--- tail last {len(tail)} lines ---")
        parts.extend(tail)
    return "\n".join(parts)


def _maybe_lossless_observation_summary(
    *,
    command: str,
    output: str,
    enabled: bool,
    max_chars: int,
    returncode: int,
) -> tuple[str, str | None]:
    """Return ``(visible_output, raw_for_artifact)`` for large observation output."""
    if not enabled or returncode != 0:
        return output, None
    if max_chars <= 0 or len(output) <= max_chars:
        return output, None
    if not _looks_like_lossless_observation_command(command):
        return output, None
    return (
        _lossless_observation_summary(output, command=command, max_chars=max_chars),
        output,
    )


def _dedup_repeated_blocks(
    text: str,
    *,
    min_repeat: int = 3,
    max_block_size: int = 4,
) -> str:
    """Collapse consecutive identical line-blocks when repeated at least *min_repeat* times.

    Tries block sizes from *max_block_size* down to 1 at each position so that
    multi-line patterns (e.g. warning + code line) are folded as a unit when possible.
    If *min_repeat* is 0, returns *text* unchanged.
    """
    if min_repeat <= 0 or not text:
        return text
    lines = text.splitlines()
    if not lines:
        return text
    out: list[str] = []
    i = 0
    n = len(lines)
    while i < n:
        best_end: int | None = None
        best_block_size = 1
        best_repeat = 1
        max_bs = min(max_block_size, n - i)
        for block_size in range(max_bs, 0, -1):
            block = lines[i : i + block_size]
            pos = i + block_size
            repeat_count = 1
            while pos + block_size <= n and lines[pos : pos + block_size] == block:
                repeat_count += 1
                pos += block_size
            if repeat_count >= min_repeat:
                best_end = pos
                best_block_size = block_size
                best_repeat = repeat_count
                break
        if best_end is not None:
            out.extend(lines[i : i + best_block_size])
            out.append(
                f"[... above {best_block_size}-line block repeated {best_repeat} times total, collapsed]"
            )
            i = best_end
        else:
            out.append(lines[i])
            i += 1
    return "\n".join(out)


# Public host-extension surface. Keep the historical aliases inside this module
# until downstream applications have migrated.
deduplicate_repeated_blocks = _dedup_repeated_blocks
maybe_lossless_observation_summary = _maybe_lossless_observation_summary
_distill_tracebacks = distill_tracebacks
_has_masked_python_traceback = has_masked_python_traceback
