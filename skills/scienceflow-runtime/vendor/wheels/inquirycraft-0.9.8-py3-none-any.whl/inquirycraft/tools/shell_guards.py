"""Composable, host-supplied shell guard pipeline."""

from __future__ import annotations

from collections.abc import Callable, Iterable
from dataclasses import dataclass

ShellGuardCheck = Callable[[str], str | None]


@dataclass(frozen=True, slots=True)
class ShellGuardRule:
    """A named first-error-wins shell command rule."""

    name: str
    check: ShellGuardCheck

    def evaluate(self, command: str) -> str | None:
        return self.check(command)


@dataclass(frozen=True, slots=True)
class ShellGuardDecision:
    command: str
    blocked_by: str | None = None
    error: str | None = None

    @property
    def allowed(self) -> bool:
        return self.error is None


def evaluate_shell_guards(
    command: str,
    rules: Iterable[ShellGuardRule],
) -> ShellGuardDecision:
    """Evaluate rules in declared order and preserve the first exact error."""

    for rule in rules:
        error = rule.evaluate(command)
        if error:
            return ShellGuardDecision(command=command, blocked_by=rule.name, error=error)
    return ShellGuardDecision(command=command)
