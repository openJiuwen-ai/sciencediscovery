"""Bounded ripgrep search with policy-stable paths."""

from __future__ import annotations

import asyncio
import shutil
from collections.abc import Callable, Sequence
from pathlib import Path
from typing import Any

from ..base import ToolResult
from ..path_policy import PathPolicy, display_from_request, join_display_path

RG_MAX_COLUMNS = 20_000
RG_STREAM_LIMIT = 1024 * 1024
ResultFactory = Callable[..., Any]


def rewrite_rg_line_path(line: str, *, logical_label: str, target_is_file: bool) -> str:
    """Rewrite ripgrep's filename prefix to the requested logical path."""
    if ":" not in line:
        return line
    file_part, rest = line.split(":", 1)
    shown = file_part[2:] if file_part.startswith("./") else file_part
    if target_is_file:
        relative = logical_label
    else:
        relative = "." if shown in ("", ".") else shown
        relative = join_display_path(logical_label, relative)
    return f"{relative}:{rest}"


def _search_command(
    executable: str,
    pattern: str,
    search_path: str,
    *,
    include: str,
    file_type: str,
    denied_prefixes: Sequence[str | Path],
) -> list[str]:
    command = [
        executable,
        "--line-number",
        "--with-filename",
        "--color=never",
        "--max-columns",
        str(RG_MAX_COLUMNS),
        "--max-columns-preview",
    ]
    exclusions = (
        "**/.git/**",
        "**/.venv/**",
        "**/node_modules/**",
        "**/__pycache__/**",
        "**/.pytest_cache/**",
        "**/.mypy_cache/**",
        "**/.ruff_cache/**",
    )
    for excluded in exclusions:
        command.extend(["-g", f"!{excluded}"])
    for prefix in denied_prefixes:
        clean = str(prefix or "").strip().strip("/")
        if clean:
            command.extend(["-g", f"!{clean}/**", "-g", f"!**/{clean}/**"])
    if file_type.strip():
        command.extend(["-t", file_type.strip()])
    if include.strip():
        command.extend(["-g", include.strip()])
    command.extend(["--", pattern, search_path])
    return command


def _search_location(resolved: Path, workspace_root: Path) -> tuple[Path, str, bool, bool]:
    target_is_file = resolved.is_file()
    try:
        relative = resolved.relative_to(workspace_root)
        search_path = "." if str(relative) == "." else relative.as_posix()
        return workspace_root, search_path, False, target_is_file
    except ValueError:
        if target_is_file:
            return resolved.parent, resolved.name, True, True
        return resolved, ".", True, False


async def grep_path(
    root: str | Path,
    pattern: str,
    *,
    path: str = ".",
    include: str = "",
    file_type: str = "",
    max_results_lines: int = 50,
    sandbox: bool = True,
    extra_roots: Sequence[str | Path] = (),
    denied_prefixes: Sequence[str | Path] = (),
    logical_paths: bool = True,
    display_root: str | Path | None = None,
    result_factory: ResultFactory = ToolResult,
    path_policy: PathPolicy | None = None,
):
    if not pattern.strip():
        return result_factory(error="Empty search pattern")
    guard = path_policy or PathPolicy(
        root, enabled=sandbox, extra_roots=extra_roots, denied_prefixes=denied_prefixes
    )
    try:
        resolved = guard.resolve(path)
    except ValueError as exc:
        return result_factory(error=str(exc))
    executable = shutil.which("rg")
    if executable is None:
        return result_factory(error="rg binary not found on PATH")
    logical_label = display_from_request(
        guard.root, resolved, path, logical_paths=logical_paths, display_root=display_root
    )
    search_cwd, search_path, remap_paths, target_is_file = _search_location(resolved, guard.root)
    command = _search_command(
        executable,
        pattern,
        search_path,
        include=include,
        file_type=file_type,
        denied_prefixes=denied_prefixes,
    )
    process = await asyncio.create_subprocess_exec(
        *command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        cwd=str(search_cwd),
        limit=RG_STREAM_LIMIT,
    )
    cap = max(1, int(max_results_lines))
    raw_lines: list[str] = []
    killed_for_limit = False
    deadline = asyncio.get_running_loop().time() + 30.0
    try:
        while True:
            remaining = deadline - asyncio.get_running_loop().time()
            if remaining <= 0:
                process.kill()
                await process.wait()
                return result_factory(error="Search timed out after 30s")
            assert process.stdout is not None
            try:
                line_bytes = await asyncio.wait_for(process.stdout.readline(), timeout=remaining)
            except ValueError:
                process.kill()
                await process.wait()
                return result_factory(
                    error=(
                        "Search output line exceeded the internal read limit even after "
                        f"rg preview truncation at {RG_MAX_COLUMNS} columns; narrow the search."
                    )
                )
            if not line_bytes:
                break
            line = line_bytes.decode(errors="replace").rstrip("\n")
            if not line.strip():
                continue
            if remap_paths:
                line = rewrite_rg_line_path(
                    line, logical_label=logical_label, target_is_file=target_is_file
                )
            raw_lines.append(line)
            if len(raw_lines) > cap:
                killed_for_limit = True
                process.kill()
                break
    except TimeoutError:
        process.kill()
        await process.wait()
        return result_factory(error="Search timed out after 30s")
    try:
        await asyncio.wait_for(process.wait(), timeout=2)
    except TimeoutError:
        process.kill()
        await process.wait()
    stderr_bytes = b""
    if process.stderr is not None:
        try:
            stderr_bytes = await asyncio.wait_for(process.stderr.read(), timeout=1)
        except TimeoutError:
            pass
    stderr = stderr_bytes.decode(errors="replace").strip()
    if not killed_for_limit and process.returncode not in (0, 1):
        return result_factory(error=stderr or f"rg failed with code {process.returncode}")
    if not raw_lines:
        return result_factory(output=f"No matches for pattern: {pattern!r}")
    output = "\n".join(raw_lines[:cap])
    total = len(raw_lines)
    if killed_for_limit:
        output += f"\n... [more matches omitted, stopped after limit={cap}]"
    elif total > cap:
        output += f"\n... [{total - cap} more matches omitted, {total} total]"
    else:
        output += f"\n[{total} matches]"
    return result_factory(output=output)


# Historical function name retained as a non-owning API alias.
grep_workspace = grep_path
