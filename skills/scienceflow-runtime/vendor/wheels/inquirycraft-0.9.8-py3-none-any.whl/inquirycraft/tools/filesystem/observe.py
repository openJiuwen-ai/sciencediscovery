"""Reusable, model-facing filesystem observation operations."""

from __future__ import annotations

from collections.abc import Callable, Sequence
from pathlib import Path
from typing import Any

from ..base import ToolResult
from ..path_policy import PathPolicy, display_from_request, join_display_path

ResultFactory = Callable[..., Any]


def _directory_tree(root: Path, label: str, *, max_entries: int = 400, max_depth: int = 4) -> str:
    lines: list[str] = [f"[directory listing: {label}]"]
    count = 0

    def walk(current: Path, depth: int) -> None:
        nonlocal count
        if depth > max_depth or count >= max_entries:
            return
        try:
            entries = sorted(
                current.iterdir(), key=lambda path: (not path.is_dir(), path.name.lower())
            )
        except OSError as exc:
            lines.append(f"  (cannot read: {exc})")
            return
        for entry in entries:
            if count >= max_entries:
                lines.append("  ... (truncated)")
                return
            if entry.name.startswith(".") and entry.name not in (".", ".."):
                continue
            relative = entry.relative_to(root)
            indent = "  " * depth
            if entry.is_dir():
                lines.append(f"{indent}{relative.as_posix()}/")
                count += 1
                walk(entry, depth + 1)
            else:
                try:
                    size = entry.stat().st_size
                except OSError:
                    size = -1
                lines.append(f"{indent}{relative.as_posix()} ({size} bytes)")
                count += 1

    walk(root, 0)
    return "\n".join(lines)


def read_path(
    root: str | Path,
    path: str | None,
    *,
    offset: int = 1,
    limit: int = 200,
    sandbox: bool = True,
    extra_roots: Sequence[str | Path] = (),
    denied_prefixes: Sequence[str | Path] = (),
    logical_paths: bool = True,
    display_root: str | Path | None = None,
    result_factory: ResultFactory = ToolResult,
    path_policy: PathPolicy | None = None,
):
    path_value = str(path).strip() if path is not None else ""
    if not path_value:
        return result_factory(
            error=(
                "read requires non-empty 'path' (relative to workspace root). "
                "When paging with offset/limit, repeat the same path; there is no implicit previous file."
            )
        )
    guard = path_policy or PathPolicy(
        root,
        enabled=sandbox,
        extra_roots=extra_roots,
        denied_prefixes=denied_prefixes,
    )
    try:
        resolved = guard.resolve(path_value)
    except ValueError as exc:
        return result_factory(error=str(exc))
    if not resolved.exists():
        return result_factory(error=f"Path not found: {path_value}")
    label = display_from_request(
        guard.root,
        resolved,
        path_value,
        logical_paths=logical_paths,
        display_root=display_root,
    )
    if resolved.is_dir():
        return result_factory(output=_directory_tree(resolved, label))
    lines = resolved.read_text(encoding="utf-8", errors="replace").splitlines()
    total = len(lines)
    start = max(0, int(offset) - 1)
    requested_limit = int(limit)
    end = total if requested_limit <= 0 else min(total, start + requested_limit)
    numbered = "\n".join(
        f"{index:>6}|{line}" for index, line in enumerate(lines[start:end], start=start + 1)
    )
    meta = f"[{label}: {total} lines total"
    if end < total or start > 0:
        meta += f", showing {start + 1}-{end if end >= start else start}"
    return result_factory(output=f"{meta}]\n{numbered}")


def _has_hidden_part(path: Path, base: Path) -> bool:
    try:
        relative = path.relative_to(base)
    except ValueError:
        relative = path
    return any(part.startswith(".") for part in relative.parts if part not in ("", "."))


def glob_paths(
    root: str | Path,
    pattern: str,
    *,
    path: str = ".",
    include_dirs: bool = False,
    include_hidden: bool = False,
    limit: int = 200,
    max_results: int = 1000,
    sandbox: bool = True,
    extra_roots: Sequence[str | Path] = (),
    denied_prefixes: Sequence[str | Path] = (),
    logical_paths: bool = True,
    display_root: str | Path | None = None,
    result_factory: ResultFactory = ToolResult,
    path_policy: PathPolicy | None = None,
):
    pattern = str(pattern or "").strip()
    if not pattern:
        return result_factory(error="glob tool requires non-empty 'pattern' argument")
    if Path(pattern).is_absolute() or ".." in pattern.replace("\\", "/").split("/"):
        return result_factory(error="glob pattern must be relative and must not contain '..'")
    guard = path_policy or PathPolicy(
        root, enabled=sandbox, extra_roots=extra_roots, denied_prefixes=denied_prefixes
    )
    try:
        resolved = guard.resolve(path)
    except ValueError as exc:
        return result_factory(error=str(exc))
    if not resolved.exists():
        return result_factory(error=f"Path not found: {path}")
    if not resolved.is_dir():
        return result_factory(error=f"Path is not a directory: {path}")
    cap = max(1, min(int(limit or 200), int(max_results)))
    matches: list[Path] = []
    truncated = False
    try:
        for candidate in resolved.glob(pattern):
            if guard.is_denied(candidate):
                continue
            try:
                guard.resolve(candidate)
            except ValueError:
                continue
            if not include_hidden and _has_hidden_part(candidate, resolved):
                continue
            if candidate.is_dir() and not include_dirs:
                continue
            if not candidate.is_dir() and not candidate.is_file():
                continue
            if len(matches) >= cap:
                truncated = True
                break
            matches.append(candidate)
    except (OSError, RuntimeError, ValueError) as exc:
        return result_factory(error=f"glob failed: {exc}")
    label = display_from_request(
        guard.root, resolved, path, logical_paths=logical_paths, display_root=display_root
    )
    if not matches:
        return result_factory(output=f"[glob: {pattern!r} under {label}]\nNo matches")

    def shown(candidate: Path) -> str:
        try:
            relative = candidate.relative_to(resolved).as_posix()
        except ValueError:
            relative = candidate.name
        value = join_display_path(label, relative)
        return value + "/" if candidate.is_dir() else value

    matches.sort(key=lambda candidate: shown(candidate).lower())
    lines = [f"[glob: {pattern!r} under {label}]", *(shown(item) for item in matches)]
    lines.append(
        f"... [more matches omitted, limit={cap}]" if truncated else f"[{len(matches)} matches]"
    )
    return result_factory(output="\n".join(lines))


def _entry_kind(path: Path) -> str:
    if path.is_symlink():
        try:
            if path.is_dir():
                return "DIRLINK"
            if path.is_file():
                return "FILELINK"
        except OSError:
            pass
        return "LINK"
    if path.is_dir():
        return "DIR"
    if path.is_file():
        return "FILE"
    return "OTHER"


def list_path(
    root: str | Path,
    *,
    path: str = ".",
    recursive: bool = False,
    depth: int = 2,
    include_hidden: bool = False,
    limit: int = 200,
    max_results: int = 1000,
    max_depth: int = 8,
    sandbox: bool = True,
    extra_roots: Sequence[str | Path] = (),
    denied_prefixes: Sequence[str | Path] = (),
    logical_paths: bool = True,
    display_root: str | Path | None = None,
    result_factory: ResultFactory = ToolResult,
    path_policy: PathPolicy | None = None,
):
    guard = path_policy or PathPolicy(
        root, enabled=sandbox, extra_roots=extra_roots, denied_prefixes=denied_prefixes
    )
    try:
        resolved = guard.resolve(path)
    except ValueError as exc:
        return result_factory(error=str(exc))
    if not resolved.exists():
        return result_factory(error=f"Path not found: {path}")
    label = display_from_request(
        guard.root, resolved, path, logical_paths=logical_paths, display_root=display_root
    )
    if resolved.is_file():
        try:
            size = resolved.stat().st_size
        except OSError:
            size = -1
        return result_factory(output=f"[ls: {label}]\nFILE {label} ({size} bytes)")
    if not resolved.is_dir():
        return result_factory(error=f"Path is not a file or directory: {path}")
    cap = max(1, min(int(limit or 200), int(max_results)))
    allowed_depth = max(0, min(int(depth or 0), int(max_depth))) if recursive else 0
    lines = [f"[ls: {label}]"]
    count = 0
    truncated = False

    def display(entry: Path) -> str:
        try:
            relative = entry.relative_to(resolved).as_posix()
        except ValueError:
            relative = entry.name or "."
        return join_display_path(label, relative)

    def walk(current: Path, relative_depth: int) -> None:
        nonlocal count, truncated
        if truncated:
            return
        try:
            entries = sorted(
                current.iterdir(), key=lambda item: (not item.is_dir(), item.name.lower())
            )
        except OSError as exc:
            lines.append(f"{'  ' * relative_depth}(cannot read: {exc})")
            return
        for entry in entries:
            if count >= cap:
                truncated = True
                lines.append(f"... [more entries omitted, limit={cap}]")
                return
            if not include_hidden and _has_hidden_part(entry, resolved):
                continue
            if guard.is_denied(entry):
                continue
            try:
                guard.resolve(entry)
            except ValueError:
                lines.append(f"{'  ' * relative_depth}BLOCKED {display(entry)}")
                count += 1
                continue
            kind = _entry_kind(entry)
            suffix = "/" if kind in {"DIR", "DIRLINK"} else ""
            size = ""
            if kind in {"FILE", "FILELINK"}:
                try:
                    size = f" ({entry.stat().st_size} bytes)"
                except OSError:
                    size = " (size unknown)"
            lines.append(f"{'  ' * relative_depth}{kind} {display(entry)}{suffix}{size}")
            count += 1
            if recursive and relative_depth < allowed_depth and kind in {"DIR", "DIRLINK"}:
                walk(entry, relative_depth + 1)

    walk(resolved, 0)
    if not truncated:
        lines.append(f"[{count} entries]")
    return result_factory(output="\n".join(lines))


# Historical function names retained as non-owning API aliases.
glob_workspace = glob_paths
list_workspace = list_path
read_workspace = read_path
