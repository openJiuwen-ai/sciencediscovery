"""Reusable filesystem mutation operations with stable model feedback."""

from __future__ import annotations

import ast
import hashlib
from collections.abc import Callable, Sequence
from pathlib import Path
from typing import Any

from ..base import ToolResult
from ..path_policy import PathPolicy, atomic_write, display_under_root, validate_syntax

DEFAULT_RETURN_FULL_MAX_CHARS = 12000
DEFAULT_RETURN_FULL_MAX_LINES = 250
DEFAULT_RETURN_HEAD_TAIL_LINES = 40

ResultFactory = Callable[..., Any]


def python_ast_smoke_hints(source: str) -> str | None:
    """Return non-blocking hints for apparently unused top-level imports."""
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return None
    imported: set[str] = set()
    for node in tree.body:
        if isinstance(node, ast.Import):
            imported.update((alias.asname or alias.name).split(".")[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            imported.update(
                (alias.asname or alias.name).split(".")[0]
                for alias in node.names
                if alias.name != "*"
            )
    used = {
        node.id
        for node in ast.walk(tree)
        if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load)
    }
    unused = sorted(name for name in imported if name not in used and not name.startswith("_"))
    if not unused:
        return None
    return (
        "Possible unused top-level imports (heuristic, not exhaustive): "
        + ", ".join(unused[:12])
        + (" …" if len(unused) > 12 else "")
    )


def format_file_snapshot(
    content: str,
    *,
    max_chars: int = DEFAULT_RETURN_FULL_MAX_CHARS,
    max_lines: int = DEFAULT_RETURN_FULL_MAX_LINES,
    head_tail_lines: int = DEFAULT_RETURN_HEAD_TAIL_LINES,
) -> str:
    """Return a numbered full or head/tail snapshot for model feedback."""
    if not content:
        return ""
    lines = content.splitlines()
    total = len(lines)
    if total == 0:
        return ""
    if len(content) <= max_chars and total <= max_lines:
        return "\n".join(f"{index:>6}|{line}" for index, line in enumerate(lines, 1))
    edge = max(1, head_tail_lines)
    if total <= 2 * edge + 2:
        return "\n".join(f"{index:>6}|{line}" for index, line in enumerate(lines, 1))
    head = "\n".join(f"{index:>6}|{line}" for index, line in enumerate(lines[:edge], 1))
    tail = "\n".join(
        f"{index:>6}|{line}" for index, line in enumerate(lines[-edge:], total - edge + 1)
    )
    return f"{head}\n  ... ({total - 2 * edge} lines omitted) ...\n{tail}"


def write_file(
    root: str | Path,
    path: str,
    content: str,
    *,
    sandbox: bool = True,
    extra_roots: Sequence[str | Path] = (),
    denied_prefixes: Sequence[str | Path] = (),
    return_full_max_chars: int = DEFAULT_RETURN_FULL_MAX_CHARS,
    return_full_max_lines: int = DEFAULT_RETURN_FULL_MAX_LINES,
    return_head_tail_lines: int = DEFAULT_RETURN_HEAD_TAIL_LINES,
    result_factory: ResultFactory = ToolResult,
    path_policy: PathPolicy | None = None,
):
    """Validate and atomically write a complete file under the policy root."""
    try:
        policy = path_policy or PathPolicy(
            root,
            enabled=sandbox,
            extra_roots=extra_roots,
            denied_prefixes=denied_prefixes,
        )
        resolved = policy.resolve(path)
    except ValueError as exc:
        return result_factory(error=str(exc))
    if resolved.suffix.lower() == ".py":
        try:
            ast.parse(content, filename=str(resolved))
        except SyntaxError as exc:
            return result_factory(error=f"Syntax check failed (ast.parse): {exc}")
        ast_hints = python_ast_smoke_hints(content)
    else:
        ast_hints = None
        error = validate_syntax(resolved, content)
        if error:
            return result_factory(error=f"Syntax check failed: {error}")
    display_path = display_under_root(policy.root, resolved)
    previous_lines: int | None = None
    if resolved.exists():
        new_raw = content.encode("utf-8")
        existing_raw = resolved.read_bytes()
        if hashlib.sha256(new_raw).digest() == hashlib.sha256(existing_raw).digest():
            existing_sha = hashlib.sha256(existing_raw).hexdigest()[:16]
            line_count = len(content.splitlines())
            return result_factory(
                output=(
                    f"No-op: {display_path} already has exactly this content "
                    f"({line_count} lines, sha256~{existing_sha}). "
                    "File was not modified. Use bash to test when the code is already correct."
                )
            )
        previous_lines = len(existing_raw.decode("utf-8", errors="replace").splitlines())
    info = atomic_write(resolved, content)
    snapshot = format_file_snapshot(
        content,
        max_chars=int(return_full_max_chars),
        max_lines=int(return_full_max_lines),
        head_tail_lines=int(return_head_tail_lines),
    )
    snapshot_block = f"\n{snapshot}" if snapshot else ""
    hint_block = f"\n[ast-smoke] {ast_hints}" if ast_hints else ""
    edit_hint = ""
    if previous_lines is not None and previous_lines > 0:
        ratio = abs(info["lines"] - previous_lines) / previous_lines
        if ratio <= 0.30:
            edit_hint = (
                f"\n[hint] Only ~{ratio:.0%} of lines changed vs the previous file. "
                "Next time prefer `edit` (old_string/new_string) for surgical changes — "
                "it is faster (lower ttft) and easier to review."
            )
    return result_factory(
        output=(
            f"Written {display_path} ({info['lines']} lines, {info['bytes']} bytes, "
            f"sha256~{info['sha256_short']}){hint_block}{edit_hint}{snapshot_block}"
        )
    )


# Historical function name retained as a non-owning API alias.
write_workspace = write_file
