"""Exact-match filesystem editing and diagnostic feedback."""

from __future__ import annotations

import ast
from collections.abc import Callable, Sequence
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any

from ..base import ToolResult
from ..path_policy import PathPolicy, atomic_write, validate_syntax
from .modify import format_file_snapshot

ResultFactory = Callable[..., Any]


def diagnose_not_found(content: str, old_str: str) -> str:
    first_line = old_str.strip().split("\n")[0].strip()
    if not first_line:
        return "old_str is empty or whitespace-only."
    best_line, best_ratio, best_number = "", 0.0, 0
    for number, line in enumerate(content.splitlines(), 1):
        ratio = SequenceMatcher(None, line.strip(), first_line).ratio()
        if ratio > best_ratio:
            best_ratio, best_line, best_number = ratio, line.rstrip(), number
    if best_ratio > 0.5:
        return f"Closest line match (line {best_number}, {best_ratio:.0%} similar): {best_line!r}"
    return "No close line match; re-read the file and copy the exact span."


def top_line_block_matches(
    content: str,
    old_str: str,
    *,
    k: int,
) -> list[tuple[float, int, str]]:
    old_lines = old_str.splitlines()
    if not old_lines:
        return []
    width = len(old_lines)
    file_lines = content.splitlines()
    if len(file_lines) < width:
        return []
    candidates: list[tuple[float, int, str]] = []
    for index in range(0, len(file_lines) - width + 1):
        block = "\n".join(file_lines[index : index + width])
        candidates.append((SequenceMatcher(None, old_str, block).ratio(), index + 1, block))
    candidates.sort(key=lambda candidate: -candidate[0])
    return candidates[: max(1, k)]


def context_around_lines(
    file_lines: list[str],
    start_1based: int,
    *,
    n_lines: int,
    ctx: int,
) -> str:
    start = start_1based - 1
    low = max(0, start - ctx)
    high = min(len(file_lines), start + n_lines + ctx)
    output = [f"(lines {start + 1}-{start + n_lines} context; lines {low + 1}-{high})"]
    for index in range(low, high):
        prefix = ">> " if start <= index < start + n_lines else "   "
        output.append(f"{prefix}{index + 1:6}|{file_lines[index]}")
    return "\n".join(output)


def python_symbol_for_line(content: str, line_number: int) -> str:
    try:
        tree = ast.parse(content or "\n")
    except SyntaxError:
        return ""
    best: ast.AST | None = None
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            continue
        start = int(getattr(node, "lineno", 0) or 0)
        end = int(getattr(node, "end_lineno", start) or start)
        if start <= line_number <= end:
            if best is None:
                best = node
                continue
            best_start = int(getattr(best, "lineno", 0) or 0)
            best_end = int(getattr(best, "end_lineno", best_start) or best_start)
            if end - start <= best_end - best_start:
                best = node
    if best is None:
        return ""
    start = int(getattr(best, "lineno", 0) or 0)
    end = int(getattr(best, "end_lineno", start) or start)
    kind = "class" if isinstance(best, ast.ClassDef) else "function"
    return f"{kind} {getattr(best, 'name', '(unknown)')} lines {start}-{end}"


def suggest_old_str_anchor(
    content: str,
    file_lines: list[str],
    start_1based: int,
    *,
    n_lines: int,
    ctx: int,
    path: str,
) -> str:
    start = start_1based - 1
    low = max(0, start - ctx)
    high = min(len(file_lines), start + n_lines + ctx)
    anchor = "\n".join(file_lines[low:high])
    if len(anchor) > 2000:
        anchor = anchor[:1000].rstrip() + "\n...[anchor truncated]...\n" + anchor[-1000:]
    lines = [f"[edit-anchor suggestion: {path} lines {low + 1}-{high}]"]
    if Path(path).suffix == ".py":
        symbol = python_symbol_for_line(content, start_1based)
        if symbol:
            lines.append(f"Enclosing symbol: {symbol}")
    lines.extend(
        ["Suggested old_str anchor (copy exactly between markers):", "```text", anchor, "```"]
    )
    return "\n".join(lines)


def change_context(text: str, target: str, ctx: int = 3, hint_offset: int = -1) -> str:
    if hint_offset >= 0 and text[hint_offset : hint_offset + len(target)] == target:
        index = hint_offset
    else:
        index = text.find(target)
    if index < 0:
        return ""
    line_number = text[:index].count("\n") + 1
    lines = text.splitlines()
    accumulated = 0
    start_line = 0
    for line_index, line in enumerate(lines):
        if accumulated + len(line) >= index:
            start_line = line_index
            break
        accumulated += len(line) + 1
    end_line = start_line + target.count("\n")
    low = max(0, start_line - ctx)
    high = min(len(lines), end_line + ctx + 1)
    output = [f"(context around edit near line {line_number})"]
    for line_index in range(low, high):
        prefix = ">> " if start_line <= line_index <= end_line else "   "
        output.append(f"{prefix}{line_index + 1:6}|{lines[line_index]}")
    return "\n".join(output)


def _not_found_feedback(
    content: str,
    old_str: str,
    path: str,
    *,
    candidate_count: int,
    max_chars: int,
) -> str:
    diagnostic = diagnose_not_found(content, old_str)
    matches = top_line_block_matches(content, old_str, k=candidate_count)
    file_lines = content.splitlines()
    parts: list[str] = []
    old_line_count = len(old_str.splitlines())
    for rank, (ratio, start_line, _block) in enumerate(matches, 1):
        parts.append(
            f"\n--- Candidate {rank} ({ratio:.0%} similar to old_str, starts at line {start_line}) ---"
        )
        parts.append(context_around_lines(file_lines, start_line, n_lines=old_line_count, ctx=2))
        parts.append(
            suggest_old_str_anchor(
                content, file_lines, start_line, n_lines=old_line_count, ctx=2, path=path
            )
        )
    extra = "".join(parts)
    if len(extra) > max_chars:
        extra = extra[: max_chars // 2] + "\n...[truncated]...\n" + extra[-max_chars // 2 :]
    return f"old_str not found in {path}.\n{diagnostic}{extra}"


def edit_file(
    root: str | Path,
    path: str,
    old_str: str,
    new_str: str,
    *,
    sandbox: bool = True,
    extra_roots: Sequence[str | Path] = (),
    denied_prefixes: Sequence[str | Path] = (),
    return_full_max_chars: int = 12000,
    return_full_max_lines: int = 250,
    return_head_tail_lines: int = 40,
    return_change_ctx_lines: int = 8,
    failure_top_k_candidates: int = 3,
    failure_diag_max_chars: int = 2000,
    result_factory: ResultFactory = ToolResult,
    path_policy: PathPolicy | None = None,
):
    try:
        policy = path_policy or PathPolicy(
            root, enabled=sandbox, extra_roots=extra_roots, denied_prefixes=denied_prefixes
        )
        resolved = policy.resolve(path)
    except ValueError as exc:
        return result_factory(error=str(exc))
    if not resolved.is_file():
        return result_factory(error=f"File not found or not a file: {path}")
    content = resolved.read_text(encoding="utf-8", errors="replace")
    count = content.count(old_str)
    if count == 0:
        return result_factory(
            error=_not_found_feedback(
                content,
                old_str,
                path,
                candidate_count=int(failure_top_k_candidates),
                max_chars=int(failure_diag_max_chars),
            )
        )
    if count > 1:
        return result_factory(
            error=(
                f"old_str matches {count} locations in {path}; "
                "add more surrounding lines so the match is unique."
            )
        )
    new_content = content.replace(old_str, new_str, 1)
    error = validate_syntax(resolved, new_content)
    if error:
        return result_factory(error=f"Edit would break syntax/format: {error}")
    info = atomic_write(resolved, new_content)
    preview = change_context(
        new_content,
        new_str,
        ctx=max(3, int(return_change_ctx_lines)),
        hint_offset=content.find(old_str),
    )
    snapshot = format_file_snapshot(
        new_content,
        max_chars=int(return_full_max_chars),
        max_lines=int(return_full_max_lines),
        head_tail_lines=int(return_head_tail_lines),
    )
    snapshot_block = f"\n--- Current file snapshot (after edit) ---\n{snapshot}" if snapshot else ""
    return result_factory(
        output=(
            f"Edited {path}: 1 replacement OK.\n{preview}\n"
            f"({info['lines']} lines, sha256~{info['sha256_short']}){snapshot_block}"
        )
    )


# Historical function name retained as a non-owning API alias.
edit_workspace = edit_file
