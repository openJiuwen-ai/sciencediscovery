"""Task-specific colors and a title-only activity pulse."""

from rich.text import Text
from textual.widgets import Button

from .controller import sanitize_terminal_text
from .formatting import style_progress

ACTIVE_TASK_STATES = frozenset({'starting', 'running', 'stopping'})
_PULSE_FRAMES = (
    ('○', '#536575'),
    ('◉', '#8FA9C4'),
    ('●', '#B8D7E8'),
    ('◉', '#8FA9C4'),
)


def task_state_tone(state: str) -> str:
    if state in {'failed', 'interrupted'}:
        return '#E99AA3'
    if state in {'partial', 'needs review', 'waiting'}:
        return '#D8BE91'
    if state in ACTIVE_TASK_STATES:
        return '#8FA9C4'
    return '#9297A3'


def style_task_text(text: Text, *, state: str | None = None) -> Text:
    """Color task metrics without using emphasis as a second signal."""
    style_progress(text)
    best_style = '#DADCE7 not bold'
    estra_style = '#B8A4E3 not bold'
    eec_style = '#8FA9C4 not bold'
    disk_style = '#C5D1DF not bold'
    cost_style = '#D8BE91 not bold'
    text.highlight_regex(r'\b(?:Best|B)\s+\S+', style=best_style)
    text.highlight_regex(r'\b(?:ESTRA|Es)\s+[0-9—/-]+', style=estra_style)
    text.highlight_regex(r'\b(?:EEC|Ec)\s+[0-9—/-]+', style=eec_style)
    text.highlight_regex(
        r'\b(?:Disk|D)\s+(?:~?[0-9.]+[MG]|—)',
        style=disk_style,
    )
    text.highlight_regex(
        r'(?:(?<=Cost )|(?<!\w))~?\$[0-9.,]+[KMBT]?',
        style=cost_style,
    )
    filled_style = 'bold #7FB7C9'
    empty_style = '#59636F'
    percent_style = 'bold #AFC9D6'
    text.highlight_regex(r'■+', style=filled_style)
    text.highlight_regex(r'□+', style=empty_style)
    text.highlight_regex(r'\b\d{1,3}%', style=percent_style)
    text.highlight_regex(r'\b(?:running|starting)\b', style='bold #8FA9C4')
    text.highlight_regex(r'\b(?:waiting|partial|needs review)\b', style='#D8BE91')
    text.highlight_regex(r'\b(?:failed|interrupted)\b', style='bold #E99AA3')
    text.highlight_regex(r'\b(?:completed|stopped|paused)\b', style='#9297A3')
    text.highlight_regex(
        r'\b(?:\d+(?:\.\d+)?[smh](?: \d{2}m)? left|finalizing)\b',
        style='bold #8FA9C4',
    )
    text.highlight_regex(r'(?m)^[▾▸-]?\s*[A-Za-z]\w*:', style='bold #C5D1DF')
    return text


class TaskPulse:
    """Animate one fixed-width glyph without repainting task rows."""

    TASK_PULSE_INTERVAL = 0.75

    def _set_task_pulse(self, active: bool) -> None:
        changed = active != getattr(self, '_task_pulse_active', False)
        self._task_pulse_active = active
        if changed:
            self._task_pulse_frame = 0
        if not self.is_mounted:
            return
        timer = getattr(self, '_task_pulse_timer', None)
        if timer is None:
            self._task_pulse_timer = self.set_interval(
                self.TASK_PULSE_INTERVAL,
                self._tick_task_pulse,
                name='task-pulse',
                pause=not active,
            )
        elif active:
            timer.resume()
        else:
            timer.pause()

    def _tick_task_pulse(self) -> None:
        if not getattr(self, '_task_pulse_active', False):
            return
        self._task_pulse_frame = (
            getattr(self, '_task_pulse_frame', 0) + 1
        ) % len(_PULSE_FRAMES)
        self._refresh_task_heading()

    def _task_heading(self, title: str) -> Text:
        """Build a stable-width task title; the activity glyph never changes."""
        heading = sanitize_terminal_text(title).replace('\n', ' ')
        if heading.startswith('Tasks'):
            heading = heading[5:].lstrip(' ·')
        collapsed = getattr(self, '_panel_collapsed', False)
        prefix, caption = ('▸ ', 'Tasks') if collapsed else ('╭─', 'TASKS')
        available_width = max(18, self.size.width - 8)
        pulse_width = 2 if getattr(self, '_task_pulse_active', False) else 0
        if (
            ' · Cost ' in heading
            and Text(prefix + caption + ' · ' + heading).cell_len + pulse_width > available_width
        ):
            heading = heading.rsplit(' · Cost ', 1)[0]
        label = Text(prefix + caption, no_wrap=True, overflow='ellipsis')
        if getattr(self, '_task_pulse_active', False):
            frame = getattr(self, '_task_pulse_frame', 0) % len(_PULSE_FRAMES)
            glyph, color = _PULSE_FRAMES[frame]
            label.append(' ' + glyph, style=color)
        label.append(' · ' + heading)
        label.truncate(available_width, overflow='ellipsis')
        return style_task_text(label)

    def _refresh_task_heading(self) -> None:
        if not self.is_mounted or getattr(self, '_host_tasks', None) is None:
            return
        self.query_one('#research-toggle', Button).label = self._task_heading(
            self._host_tasks[0]
        )
