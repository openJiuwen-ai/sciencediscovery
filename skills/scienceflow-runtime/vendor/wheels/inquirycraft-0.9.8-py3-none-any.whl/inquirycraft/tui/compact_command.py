"""Manual chat context compaction, separate from view/history folding."""

import asyncio


async def compact_chat(app, arguments):
    if arguments:
        await app.notice('Use /compact without arguments.')
        return
    if app.busy:
        await app.notice('Finish or cancel the current chat before compacting its context.')
        return
    compact = getattr(app.runtime, 'compact_context', None)
    if not callable(compact):
        await app.notice('This runtime does not support manual context compaction.')
        return
    try:
        result = await compact()
    except asyncio.CancelledError:
        await app.notice('Context compaction cancelled; original history retained.')
        return
    except (RuntimeError, ValueError, OSError) as exc:
        await app.notice(f'Context compaction failed: {exc}')
        return
    if result.compacted:
        monitor = getattr(app.runtime, "chat_monitor", None)
        if monitor is not None:
            monitor.context_compacted(result.estimated_tokens)
        await app.notice(
            f'Chat context compacted · estimated {result.tokens_before / 1024:.1f}K → '
            f'{result.estimated_tokens / 1024:.1f}K · original history retained.\n'
            'The footer shows ≈ estimated context until the next provider usage arrives.'
        )
    else:
        await app.notice('Chat context is already short; no compaction needed. Original history retained.')
    app._refresh_chrome()
