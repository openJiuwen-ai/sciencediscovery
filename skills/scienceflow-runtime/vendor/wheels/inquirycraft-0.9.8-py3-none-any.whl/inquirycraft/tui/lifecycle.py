"""Shared shutdown lifecycle for the Textual runtime host."""

import asyncio
from copy import deepcopy
from time import monotonic
from typing import Any

from textual.widgets import TextArea

from .shell_job_view import close_shell_jobs


class TuiLifecycle:
    """Close application interactions and runtime resources exactly once."""

    async def action_confirm_quit(self) -> None:
        """Copy selected text, otherwise require two Ctrl+C presses to exit."""
        focused = self.focused
        if isinstance(focused, TextArea) and focused.selected_text:
            self._quit_requested_at = None
            focused.action_copy()
            return
        selected = self.screen.get_selected_text()
        if selected:
            self._quit_requested_at = None
            self.copy_to_clipboard(selected)
            return
        if any(widget.is_attached for widget in self.screen.selections):
            # Rich Markdown has no native source-position selection mapping.
            # A visible selection must never be interpreted as a quit request.
            self._quit_requested_at = None
            self.notify('Use Ctrl+Shift+C, or Copy on a code block.', timeout=2)
            return
        now = monotonic()
        requested = getattr(self, "_quit_requested_at", None)
        if requested is not None and now - requested <= 2.0:
            self._quit_requested_at = None
            await self.action_quit_app()
            return
        self._quit_requested_at = now
        self.notify("Press Ctrl+C again within 2 seconds to quit.", timeout=2)

    async def action_quit_app(self) -> None:
        if getattr(self, "_quitting", False):
            return
        self._quitting = True
        try:
            await self.shutdown_runtime()
        finally:
            self.exit()

    async def shutdown_runtime(self) -> None:
        if self._runtime_closed:
            return
        self._runtime_closed = True
        owned_runtime = getattr(self, "_host_chat_runtime", None) or self.runtime
        try:
            if self.interceptor is not None:
                await self.interceptor.aclose()
        finally:
            try:
                task = self._run_task
                if task is not None and not task.done():
                    await self.runtime.cancel()
                    try:
                        await asyncio.wait_for(asyncio.shield(task), timeout=3.0)
                    except (TimeoutError, asyncio.CancelledError):
                        task.cancel()
                        await asyncio.gather(task, return_exceptions=True)
            finally:
                try:
                    await close_shell_jobs(self)
                finally:
                    await owned_runtime.aclose()


    async def notice_rich(self, content, *, separate: bool = False) -> None:
        """Display a host-styled Rich Text notice without interpreting markup."""
        from rich.text import Text

        from .components import TranscriptEntry
        from .controller import sanitize_terminal_text

        if not isinstance(content, Text):
            raise TypeError("notice_rich expects Rich Text")
        clean = sanitize_terminal_text(content.plain)
        from .history_context import exclude_from_history

        entry = TranscriptEntry("notice", clean, notice_label=self.branding.notice_label,
                                history_excluded=exclude_from_history())
        body = content if clean == content.plain else Text(clean)
        entry.set_rich_content(body)
        await self._mount_entry(entry, merge_with_previous=not separate)

    async def echo_user(self, text: str) -> None:
        """Display host-consumed input without submitting it to the chat runtime."""
        from .components import TranscriptEntry

        await self._mount_entry(TranscriptEntry("user", text))

    async def run_host_task(self, prompt: str, *, show_response: bool = True, runtime=None) -> str:
        """Run with an optional caller-owned, isolated preparation runtime.

        Cancellation and tool events use the active runtime. The chat runtime
        and its session are restored even when preparation fails or is cancelled.
        The caller remains responsible for closing its temporary runtime.
        """
        if self.busy:
            raise RuntimeError("A chat request is already active.")
        chat_runtime = self.runtime
        if runtime is not None:
            self._host_chat_runtime = chat_runtime
            self.runtime = runtime
        self._hide_host_response = not show_response
        try:
            return await self._run_host_task(prompt)
        finally:
            self._hide_host_response = False
            self.runtime = chat_runtime
            if runtime is not None:
                self._host_chat_runtime = None
                conversation = getattr(chat_runtime, "conversation", None)
                self._conversation_count = len(getattr(conversation, "messages", ()))
            self._refresh_chrome()

    async def _run_host_task(self, prompt: str) -> str:
        """Run a host preparation task with normal tools, events and cancellation.

        Hosts should schedule this coroutine so input handling stays responsive.
        It never starts a separate research worker or changes runtime policies.
        """
        if self.busy:
            raise RuntimeError("A chat request is already active.")
        reset = getattr(self.runtime, "reset_cancellation", None)
        if reset is not None:
            reset()
        before = len(self.conversation_snapshot())
        self._state = "running"
        self._start_activity("Preparing task")
        task = asyncio.create_task(self._consume_run(prompt))
        self._run_task = task
        self._refresh_chrome()
        try:
            await task
        except asyncio.CancelledError:
            await self.runtime.cancel()
            task.cancel()
            await asyncio.gather(task, return_exceptions=True)
            raise
        if asyncio.current_task().cancelling():
            await self.runtime.cancel()
            raise asyncio.CancelledError
        if self._state == "error":
            raise RuntimeError("Preparation agent failed; see the conversation above.")
        messages = self.conversation_snapshot()[before:]
        for message in reversed(messages):
            if message.get("role") == "assistant" and message.get("content"):
                return str(message["content"])
        raise RuntimeError("Preparation agent returned no final answer.")

    def conversation_snapshot(self) -> tuple[dict[str, Any], ...]:
        conversation = getattr(self.runtime, "conversation", None)
        return tuple(deepcopy(message.to_dict()) for message in getattr(conversation, "messages", ()))

    async def _consume_run(self, prompt: str, *, chat: bool = False,
                           host_context: str | None = None) -> None:
        try:
            set_context = getattr(self.runtime, 'set_ephemeral_context', None)
            if callable(set_context):
                set_context(host_context)
            progress_events = 0
            async for event in self.runtime.run_stream(prompt):
                await self._handle_runtime_event(event)
                if event.type == 'tool.progress':
                    progress_events += 1
                    # A full event queue can otherwise starve keys and UI timers.
                    if progress_events >= 32:
                        progress_events = 0
                        await asyncio.sleep(0)
                else:
                    progress_events = 0
        except asyncio.CancelledError:
            self._state = "cancelling"
            await self._add_notice("Run cancelled.", chat_lifecycle=True)
        except Exception as exc:
            self._state = "error"
            await self._add_notice(f"Run failed: {type(exc).__name__}: {exc}", chat_lifecycle=True)
        finally:
            set_context = getattr(self.runtime, 'set_ephemeral_context', None)
            if callable(set_context):
                set_context(None)
            self.sync_tool_details()
            if self._assistant is None and not getattr(self, "_hide_host_response", False):
                await self._restore_new_nonstream_messages()
            if chat:
                interrupted = self._state in {"error", "cancelling"}
                if interrupted:
                    for entry in self._tool_entries.values():
                        if entry.state in {'requested', 'running'}:
                            entry.update_tool(state='cancelled')
                outcome = ('Run failed' if self._state == 'error' else 'Run cancelled') if interrupted else ''
                self._finish_chat_round(settled=True, outcome=outcome)
                if not interrupted:
                    from .notice_history import archive_system_notices

                    await archive_system_notices(self)
            conversation = getattr(self.runtime, "conversation", None)
            self._conversation_count = len(getattr(conversation, "messages", ()))
            if self._state != "error":
                self._state = "idle"
            pending_handoff = chat and not getattr(self, "_quitting", False) and (
                self._queued_chat_prompts
                or any(
                    getattr(item, "queue", None) in {"steer", "follow_up"}
                    for item in self.runtime.pending_messages()
                )
            )
            self._handoff_pending = bool(pending_handoff)
            self._run_task = None
            self._assistant = None
            self._tool_entries.clear()
            self._active_tool_names.clear()
            self._stop_activity()
            self._refresh_chrome()
            if pending_handoff:
                # Input submitted just before a detached shell yielded (or
                # just before any run settled) must still receive its own reply.
                while True:
                    queued = tuple(
                        item for item in self.runtime.pending_messages()
                        if getattr(item, "queue", None) in {"steer", "follow_up"}
                    )
                    if not queued:
                        break
                    for item in queued:
                        if await self.runtime.cancel_message(item.id):
                            self._queued_chat_prompts.append(item.content)
                prompt = self._queued_chat_prompts.popleft()
                self._handoff_pending = False
                from .controller import TuiSubmission

                await self._dispatch_submission(TuiSubmission("run", prompt))

    async def _restore_new_nonstream_messages(self) -> None:
        conversation = getattr(self.runtime, "conversation", None)
        messages = tuple(getattr(conversation, "messages", ()))
        for message in messages[self._conversation_count :]:
            if str(getattr(message, "role", "")) != "assistant":
                continue
            content = getattr(message, "content", "")
            if isinstance(content, str):
                await self._restore_assistant(message)
        self._conversation_count = len(messages)
