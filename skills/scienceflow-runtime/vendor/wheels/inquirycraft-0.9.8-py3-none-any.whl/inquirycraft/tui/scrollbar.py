"""Compact scrollbar rendering for terminal cells."""

from rich.color import Color
from rich.segment import Segment, Segments
from rich.style import Style
from textual.scrollbar import ScrollBarRender


class ThinScrollBarRender(ScrollBarRender):
    """Draw only the narrow thumb, retaining invisible track click targets."""

    VERTICAL_GLYPH = "▕"

    @classmethod
    def render_bar(
        cls,
        size: int = 25,
        virtual_size: float = 50,
        window_size: float = 20,
        position: float = 0,
        thickness: int = 1,
        vertical: bool = True,
        back_color: Color = Color.parse("#555555"),
        bar_color: Color = Color.parse("bright_magenta"),
    ) -> Segments:
        rendered = super().render_bar(
            size=size,
            virtual_size=virtual_size,
            window_size=window_size,
            position=position,
            thickness=thickness,
            vertical=vertical,
            back_color=back_color,
            bar_color=bar_color,
        )
        if not vertical:
            return rendered

        segments = []
        for segment in rendered.segments:
            meta = segment.style.meta if segment.style is not None else None
            is_thumb = bool(meta and meta.get("@mouse.down") == "grab")
            segments.append(
                Segment(
                    (cls.VERTICAL_GLYPH if is_thumb else " ") * thickness,
                    Style(color=bar_color if is_thumb else None, meta=meta),
                )
            )
        return Segments(segments, new_lines=True)
