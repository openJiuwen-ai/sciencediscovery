"""Host-extensible slash command completion without domain-specific commands."""


import shlex
from itertools import islice
from pathlib import Path

from rich.text import Text
from textual.widgets import Static, TextArea

from .contracts import TuiCommandSpec
from .controller import sanitize_terminal_text

DEFAULT_COMMANDS = tuple(TuiCommandSpec(name, description) for name, description in (
    ('/panel', 'Collapse or expand progress'),
    ('/help', 'Commands and shortcuts'), ('/status', 'Current run status'),
    ('/context', 'Configure model context preset'), ('/usage', 'Session tokens and costs'),
    ('/compact', 'Compact chat context; preserve saved history'),
    ('/cancel', 'Cancel active work'),
    ('/clear', 'Clear transcript view'),
    ('/steer', 'Guide the active agent'), ('/follow-up', 'Queue follow-up'),
    ('/next', 'Queue the next run')))

DEFAULT_COMMON_COMMANDS = ('/help', '/status', '/cancel')


class TuiCompletion:
    def register_commands(self, commands, *, common_commands=None):
        """Let hosts order bare-slash suggestions without changing command routing."""
        self._host_commands = tuple(commands)
        preferred = (
            tuple(spec.name for spec in self._host_commands) + DEFAULT_COMMON_COMMANDS
            if common_commands is None else common_commands
        )
        self._common_commands = tuple(dict.fromkeys(preferred))

    def _command_specs(self):
        specs = {spec.name: spec for spec in (*DEFAULT_COMMANDS, *getattr(self, '_host_commands', ()))}
        common = getattr(self, '_common_commands', DEFAULT_COMMON_COMMANDS)
        ordered = {name: specs[name] for name in common if name in specs}
        ordered.update((name, spec) for name, spec in specs.items() if name not in ordered)
        return ordered

    def _completion_matches(self, text):
        specs = self._command_specs()
        if not text.startswith('/') or '\n' in text:
            return []
        if ' ' not in text:
            common = getattr(self, '_common_commands', DEFAULT_COMMON_COMMANDS)
            return [(spec.name + ' ', spec.description) for name, spec in specs.items()
                    if name.startswith(text) and name != text
                    and (text != '/' or name in common)]
        command, _, arguments = text.partition(' ')
        spec = specs.get(command)
        prefix = arguments.rsplit(' ', 1)[-1]
        if spec is None:
            return []
        provider = getattr(getattr(self, 'interceptor', None), 'tui_completions', None)
        if callable(provider):
            dynamic = provider(text)
            if dynamic is not None:
                return list(dynamic)[:100]
        if '=' in prefix:
            key, _, fragment = prefix.partition('=')
            if key not in spec.path_parameters or any(c in fragment for c in "\"'"):
                return []
            candidate = Path(fragment).expanduser()
            if not candidate.is_absolute():
                candidate = self.workspace / candidate
            directory = candidate if not fragment or fragment.endswith('/') else candidate.parent
            name = '' if not fragment or fragment.endswith('/') else candidate.name
            try:
                entries = sorted(p for p in islice(directory.iterdir(), 500) if p.is_dir() and p.name.startswith(name))[:30]
            except OSError:
                return []
            return [(text[:-len(prefix)] + key + '=' + shlex.quote(str(p) + '/'), 'Directory') for p in entries]
        base = text[:-len(prefix)] if prefix else text
        return [(base + value, 'Parameter') for value in spec.parameters
                if value.startswith(prefix) and value.rstrip('=') + '=' not in arguments]

    def on_text_area_changed(self, event: TextArea.Changed):
        if event.text_area.id != 'prompt':
            return
        value = event.text_area.text
        self._matches = [] if value == getattr(self, "_completion_accepted", None) else self._completion_matches(value)
        self._completion_index = 0
        self._render_completions()

    def _render_completions(self):
        widget = self.query_one('#command-completions', Static)
        matches = getattr(self, '_matches', [])
        widget.display = bool(matches)
        self.screen.set_class(bool(matches), 'completing')
        text = Text()
        selected = getattr(self, '_completion_index', 0)
        start = max(0, selected - 4)
        for index in range(start, min(len(matches), start + 5)):
            command, description = matches[index]
            text.append(('› ' if index == selected else '  ') + sanitize_terminal_text(command.strip()) + '  ' + sanitize_terminal_text(description) + '\n',
                        style='#8FA9C4 bold' if index == selected else '#9297A3')
        widget.update(text)

    def select_completion(self, delta):
        if not getattr(self, '_matches', []):
            return False
        self._completion_index = (self._completion_index + delta) % len(self._matches)
        self._render_completions()
        return True

    def complete_prompt(self):
        """Refresh on explicit Tab, including a complete command without a space."""
        editor = self.query_one('#prompt', TextArea)
        value = editor.text
        if not getattr(self, '_matches', []):
            exact = self._command_specs().get(value)
            self._matches = ([(exact.name + ' ', exact.description)] if exact
                             else self._completion_matches(value))
            self._completion_index = 0
        return self.accept_completion()

    def accept_completion(self):
        if not getattr(self, '_matches', []):
            return False
        editor = self.query_one('#prompt', TextArea)
        value = self._matches[self._completion_index][0]
        self._completion_accepted = value
        editor.load_text(value)
        editor.move_cursor(editor.document.end)
        self.dismiss_completion()
        return True

    def dismiss_completion(self):
        active = bool(getattr(self, '_matches', []))
        self._matches = []
        self._render_completions()
        return active
