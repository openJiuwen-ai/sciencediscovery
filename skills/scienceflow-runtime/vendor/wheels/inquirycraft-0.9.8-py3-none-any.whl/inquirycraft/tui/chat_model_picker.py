"""Bottom-docked keyboard model picker for embedding hosts."""

from __future__ import annotations

from collections.abc import Sequence

from textual import events
from textual.app import ComposeResult
from textual.containers import Vertical
from textual.message import Message
from textual.widgets import Label, OptionList
from textual.widgets.option_list import Option


class ChatModelPicker(Vertical):
    """Select one chat model without leaving the conversation screen."""

    class Selected(Message):
        def __init__(self, alias: str) -> None:
            super().__init__()
            self.alias = alias

    class Cancelled(Message):
        pass

    def __init__(self) -> None:
        super().__init__(id='chat-model-picker')
        self.aliases: tuple[str, ...] = ()

    def compose(self) -> ComposeResult:
        yield Label('Chat model', id='chat-model-title')
        yield OptionList(id='chat-model-list')
        yield Label('↑↓ select  ·  Enter apply  ·  Esc close', id='chat-model-hint')
        yield Label('', id='chat-model-config')
        yield Label('', id='chat-model-error')

    def configure(
        self,
        aliases: Sequence[str],
        current: Sequence[str],
        *,
        config_hint: str = '',
    ) -> None:
        self.aliases = tuple(aliases)
        options = self.query_one('#chat-model-list', OptionList)
        options.set_options(
            Option(
                f'{index:02d}  {alias}' + ('  ·  current' if alias in current else ''),
                id=alias,
            )
            for index, alias in enumerate(self.aliases, 1)
        )
        options.highlighted = next(
            (index for index, alias in enumerate(self.aliases) if alias in current),
            0,
        )
        options.disabled = False
        self.query_one('#chat-model-config', Label).update(config_hint)
        self.query_one('#chat-model-error', Label).update('')

    def focus_options(self) -> None:
        self.query_one('#chat-model-list', OptionList).focus()

    def set_busy(self, busy: bool) -> None:
        self.query_one('#chat-model-list', OptionList).disabled = busy

    def set_error(self, text: str) -> None:
        self.query_one('#chat-model-error', Label).update(text)
        self.set_busy(False)

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        if event.option.id is not None:
            self.post_message(self.Selected(str(event.option.id)))

    def on_key(self, event: events.Key) -> None:
        options = self.query_one('#chat-model-list', OptionList)
        if event.key == 'escape':
            event.stop()
            self.post_message(self.Cancelled())
            return
        if options.disabled:
            return
        if len(event.key) == 1 and event.key.isdigit() and event.key != '0':
            index = int(event.key) - 1
            if index < len(self.aliases):
                event.stop()
                self.post_message(self.Selected(self.aliases[index]))


__all__ = ['ChatModelPicker']
