"""Recognize TUI-owned context that must not appear as user input."""

BACKGROUND_SHELL_RESULT_PREFIX = "[Background shell result, not a new user request]"
BACKGROUND_SHELL_CONTINUE_PROMPT = (
    "[Background shell completion, not a new user request] "
    "The command finished. Use the queued result to finish the original request. "
    "Do not repeat the command."
)


def is_background_shell_result(content: object) -> bool:
    return isinstance(content, str) and content.startswith(BACKGROUND_SHELL_RESULT_PREFIX)


def is_internal_shell_message(content: object) -> bool:
    return is_background_shell_result(content) or content == BACKGROUND_SHELL_CONTINUE_PROMPT
