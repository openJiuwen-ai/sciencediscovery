"""Dependency-light contracts for application-owned TUI interactions."""

from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol


class TuiHostPort(Protocol):
    @property
    def busy(self) -> bool: ...

    def conversation_snapshot(self) -> tuple[Mapping[str, Any], ...]: ...

    async def notice(self, text: str) -> None: ...

    def set_host_status(self, text: str) -> None: ...

    async def switch_chat_models(
        self,
        model_config: Path,
        *,
        aliases: tuple[str, ...],
        selection: str,
    ) -> tuple[str, ...]: ...

    def open_chat_model_selector(
        self,
        model_config: Path,
        *,
        aliases: tuple[str, ...],
        current: tuple[str, ...],
        selection: str,
        config_hint: str = "",
        on_applied: Callable[[tuple[str, ...]], Any] | None = None,
    ) -> None: ...


class TuiPreparationPort(TuiHostPort, Protocol):
    """Optional tool-enabled preparation; existing hosts need not implement it."""

    async def run_host_task(
        self, prompt: str, *, show_response: bool = True, runtime: Any = None
    ) -> str: ...


class TuiTranscriptSectionPort(TuiHostPort, Protocol):
    """Optional presentation-only host sections; no conversation mutation."""

    async def begin_transcript_section(self) -> object: ...

    async def fold_transcript_section(self, section: object, summary: str) -> bool: ...


class TuiDashboardPort(TuiHostPort, Protocol):
    """Optional embedding panels; render plain text without interpreting markup."""

    def set_host_panel(self, summary: str, rows: tuple[str, ...] = ()) -> None: ...

    def set_resource_status(self, text: str) -> None: ...


class TuiTaskDashboardPort(TuiHostPort, Protocol):
    """Optional stable-key list; task control remains in the embedding host."""

    def set_host_tasks(self, title: str, items: tuple[dict, ...]) -> None: ...


@dataclass(frozen=True)
class TuiCommandSpec:
    name: str
    description: str
    parameters: tuple[str, ...] = ()
    path_parameters: tuple[str, ...] = ()


class TuiInputInterceptor(Protocol):
    """Required lifecycle implemented by every TUI input interceptor."""

    async def try_handle(self, text: str, host: TuiHostPort) -> bool: ...

    async def aclose(self) -> None: ...


class TuiInputPreprocessor(Protocol):
    """Optional pre-history hook for sensitive or host-owned input.

    True consumes the input without dispatching or remembering it. Implementations
    must not pass sensitive raw text to model providers or notices.
    """

    async def preprocess_input(self, text: str, host: TuiHostPort) -> bool: ...


class TuiCommandProvider(Protocol):
    """Optional command discovery hooks consumed by the TUI."""

    @property
    def tui_commands(self) -> tuple[TuiCommandSpec, ...]: ...

    @property
    def tui_common_commands(self) -> tuple[str, ...]: ...


class TuiCompletionProvider(Protocol):
    """Optional contextual completion hook consumed by the TUI."""

    def tui_completions(self, text: str) -> Sequence[tuple[str, str]] | None: ...


class TuiHistoryProvider(Protocol):
    """Optional display-only history hooks; neither changes model context."""

    def history_before(self, message_index: int) -> Sequence[str]: ...


class TuiChatContextProvider(Protocol):
    """Optional concise host state for ordinary chat provider calls only."""

    def chat_context(self) -> str: ...


class TuiMountHook(Protocol):
    """Optional asynchronous mount hook consumed by the TUI."""

    async def on_mount(self, host: TuiHostPort) -> None: ...


class TuiModelRegistryHook(Protocol):
    """Optional model-registry hook used by the composed CLI."""

    def configure_model_registry(self, model_config: Path, aliases: tuple[str, ...]) -> None: ...


class TuiHistoryClassifier(Protocol):
    """Optional hook for identifying host-owned transcript prompts."""

    def is_host_task_prompt(self, content: object) -> bool: ...


class DelegatingTuiInterceptor:
    """Transparent base for interceptors that wrap another interceptor.

    The required lifecycle is forwarded explicitly, while optional present and
    future host hooks remain visible through normal attribute delegation.
    """

    def __init__(self, delegate: TuiInputInterceptor) -> None:
        self._delegate = delegate

    @property
    def delegate(self) -> TuiInputInterceptor:
        return self._delegate

    def __getattr__(self, name: str) -> Any:
        return getattr(self._delegate, name)

    async def try_handle(self, text: str, host: TuiHostPort) -> bool:
        return await self._delegate.try_handle(text, host)

    async def aclose(self) -> None:
        await self._delegate.aclose()


TuiInterceptorFactory = Callable[[Path], TuiInputInterceptor]
