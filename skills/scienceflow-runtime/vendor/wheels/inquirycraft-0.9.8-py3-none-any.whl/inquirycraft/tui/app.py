"""Textual host for InquiryCraft's existing runtime and event stream."""

from __future__ import annotations

import asyncio
from collections import deque
from pathlib import Path
from typing import Any

from textual import events
from textual.app import App, ComposeResult
from textual.containers import Container, Horizontal, VerticalScroll
from textual.widgets import Button, Static, TextArea

from .branding import TuiBranding
from .card_navigation import TuiCardNavigation
from .chat_history import TuiChatHistory
from .chat_model_picker import ChatModelPicker
from .completion import TuiCompletion
from .components import AssistantEntry, BrandHeader, PromptInput, ToolEntry, TranscriptEntry
from .contracts import TuiInputInterceptor
from .controller import (
    TuiSubmission,
    parse_submission,
    sanitize_terminal_text,
    submission_preview,
)
from .dashboard import TuiDashboard
from .history_context import HISTORY_COMMAND, exclude_from_history
from .lifecycle import TuiLifecycle
from .model_selection import TuiModelSelection
from .projection import TuiProjection
from .resource_status import HostFooter
from .shell_job_view import JobRows, JobStatus, mount_shell_jobs
from .task_panel import HostTaskRows, TaskPanel, TaskToggle, TuiTaskDashboard
from .theme import TUI_BINDINGS, configure_terminal_colors
from .transcript import TranscriptScroll
from .transcript_grouping import TuiTranscriptGrouping


class InquiryCraftTui(
    TuiCardNavigation,
    TuiChatHistory,
    TuiModelSelection,
    TuiTranscriptGrouping,
    TuiTaskDashboard,
    TuiProjection,
    TuiCompletion,
    TuiDashboard,
    TuiLifecycle,
    App[None],
):
    """Full-screen host that projects one AgentRuntime into a terminal UI."""

    ENABLE_COMMAND_PALETTE = False
    BINDINGS = TUI_BINDINGS

    CSS_PATH = "theme.tcss"

    def get_css_variables(self):
        from .palette import SURFACE_COLOR

        return {
            **super().get_css_variables(), "host-surface": SURFACE_COLOR,
            "notice-surface": getattr(getattr(self, "branding", None), "notice_background", "") or "transparent",
        }

    def __init__(
        self, runtime: Any, *, model: str, workspace: Path,
        interceptor: TuiInputInterceptor | None = None,
        branding: TuiBranding | None = None,
        markdown: bool = True,
    ) -> None:
        # Textual resolves CSS variables during its constructor.
        self.branding = branding or TuiBranding()
        # Preserve ``ansi_default`` through Textual's render pipeline. Without
        # native ANSI colors, Textual maps it to its built-in theme background
        # (currently #0c0c0c) instead of the terminal's configured background.
        super().__init__(ansi_color=True)
        configure_terminal_colors(self)
        self.markdown = markdown
        self.title, self.sub_title = self.branding.name, self.branding.subtitle
        self.interceptor = interceptor
        self._host_status = ""
        self.runtime = runtime
        self.model = model
        self.workspace = workspace.resolve()
        self._run_task: asyncio.Task[None] | None = None
        self._starting_run = False
        self._handoff_pending = False
        self._assistant: AssistantEntry | None = None
        self._tool_entries: dict[str, ToolEntry] = {}
        self._assistant_entries: list[AssistantEntry] = []
        self._all_tool_entries: list[ToolEntry] = []
        self._tool_details = False
        self._state = "idle"
        self._turn = 0
        self._chat_round_count = 0
        self._chat_rounds = []
        self._chat_archive = None
        self._input_tokens = self._output_tokens = 0
        self._runtime_closed = False
        self._conversation_count = 0
        self._activity_started = None
        self._activity_phase = ""
        self._activity_frame = 0
        self._activity_timer = None
        self._active_tool_names: dict[str, str] = {}
        self._queued_chat_prompts: deque[str] = deque()
        self._initialize_model_selection()

    @property
    def busy(self) -> bool:
        return (
            self._starting_run
            or self._handoff_pending
            or (self._run_task is not None and not self._run_task.done())
        )

    async def notice(self, text: str) -> None:
        await self._add_notice(text)

    def set_host_status(self, text: str) -> None:
        self._host_status = sanitize_terminal_text(text)
        self._refresh_chrome()

    def compose(self) -> ComposeResult:
        yield BrandHeader(self.branding)
        with TaskPanel(id="research-panel"):
            with Horizontal(id="research-controls"):
                yield TaskToggle("▾ Progress · Ctrl+P", id="research-toggle")
                yield Button("Issues", id="research-filter")
                yield Static("", id="research-page", markup=False)
                yield Button("‹", id="research-prev")
                yield Button("›", id="research-next")
            yield Static("", id="research-summary", markup=False)
            yield HostTaskRows("", id="research-workers", markup=False)
        yield TranscriptScroll(id="transcript")
        yield Button("↓ New content", id="jump-latest")
        with Container(id="dock"):
            yield Static("", id="pending", markup=False)
            yield JobStatus("", id="status", markup=False)
            yield JobRows()
            yield Static("", id="command-completions", markup=False)
            yield ChatModelPicker()
            with Horizontal(id="prompt-row"):
                yield Static(">", id="prompt-prefix", markup=False)
                yield PromptInput(
                    soft_wrap=True,
                    show_line_numbers=False,
                    placeholder=self.branding.prompt_placeholder,
                    id="prompt",
                )
            yield HostFooter("", id="footer", markup=False)

    async def on_mount(self) -> None:
        await mount_shell_jobs(self)
        await self.mount_host_extension()
        self.screen.set_class(self.size.width < 58, "narrow")
        self.screen.set_class(self.size.height < 25, "short")
        transcript = self.query_one("#transcript", VerticalScroll)
        before_welcome = len(transcript.children)
        await self._add_welcome_notice()
        welcome = transcript.children[-1] if len(transcript.children) > before_welcome else None
        await self._restore_transcript()
        conversation = getattr(self.runtime, "conversation", None)
        messages = getattr(conversation, "messages", ())
        if (
            isinstance(welcome, TranscriptEntry)
            and getattr(self.branding, "fold_system_notices", False)
            and any(str(getattr(message, "role", "")) == "user" for message in messages)
        ):
            from .chat_archive import ensure_archive

            archive = await ensure_archive(self)
            archive.synchronize(notices=(welcome,), label=self.branding.notice_label)
            transcript.content_changed()
        self._conversation_count = len(getattr(conversation, "messages", ()))
        self.query_one("#prompt", TextArea).focus()
        self._refresh_chrome()

    async def _add_welcome_notice(self) -> None:
        text = self.branding.welcome_text.strip()
        if not text:
            return
        if not self.branding.welcome_emphasis:
            await self._add_notice(text, separate=True)
            return
        from rich.text import Text

        content = Text(text, style="#DADCE7")
        content.highlight_words(
            self.branding.welcome_emphasis,
            style=f"bold {self.branding.accent_color}",
        )
        content.highlight_regex(r"(?<!\S)/[\w-]+", "bold #8FA9C4")
        await self.notice_rich(content, separate=True)

    def on_resize(self, event: events.Resize) -> None:
        if self.is_mounted:
            self.call_after_refresh(self.query_one(BrandHeader).on_resize, event)
        self.screen.set_class(event.size.width < 58, "narrow")
        self.screen.set_class(event.size.height < 25, "short")
        if getattr(self, "_host_tasks", None) is not None:
            self.call_after_refresh(self._render_host_tasks)
        elif hasattr(self, "_panel_content"):
            self.call_after_refresh(self.set_host_panel, *self._panel_content)

    async def _add_notice(self, text: str, *, chat_lifecycle: bool = False,
                          separate: bool = False) -> None:
        await self._mount_entry(TranscriptEntry("notice", text, notice_label=self.branding.notice_label,
                                               chat_lifecycle=chat_lifecycle,
                                               history_excluded=exclude_from_history()),
                                merge_with_previous=not separate)

    async def action_submit_prompt(self) -> None:
        if self._chat_model_selector_open or len(self.screen_stack) > 1 or self.accept_completion():
            return
        editor = self.query_one("#prompt", TextArea)
        text = editor.text.strip()
        if not text:
            return
        original = editor.text
        editor.clear()
        if await self.submit_text(text):
            editor.remember_submission(original)
        if len(self.screen_stack) == 1 and not self._chat_model_selector_open:
            editor.focus()

    async def submit_text(self, text: str) -> bool:
        preprocess = getattr(self.interceptor, "preprocess_input", None)
        if callable(preprocess):
            try:
                if await preprocess(text, self):
                    return False
            except Exception:
                # A failed privacy hook must never fall through to model/history.
                await self._add_notice("Input could not be processed; please retry.")
                return False
        if text.strip():
            from .notice_history import archive_system_notices

            await archive_system_notices(self)
        command_task = asyncio.current_task() if text.lstrip().startswith('/') else None
        token = HISTORY_COMMAND.set(command_task)
        try:
            if await self.handle_chat_command(text):
                return False
            if self.interceptor is not None and await self.interceptor.try_handle(text, self):
                self._refresh_chrome()
                return False
            submission = parse_submission(text, busy=self.busy)
            if submission.action == "empty":
                return False
            if submission.action in {"run", "steer", "follow_up", "next_run"} and not (
                submission.content
            ):
                await self._add_notice(f"/{submission.command or submission.action} requires text.")
                return False
            await self._dispatch_submission(submission)
            return not submission.command
        finally:
            HISTORY_COMMAND.reset(token)

    async def _dispatch_submission(self, submission: TuiSubmission) -> None:
        if submission.action == "run":
            if self.busy:
                await self._add_notice("A run is active; use /steer or /follow-up.")
                return
            self._starting_run = True
            try:
                context = getattr(self.interceptor, 'chat_context', None)
                host_context = context() if callable(context) else None
                await self._begin_chat_round(submission.content)
                await self._mount_entry(TranscriptEntry("user", submission.content))
                reset_cancellation = getattr(self.runtime, "reset_cancellation", None)
                if reset_cancellation is not None:
                    reset_cancellation()
                self._state = "running"
                self._start_activity("Thinking")
                self._refresh_chrome()
                self._run_task = asyncio.create_task(
                    self._consume_run(submission.content, chat=True, host_context=host_context)
                )
            finally:
                self._starting_run = False
            return
        if submission.action == "steer":
            await self.runtime.steer(submission.content)
            await self._add_notice(
                f"Steering queued · {submission_preview(submission.content)}",
                chat_lifecycle=True,
            )
        elif submission.action == "follow_up":
            await self.runtime.follow_up(submission.content)
            await self._add_notice(
                f"Follow-up queued · {submission_preview(submission.content)}",
                chat_lifecycle=True,
            )
        elif submission.action == "next_run":
            await self.runtime.next_run(submission.content)
            await self._add_notice(
                f"Next-run queued · {submission_preview(submission.content)}",
                chat_lifecycle=True,
            )
        elif submission.action == "cancel":
            await self.action_cancel_run()
        elif submission.action == "status":
            await self._add_notice(self._status_text(verbose=True))
        elif submission.action == "clear":
            await self.action_clear_transcript()
        elif submission.action == "help":
            await self.action_show_help()
        self._refresh_chrome()

    async def action_cancel_run(self) -> None:
        if self._chat_model_selector_open:
            self._close_chat_model_selector()
            return
        if len(self.screen_stack) > 1:
            self.screen.dismiss(None)
            return
        if self._card_has_focus():
            self.query_one('#prompt', TextArea).focus()
            return
        if self.dismiss_completion():
            return
        if self.interceptor is not None and await self.interceptor.try_handle("/cancel", self):
            return
        if not self.busy:
            self.query_one("#prompt", TextArea).clear()
            self._state = "idle"
            self._refresh_chrome()
            return
        self._state = "cancelling"
        self._set_activity_phase("Stopping")
        self._refresh_chrome()
        await self.runtime.cancel()

    async def action_clear_transcript(self) -> None:
        await self.query_one("#transcript", VerticalScroll).remove_children()
        self._assistant_entries.clear()
        self._all_tool_entries.clear()
        self._assistant = None
        self._tool_entries.clear()
        self._chat_rounds.clear()
        self._chat_archive = None
        await self._add_notice("Transcript view cleared; persisted conversation is unchanged.")
