"""Interactive context-capacity configuration."""

from dataclasses import replace

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Input, Label, Select

from inquirycraft.cli.chat_profiles import DEFAULT_WINDOW, PRESETS


class ProfileScreen(ModalScreen):
    CSS = '''
    ProfileScreen { align: center middle; background: $host-surface 50%; }
    #profile-form { width: 64; max-width: 100%; height: auto; max-height: 95%; overflow-y: auto; padding: 1 2; background: $host-surface; border: round #8FA9C4; }
    #profile-form Input, #profile-form Select { height: 3; }
    #profile-error { color: #E99AA3; height: auto; }
    #profile-buttons { height: 3; }
    '''
    BINDINGS = [('escape', 'dismiss', 'Close')]

    def __init__(self, monitor):
        super().__init__()
        self.monitor = monitor

    def compose(self) -> ComposeResult:
        profile = self.monitor.profiles[0]
        with Vertical(id='profile-form'):
            yield Label('Context capacity · exact tokens')
            yield Select([(f'{i + 1}: {route[1]} [{key[:8]}]', i) for i, (route, key) in
                          enumerate(zip(self.monitor.routes, self.monitor.keys))], value=0, allow_blank=False, id='route')
            yield Select([('Custom', 0), *[(name, value) for name, value in PRESETS.items()]], value=profile.window if profile.window in PRESETS.values() else 0, allow_blank=False, id='preset')
            for name, value in [('window', profile.window or DEFAULT_WINDOW),
                                ('output_reserve', profile.output_reserve),
                                ('safety', profile.safety), ('trigger', profile.trigger)]:
                yield Label(name.replace('_', ' '))
                yield Input(str(value), id=name)
            yield Label('', id='profile-error')
            with Horizontal(id='profile-buttons'):
                yield Button('Save', id='save', variant='primary')
                yield Button('Cancel', id='cancel')

    def on_select_changed(self, event: Select.Changed):
        if event.select.id == 'preset' and event.value:
            self.query_one('#window', Input).value = str(event.value)
        if event.select.id == 'route' and isinstance(event.value, int):
            profile = self.monitor.profiles[event.value]
            for name in ('window', 'output_reserve', 'safety', 'trigger'):
                value = getattr(profile, name)
                self.query_one('#' + name, Input).value = '' if value is None else str(value)

    def on_button_pressed(self, event: Button.Pressed):
        if event.button.id == 'cancel':
            self.dismiss(None)
        elif event.button.id == 'save':
            index = self.query_one('#route', Select).value
            try:
                values = {name: (float if name == 'trigger' else int)(self.query_one('#' + name, Input).value)
                          for name in ('window', 'output_reserve', 'safety', 'trigger')}
                self.monitor.set_profile(index, replace(self.monitor.profiles[index], **values))
            except (ValueError, TypeError, OSError) as exc:
                self.query_one('#profile-error', Label).update(str(exc))
                return
            self.dismiss(True)
