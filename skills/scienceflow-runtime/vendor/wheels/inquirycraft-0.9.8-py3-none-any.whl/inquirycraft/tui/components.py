"""Reusable InquiryCraft TUI transcript components."""

from __future__ import annotations

import re

from rich.console import Group
from rich.markdown import Markdown
from rich.text import Text
from rich.theme import Theme
from textual import events
from textual.widgets import Static

from .controller import sanitize_terminal_text
from .header import BrandHeader as BrandHeader
from .markdown_blocks import BorderlessBlockQuote
from .prompt_input import PromptInput as PromptInput
from .syntax_theme import TRANSPARENT_CODE_THEME
from .tool_card import ToolEntry as ToolEntry

USER_ROLE_COLOR = "#8FA9C4"
ASSISTANT_ROLE_COLOR = "#B8A4E3"
TRANSCRIPT_SEGMENT_DIVIDER = "────────────────────────"


_MARKDOWN_STYLES = {
    'markdown.em': 'italic', 'markdown.emph': 'italic',
    'markdown.strong': 'bold', 'markdown.s': 'strike',
    'markdown.h1': 'bold #DADCE7', 'markdown.h1.border': '#414956',
    'markdown.h2': 'bold #DADCE7', 'markdown.h3': 'bold #DADCE7',
    'markdown.h4': 'bold #C5D1DF', 'markdown.h5': 'bold #C5D1DF',
    'markdown.h6': 'bold #AEBED0', 'markdown.h7': 'bold #AEBED0',
    'markdown.link': 'underline #8FA9C4', 'markdown.link_url': '#9297A3',
    'markdown.code': '#AFC4D8', 'markdown.code_block': '#AFC4D8',
    'markdown.block_quote': '#AEBED0', 'markdown.hr': '#414956',
    'markdown.list': '#8FA9C4', 'markdown.item': '#DADCE7',
    'markdown.item.bullet': '#8FA9C4', 'markdown.item.number': '#8FA9C4',
    'markdown.table.border': '#414956', 'markdown.table.header': 'bold #C5D1DF',
    'markdown.kbd': 'bold #AFC4D8',
}
MARKDOWN_THEME = Theme({
    **_MARKDOWN_STYLES,
    'markdown.paragraph': '#F5F7FA',
    'markdown.text': '#F5F7FA',
    'markdown.block_quote': '#F5F7FA',
    'markdown.item': '#F5F7FA',
})
REASONING_MARKDOWN_THEME = Theme({
    **_MARKDOWN_STYLES,
    'markdown.paragraph': '#AEB8C4',
    'markdown.text': '#AEB8C4',
})


class ThemedMarkdown(Markdown):
    elements = {**Markdown.elements, 'blockquote_open': BorderlessBlockQuote}

    def __init__(self, *args, highlight_text: bool = True, **kwargs) -> None:
        self.highlight_text = highlight_text
        kwargs.setdefault("code_theme", TRANSPARENT_CODE_THEME)
        super().__init__(*args, **kwargs)

    def __rich_console__(self, console, options):
        theme = MARKDOWN_THEME if self.highlight_text else REASONING_MARKDOWN_THEME
        with console.use_theme(theme):
            yield from super().__rich_console__(console, options)


class TranscriptEntry(Static):
    BINDINGS = [('enter', 'toggle_notice', 'Expand/collapse')]

    async def on_click(self, event: events.Click) -> None:
        """Make Rich hyperlinks work with an ordinary mouse click."""
        position = event.get_content_offset(self)
        if self._notice_collapsible and position is not None and position.y == 0:
            self.action_toggle_notice()
            event.stop()
            return
        from urllib.parse import urlsplit

        url = event.style.link
        if url and urlsplit(url).scheme in {'http', 'https'}:
            event.stop()
            import asyncio
            import os
            import webbrowser

            remote = bool(os.environ.get('SSH_CONNECTION') or os.environ.get('SSH_TTY'))
            opened = False
            if not remote:
                try:
                    opened = await asyncio.to_thread(webbrowser.open, url)
                except (OSError, webbrowser.Error):
                    pass
            if not opened:
                self.app.copy_to_clipboard(url)
                notified = getattr(self.app, '_notified_web_links', set())
                if url not in notified:
                    notified.add(url)
                    self.app._notified_web_links = notified
                    self.app.notify(
                        'Link copied · Open locally after port forwarding.' if remote else
                        'Link copied · Open in your browser.',
                        title='Web link', timeout=3,
                    )

    def __init__(self, role: str, content: str = "", *, notice_label: str = "IQCRAFT",
                 chat_lifecycle: bool = False, history_excluded: bool = False) -> None:
        self.notice_label = notice_label
        self.role = role
        self.chat_lifecycle = chat_lifecycle
        self.history_excluded = history_excluded
        self._notice_collapsible = False
        self._notice_expanded = True
        self._segments = [sanitize_terminal_text(content)]
        self._rich_segments: list[Text | None] = [None]
        self.content_text = self._segments[0]
        super().__init__("", classes=f"transcript-entry {role}", markup=False)
        self._refresh_content()

    def enable_notice_folding(self) -> None:
        """Allow explicit display-only folding for an opted-in host notice."""
        if self.role == 'notice':
            self._notice_collapsible = self.can_focus = True
            self._refresh_content()

    def action_toggle_notice(self) -> None:
        if not self._notice_collapsible:
            return
        self._notice_expanded = not self._notice_expanded
        self._refresh_content()
        if self.is_mounted:
            from textual.containers import VerticalScroll

            transcript = self.app.query_one('#transcript', VerticalScroll)
            transcript.pause_follow()
            transcript.content_changed()

    def set_content(self, content: str) -> None:
        self._segments[-1] = sanitize_terminal_text(content)
        self._rich_segments[-1] = None
        self._sync_content_text()
        self._refresh_content()

    def append_content(self, content: str) -> None:
        self._segments[-1] += sanitize_terminal_text(content)
        self._rich_segments[-1] = None
        self._sync_content_text()
        self._refresh_content()

    def set_rich_content(self, content: Text) -> None:
        """Preserve trusted Rich styling while keeping sanitized plain text."""
        clean = sanitize_terminal_text(content.plain)
        self._segments[-1] = clean
        self._rich_segments[-1] = content.copy() if clean == content.plain else Text(clean)
        self._sync_content_text()
        self._refresh_content()

    @property
    def segment_count(self) -> int:
        return len(self._segments)

    def grouping_key(self) -> tuple[object, ...]:
        return (
            type(self),
            self.role,
            self.notice_label,
            self.chat_lifecycle,
            self.history_excluded,
            getattr(self, "markdown", None),
            self._failed(),
        )

    def append_entry(self, entry: TranscriptEntry) -> None:
        """Append a same-role visual segment without changing stored messages."""
        if self.grouping_key() != entry.grouping_key():
            raise ValueError("Transcript entries must share a grouping key")
        self._segments.extend(entry._segments)
        self._rich_segments.extend(
            value.copy() if value is not None else None
            for value in entry._rich_segments
        )
        self._sync_content_text()
        self._refresh_content()

    def _sync_content_text(self) -> None:
        separator = f"\n{TRANSCRIPT_SEGMENT_DIVIDER}\n"
        self.content_text = separator.join(self._segments)

    def _failed(self) -> bool:
        body = "\n".join(self._segments)
        return self.role == "notice" and bool(re.search(
            r"\bfailed\b(?!\s*0)|\berror:|could not|失败", body, re.IGNORECASE))

    def _body_text(self, value: str, rich: Text | None) -> Text:
        style = "#F5F7FA" if self.role == "user" else "#DADCE7"
        return rich.copy() if rich is not None else Text(value or "…", style=style)

    def _refresh_content(self) -> None:
        labels = {
            "assistant": "ASSISTANT",
            "notice": self.notice_label,
            "tool": "TOOL",
            "user": "YOU",
        }
        label = labels.get(self.role, self.role.upper())
        tone = {"user": USER_ROLE_COLOR, "assistant": ASSISTANT_ROLE_COLOR,
                "notice": "#E1C694", "tool": "#9AA7B7"}.get(self.role, "#9297A3")
        failed = self._failed()
        self.set_class(failed, "error")
        self.label_color = "#E99AA3" if failed else tone
        if self._notice_collapsible and not self._notice_expanded:
            summary = Text('▸ ' + label, style=self.label_color + ' bold', no_wrap=True, overflow='ellipsis')
            first_line = self.content_text.splitlines()[0] if self.content_text else '…'
            summary.append(' · ' + first_line, style='#DADCE7')
            if self.segment_count > 1:
                summary.append(f' · {self.segment_count} notices', style='#9297A3')
            self.update(summary)
            return
        content = Text()
        if self.role not in {'user', 'assistant'}:
            if self._notice_collapsible:
                content.append('▾ ', style=self.label_color)
            content.append(label + "\n", style=self.label_color + " bold")
        for index, (value, rich) in enumerate(
            zip(self._segments, self._rich_segments, strict=True)
        ):
            if index:
                content.append("\n")
                content.append(TRANSCRIPT_SEGMENT_DIVIDER, style="#414956")
                content.append("\n")
            if self.role == 'user':
                content.append('> ', style=USER_ROLE_COLOR)
            content.append_text(self._body_text(value, rich))
        for match in re.finditer(r'https?://[^\s<>]+', content.plain):
            url = match.group().rstrip('.,，。);')
            content.stylize(f'underline link {url}', match.start(), match.start() + len(url))
        self.update(content)



class AssistantEntry(TranscriptEntry):
    STREAM_REFRESH_INTERVAL = 0.04

    def __init__(self, *, markdown: bool = True) -> None:
        self.markdown = markdown
        self._reasoning_segments = [""]
        self.reasoning_text = ""
        self.show_reasoning = False
        self.tool_call_count: int | None = None
        self._stream_refresh_pending = False
        self._stream_dirty = False
        super().__init__("assistant")

    def append_content(self, content: str) -> None:
        self._segments[-1] += sanitize_terminal_text(content)
        self._rich_segments[-1] = None
        self._sync_content_text()
        self._schedule_stream_refresh()

    def append_reasoning(self, content: str) -> None:
        self._reasoning_segments[-1] += sanitize_terminal_text(content)
        self.reasoning_text = "\n\n".join(self._reasoning_segments)
        self._schedule_stream_refresh()

    def _schedule_stream_refresh(self) -> None:
        """Coalesce rapid deltas so Markdown is parsed at display cadence."""
        self._stream_dirty = True
        if not self.is_mounted:
            self.flush_stream_content()
        elif not self._stream_refresh_pending:
            self._stream_refresh_pending = True
            self.set_timer(self.STREAM_REFRESH_INTERVAL, self.flush_stream_content)

    def flush_stream_content(self) -> None:
        self._stream_refresh_pending = False
        if not self._stream_dirty:
            return
        self._stream_dirty = False
        self._refresh_content()
        if self.is_mounted:
            transcript = self.app.query_one('#transcript')
            transcript.content_changed()

    def append_entry(self, entry: TranscriptEntry) -> None:
        super().append_entry(entry)
        if isinstance(entry, AssistantEntry):
            self._reasoning_segments.extend(entry._reasoning_segments)
        else:
            self._reasoning_segments.extend("" for _ in entry._segments)
        self.reasoning_text = "\n\n".join(self._reasoning_segments)
        self._refresh_content()

    def toggle_reasoning(self) -> None:
        self.show_reasoning = not self.show_reasoning
        self._refresh_content()

    def _refresh_content(self) -> None:
        if self.markdown:
            parts = []
            for index, value in enumerate(self._segments):
                if index:
                    parts.append(Text(TRANSCRIPT_SEGMENT_DIVIDER, style="#414956"))
                reasoning = (
                    self._reasoning_segments[index]
                    if index < len(self._reasoning_segments)
                    else ""
                )
                if self.show_reasoning and reasoning:
                    parts.extend([
                        Text("Thinking", style="#DADCE7 bold"),
                        ThemedMarkdown(
                            reasoning,
                            code_theme=TRANSPARENT_CODE_THEME,
                            highlight_text=False,
                        ),
                    ])
                parts.append(ThemedMarkdown(value or "…", code_theme=TRANSPARENT_CODE_THEME))
            self.update(Group(*parts))
        else:
            content = Text()
            for index, value in enumerate(self._segments):
                if index:
                    content.append("\n")
                    content.append(TRANSCRIPT_SEGMENT_DIVIDER, style="#414956")
                    content.append("\n")
                reasoning = (
                    self._reasoning_segments[index]
                    if index < len(self._reasoning_segments)
                    else ""
                )
                if self.show_reasoning and reasoning:
                    content.append(f"Thinking\n{reasoning}\n\nAnswer\n", style="#DADCE7")
                content.append(value or "…", style="#F5F7FA")
            self.update(content)
