"""Generic embedding panels and terminal chrome, without domain dependencies."""

import time
from dataclasses import replace

from rich.text import Text
from textual.containers import VerticalScroll
from textual.widgets import Button, Static, TextArea

from .controller import sanitize_terminal_text
from .dashboard_layout import aligned_summary as aligned_summary
from .formatting import style_progress
from .internal_messages import is_background_shell_result
from .resource_status import TuiResourceStatus
from .shell_job_view import refresh_activity_status
from .theme import TUI_HELP


class TuiDashboard(TuiResourceStatus):
    ACTIVITY_FRAMES = ("⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏")

    async def mount_host_extension(self):
        self._activity_timer = self.set_interval(
            1 / 6,
            self._tick_activity,
            name="activity-indicator",
            pause=True,
        )
        self.register_commands(
            getattr(self.interceptor, "tui_commands", ()),
            common_commands=getattr(self.interceptor, "tui_common_commands", None),
        )
        if getattr(self.runtime, "chat_monitor", None) is not None:
            self.set_interval(2, self._refresh_chrome)
        hook = getattr(self.interceptor, "on_mount", None)
        if hook is not None:
            await hook(self)

    def set_host_panel(self, summary: str, rows: tuple[str, ...] = ()) -> None:
        self._host_tasks = None
        self._last_host_task_presentation = None
        stop_task_pulse = getattr(self, '_set_task_pulse', None)
        if stop_task_pulse is not None:
            stop_task_pulse(False)
        self.query_one('#research-summary', Static).display = True
        self._panel_content = (summary, rows)
        summary, title = aligned_summary(summary, self.size.width)
        collapsed = getattr(self, "_panel_collapsed", False)
        panel = self.query_one("#research-panel", VerticalScroll)
        panel.remove_class('task-list')
        panel.styles.height = 3 if collapsed else 'auto'
        panel.set_class(collapsed, "collapsed")
        self.query_one("#research-toggle", Button).label = "▸ Progress · Ctrl+P" if collapsed else f"▾ Progress{' · ' + title if title else ''} · Ctrl+P"
        height = 6 if self.size.height < 28 else max(7, min(15, self.size.height // 3))
        panel.styles.max_height = 3 if collapsed else height
        issues = tuple(row for row in rows if any(word in row.lower() for word in ("failed", "needs review", "error", "stale", "失败", "无效")))
        filtered = getattr(self, "_panel_filter", False)
        filter_button = self.query_one("#research-filter", Button)
        filter_button.label = "All" if filtered else f"Issues {len(issues)}"
        filter_button.display = not collapsed and bool(issues or filtered)
        if filtered:
            rows = issues
        page_size = max(1, min(8, height - 9))
        pages = max(1, (len(rows) + page_size - 1) // page_size)
        self._panel_page = min(max(0, getattr(self, "_panel_page", 0)), pages - 1)
        offset = self._panel_page * page_size
        self.query_one("#research-page", Static).update(f"{offset + 1}–{min(offset + page_size, len(rows))}/{len(rows)}" if rows else "")
        for name, disabled in (("prev", self._panel_page == 0), ("next", self._panel_page == pages - 1)):
            button = self.query_one("#research-" + name, Button)
            button.display = not collapsed and pages > 1
            button.disabled = disabled
        self.query_one("#research-page", Static).display = not collapsed
        rows = rows[offset:offset + page_size]
        self.query_one("#research-workers", Static).display = not collapsed
        panel.display = bool(summary or rows)
        if collapsed:
            lines = summary.splitlines()
            summary = next((line for line in lines if line.startswith("Time ")),
                           lines[0] if lines else "Research running")
            if summary.startswith("Time "):
                summary = "Time " + summary[5:].lstrip()
            if self.size.width < 80:
                summary = summary.replace("Time ", "").replace("remaining ", "left ")
                summary = summary.replace("■ ", "■").replace("□ ", "□")
        heading = Text(no_wrap=True, overflow="ellipsis")
        lines = sanitize_terminal_text(summary).splitlines()
        if self.size.height < 28:
            lines = lines[:2]
        for index, line in enumerate(lines):
            heading.append(line + "\n", style="bold #DADCE7" if index == 0 else "#9297A3")
        heading.rstrip()
        style_progress(heading)
        heading.highlight_regex(r"(?m)^[^·\n]+(?= · Workers)", style="bold #DADCE7")
        heading.highlight_regex(r"(?i)\bWorkers\s+\d+|\brunning\s+[1-9][0-9]*", style="bold #DADCE7")
        heading.highlight_regex(r"(?i)\bwaiting\s+[1-9][0-9]*", style="#D8BE91")
        heading.highlight_regex(r"(?m)^(Time|Workers|Result|Usage|Research usage|ESTRA|EEC|Resources)", style="bold #DADCE7")
        heading.highlight_regex(r"\b(?:Best) [^·\n]+", style="bold #DADCE7")
        heading.highlight_regex(r"\b\d+%|\b\d{2}:\d{2}/\d{2}:\d{2}", style="#8FA9C4")
        heading.highlight_words(["■"], style="bold #8FA9C4")
        heading.highlight_words(["□"], style="#536575")
        heading.highlight_regex(r"(?i)(?:failed|issues)\s+[1-9][0-9]*", style="bold #D8BE91")
        self.query_one("#research-summary", Static).update(heading)
        workers = Text(no_wrap=True, overflow="ellipsis")
        for row in rows:
            clean = sanitize_terminal_text(row)
            tone = "#9297A3"
            if any(word in clean.lower() for word in ("invalid", "failed", "needs review", "无效", "失败")):
                tone = "#D8BE91"
            elif any(word in clean.lower() for word in ("wait", "retry", "等待", "重试")):
                tone = "#D8BE91"
            elif any(word in clean.lower() for word in ("completed", "完成")):
                tone = "#8FA9C4"
            else:
                tone = "#8FA9C4"
            worker = Text(clean + "\n", style="#9297A3")
            worker.highlight_regex(r"waiting|running|failed|needs review|completed|invalid|retry", style=tone)
            worker.highlight_regex(r"^[^: ]+:?", style="bold #DADCE7")
            worker.highlight_regex(r"· best\s+[^·]+", style="#DADCE7")
            worker.highlight_regex(r"· [^·]+ ago$", style="#9297A3")
            workers.append_text(worker)
        self.query_one("#research-workers", Static).update(workers)

    def action_toggle_host_panel(self) -> None:
        if getattr(self, '_host_tasks', None) is not None:
            self._panel_user_override = True
        self._panel_collapsed = not getattr(self, "_panel_collapsed", False)
        self._render_current_panel()

    def _render_current_panel(self):
        if getattr(self, '_host_tasks', None) is not None:
            self._render_host_tasks()
        else:
            self.set_host_panel(*getattr(self, '_panel_content', ('', ())))

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id in {
            "research-filter",
            "research-prev",
            "research-next",
            "research-toggle",
        }:
            event.button.remove_class("-active")
        if event.button.id == "jump-latest":
            self.query_one("#transcript").resume_follow()
            self.query_one("#prompt", TextArea).focus()
            event.stop()
        elif event.button.id == "research-filter":
            self._panel_filter = not getattr(self, "_panel_filter", False)
            self._panel_page = 0
            self._render_current_panel()
            event.stop()
        elif event.button.id in {"research-prev", "research-next"}:
            self._panel_page = getattr(self, "_panel_page", 0) + (1 if event.button.id == "research-next" else -1)
            self._render_current_panel()
            event.stop()
        elif event.button.id == "research-toggle":
            keyboard = getattr(event.button, '_keyboard_activation', False)
            event.button._keyboard_activation = False
            self.action_toggle_host_panel()
            if keyboard:
                rows = self.query_one('#research-workers')
                (rows if rows.display else event.button).focus()
            else:
                self.query_one("#prompt", TextArea).focus()
            event.stop()

    def _start_activity(self, phase: str = "Thinking") -> None:
        if getattr(self, "_activity_started", None) is None:
            self._activity_started = time.monotonic()
            self._activity_frame = 0
        self._activity_phase = sanitize_terminal_text(phase).replace("\n", " ")
        timer = getattr(self, "_activity_timer", None)
        if timer is not None:
            timer.resume()
        self._refresh_activity_status()

    def _set_activity_phase(self, phase: str) -> None:
        if getattr(self, "_activity_started", None) is None:
            self._start_activity(phase)
            return
        self._activity_phase = sanitize_terminal_text(phase).replace("\n", " ")
        self._refresh_activity_status()

    def _stop_activity(self) -> None:
        timer = getattr(self, "_activity_timer", None)
        if timer is not None:
            timer.pause()
        self._activity_started = None
        self._activity_phase = ""
        self._activity_frame = 0
        self._refresh_activity_status()

    def _tick_activity(self) -> None:
        if getattr(self, "_activity_started", None) is None:
            return
        self._activity_frame = (self._activity_frame + 1) % len(self.ACTIVITY_FRAMES)
        self._refresh_activity_status()
        entries = getattr(self, '_tool_entries', {})
        updated = False
        for tool_id in getattr(self, '_active_tool_names', ()):
            entry = entries.get(tool_id)
            if entry is not None:
                updated = entry.refresh_running_status() or updated
        if updated:
            self.query_one('#transcript').content_changed()

    def _refresh_activity_status(self) -> None:
        refresh_activity_status(self)

    def _refresh_chrome(self) -> None:
        if not self.is_mounted or len(self.screen_stack) > 1:
            return
        pending = tuple(
            item for item in self.runtime.pending_messages()
            if not is_background_shell_result(getattr(item, "content", None))
        )
        pending_text = ""
        queues: dict[str, int] = {}
        for item in pending:
            queue = str(getattr(item, "queue", "queued"))
            queues[queue] = queues.get(queue, 0) + 1
        if self._queued_chat_prompts:
            queues["chat"] = len(self._queued_chat_prompts)
        if queues:
            pending_text = "pending · " + " · ".join(
                f"{name}:{count}" for name, count in sorted(queues.items())
            )
        pending_widget = self.query_one("#pending", Static)
        pending_state = (bool(pending_text), pending_text)
        if pending_state != getattr(self, "_last_pending_state", None):
            pending_widget.display = pending_state[0]
            pending_widget.update(pending_text)
            self._last_pending_state = pending_state
        self._refresh_activity_status()
        self._refresh_resource_footer()

    async def handle_chat_command(self, text):
        parts = text.strip().split()
        if not parts:
            return False
        if parts[0] == '/' and len(parts) > 1:
            parts = ['/' + parts[1], *parts[2:]]
        command = parts[0].casefold()
        arguments = parts[1:]
        if command == '/compact':
            from .compact_command import compact_chat

            await compact_chat(self, arguments)
            return True
        if command == "/panel":
            self.action_toggle_host_panel()
            return True
        if command not in {"/usage", "/context"}:
            return False
        monitor = getattr(self.runtime, "chat_monitor", None)
        if monitor is None:
            await self.notice("This host has not enabled chat profile/usage support.")
        elif arguments and command != "/context":
            await self.notice(f"Use {command} without arguments.")
        elif command == "/usage":
            await self.notice(monitor.details())
        elif self.busy:
            await self.notice("Finish or cancel the current chat request before changing its profile.")
        elif arguments:
            from inquirycraft.cli.chat_profiles import PRESETS
            try:
                if len(arguments) != 1:
                    raise ValueError("Choose one context capacity.")
                value = arguments[0].upper()
                window = PRESETS[value] if value in PRESETS else int(value)
                index = max(0, monitor.active)
                monitor.set_profile(index, replace(monitor.profiles[index], window=window))
            except (ValueError, TypeError, OSError) as exc:
                await self.notice(f"{exc} Use /context, /context 256K, /context 1M, or /context 262144.")
            else:
                await self.notice(f"Context capacity saved: {window:,} tokens for {monitor.routes[index][1]}. Use /context to configure other pool routes.")
                self._refresh_chrome()
        else:
            from .profile_screen import ProfileScreen
            self.push_screen(ProfileScreen(monitor))
        return True

    def _status_text(self, *, verbose: bool = False) -> str:
        pending = sum(
            not is_background_shell_result(getattr(item, "content", None))
            for item in self.runtime.pending_messages()
        ) + len(self._queued_chat_prompts)
        started = getattr(self, "_activity_started", None)
        if started is None:
            base = (
                ""
                if self._state == "idle" and pending == 0
                else f"{self._state} · pending:{pending}"
            )
        else:
            elapsed = max(0, int(time.monotonic() - started))
            duration = (
                f"{elapsed // 3600:d}h {(elapsed % 3600) // 60:02d}m"
                if elapsed >= 3600
                else f"{elapsed // 60:d}m {elapsed % 60:02d}s"
                if elapsed >= 60
                else f"{elapsed:02d}s"
            )
            frame = self.ACTIVITY_FRAMES[getattr(self, "_activity_frame", 0)]
            phase = getattr(self, "_activity_phase", "Thinking")
            base = f"{frame} {phase} · {duration} · pending:{pending}"
        transcript = self.query_one("#transcript", VerticalScroll) if self.is_mounted else None
        if transcript is not None and transcript.is_vertical_scroll_end:
            self._unread = 0
        if getattr(self, "_unread", 0):
            base += (" · " if base else "") + f"{self._unread} new entries ↓"
        if self._host_status:
            base += (" · " if base else "") + self._host_status
        if verbose:
            details = (
                f"turn:{self._turn} · tokens ↑{self._input_tokens} "
                f"↓{self._output_tokens} · model:{self.model}"
            )
            return f"{base} · {details}" if base else details
        return base

    async def action_show_help(self) -> None:
        specs = self._command_specs()
        common = " · ".join(name for name in self._common_commands if name in specs)
        await self._add_notice(f"Common: {common}\n{TUI_HELP}")

    async def action_toggle_reasoning(self) -> None:
        for entry in self._assistant_entries:
            entry.toggle_reasoning()

    async def action_toggle_tools(self) -> None:
        self._tool_details = not self._tool_details
        for entry in self._all_tool_entries:
            if entry.expanded != self._tool_details:
                entry.toggle_details()

    def action_history_up(self):
        if len(self.screen_stack) == 1:
            self.query_one('#transcript').action_page_up()

    def action_history_down(self):
        if len(self.screen_stack) == 1:
            self.query_one('#transcript').scroll_page_down(animate=False)

    def action_latest(self):
        if len(self.screen_stack) == 1:
            self.query_one('#transcript').resume_follow()
