"""Strictly contiguous, presentation-only folding for assistant tool work."""

from __future__ import annotations

from rich.text import Text
from textual import events
from textual.containers import VerticalScroll
from textual.widgets import Static

from .components import AssistantEntry, TranscriptEntry
from .tool_card import ToolEntry


class AssistantToolGroup(Static):
    """A summary controlling existing transcript entries without owning them."""

    can_focus = True
    BINDINGS = [('enter', 'toggle', 'Expand')]

    def __init__(self, entries: tuple[Static, ...]) -> None:
        self.entries = entries
        self.expanded = False
        super().__init__('', classes='transcript-entry assistant-tool-group', markup=False)
        self._set_entries_visible(False)
        self._refresh_content()

    def _set_entries_visible(self, visible: bool) -> None:
        for entry in self.entries:
            entry.display = visible

    def _refresh_content(self) -> None:
        steps = sum(isinstance(entry, AssistantEntry) for entry in self.entries)
        tools = [entry for entry in self.entries if isinstance(entry, ToolEntry)]
        failed = sum(entry.state == 'failed' for entry in tools)
        summary = Text('▾' if self.expanded else '▸', style='#8FA9C4')
        summary.append(' TOOLS', style='bold #C5D1DF')
        summary.append(
            f" · {steps} {'step' if steps == 1 else 'steps'}"
            f" · {len(tools)} tools",
            style='#9297A3',
        )
        if failed:
            summary.append(f' · {failed} failed', style='bold #E99AA3')
        self.set_class(self.expanded, 'expanded')
        self.update(summary)

    def action_toggle(self) -> None:
        self.expanded = not self.expanded
        self._set_entries_visible(self.expanded)
        self._refresh_content()
        if self.is_mounted:
            self.app.query_one('#transcript', VerticalScroll).content_changed()

    def on_click(self, event: events.Click) -> None:
        self.action_toggle()
        event.stop()


class TuiTranscriptGrouping:
    """Mount transcript entries and fold only a directly adjacent tool chain."""

    async def begin_transcript_section(self) -> object:
        from .transcript_sections import begin_section

        return await begin_section(self)

    async def fold_transcript_section(self, section: object, summary: str) -> bool:
        from .transcript_sections import fold_section

        return await fold_section(self, section, summary)

    async def _mount_entry(self, entry: Static, *, merge_with_previous: bool = True) -> Static:
        transcript = self.query_one('#transcript', VerticalScroll)
        standalone_notice = False
        if isinstance(entry, TranscriptEntry) and entry.role == 'notice':
            entry.set_class(bool(getattr(self.branding, 'notice_background', '')), 'notice-surface')
            if getattr(self.branding, 'fold_system_notices', False):
                entry.enable_notice_folding()
                from .notice_history import is_task_launch_notice

                standalone_notice = is_task_launch_notice(entry)
        if merge_with_previous and isinstance(entry, TranscriptEntry) and transcript.children:
            previous = transcript.children[-1]
            if (
                isinstance(previous, TranscriptEntry)
                and not standalone_notice
                and previous.display
                and previous.grouping_key() == entry.grouping_key()
            ):
                previous.append_entry(entry)
                transcript.content_changed()
                return previous
        await transcript.mount(entry)
        if isinstance(entry, TranscriptEntry) and entry.role == 'notice':
            from .notice_history import fold_task_notice

            await fold_task_notice(self, entry)
        transcript.content_changed()
        return entry

    async def _fold_preceding_tool_sequence(
        self,
        final: AssistantEntry,
    ) -> AssistantToolGroup | None:
        """Fold the maximal adjacent tool chain immediately before a final answer."""
        transcript = self.query_one('#transcript', VerticalScroll)
        children = list(transcript.children)
        try:
            final_index = children.index(final)
        except ValueError:
            return None
        if not final.content_text.strip():
            return None

        candidate: list[Static] = []
        for entry in reversed(children[:final_index]):
            if isinstance(entry, TranscriptEntry) and entry.role == 'notice' and entry.chat_lifecycle:
                continue
            if isinstance(entry, ToolEntry):
                candidate.append(entry)
            elif (
                isinstance(entry, AssistantEntry)
                and getattr(entry, 'tool_call_count', None)
            ):
                candidate.append(entry)
            else:
                break
        candidate.reverse()
        while candidate and not isinstance(candidate[0], AssistantEntry):
            candidate.pop(0)
        tool_count = sum(isinstance(entry, ToolEntry) for entry in candidate)
        if (
            tool_count < 2
            or not candidate
            or not isinstance(candidate[0], AssistantEntry)
            or not isinstance(candidate[-1], ToolEntry)
        ):
            return None

        group = AssistantToolGroup(tuple(candidate))
        await transcript.mount(group, before=final)
        transcript.content_changed()
        return group
