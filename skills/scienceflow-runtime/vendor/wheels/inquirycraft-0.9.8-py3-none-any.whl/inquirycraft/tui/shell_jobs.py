"""TUI-owned shell jobs: detach waiting, never duplicate execution."""

import asyncio
import hashlib
import json
import os
import time
from dataclasses import dataclass, replace
from uuid import uuid4

from inquirycraft.runtime.cancellation import CancellationToken
from inquirycraft.tools import BaseTool, ShellTool, ToolResult
from inquirycraft.tools.path_policy import PathGuard, atomic_write


@dataclass
class ShellJob:
    number: int
    command: str
    workspace: str
    started: float
    cancellation: CancellationToken
    log: str
    finished: float | None = None
    task: asyncio.Task | None = None
    result: ToolResult | None = None
    detached: bool = False
    tail: str = ""
    entry: object = None
    notified: bool = False
    reported: bool = False
    stop_requested: bool = False

    def stop(self):
        self.stop_requested = True
        self.cancellation.cancel()

    @property
    def running(self):
        return self.task is not None and not self.task.done()


class ShellJobs:
    """Jobs belong to one chat runtime, not the research runtime or a daemon."""

    def __init__(self, runtime, *, yield_after=10.0, max_running=4):
        self.runtime = runtime
        self.yield_after, self.max_running = yield_after, max_running
        key = hashlib.sha256(runtime.context.session_id.encode()).hexdigest()[:16]
        self.root = PathGuard(runtime.context.workspace).resolve(f".logs/shell_jobs/{key}")
        self.jobs = {}
        self.completed = asyncio.Queue()
        self.closed = False
        self.next_number = 1
        self.recovered = 0
        self.warning = ""
        if (self.root / "jobs.json").exists():
            try:
                rows = json.loads((self.root / "jobs.json").read_text())
                if not isinstance(rows, list) or any(
                    not isinstance(row, dict)
                    or type(row.get("number")) is not int
                    or row["number"] < 1
                    or not isinstance(row.get("status"), str)
                    for row in rows
                ):
                    raise ValueError("Invalid shell job history")
            except (OSError, ValueError):
                rows = []
                self.warning = "Shell job history could not be read; existing logs were retained."
            self.next_number = max((row["number"] for row in rows), default=0) + 1
            self.recovered = sum(row["status"] == "running" for row in rows)
            # A new process cannot prove ownership of an old PID. Never replay
            # or kill it based on stale metadata; retain an interrupted record.
            for row in rows:
                if row["status"] == "running":
                    row["status"] = "interrupted"
            self.previous = rows[-100:]
        else:
            self.previous = []

    @property
    def running(self):
        return [job for job in self.jobs.values() if job.detached and job.running]

    def save(self):
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        rows = [
            *self.previous,
            *[
                {
                    "number": job.number,
                    "command": job.command,
                    "workspace": job.workspace,
                    "status": "running"
                    if job.result is None
                    else ("failed" if job.result.is_error else "done"),
                    "log": job.log,
                    "result": job.result.render()[-2000:] if job.result is not None else None,
                }
                for job in self.jobs.values()
            ],
        ]
        atomic_write(self.root / "jobs.json", json.dumps(rows[-100:], ensure_ascii=False))
        (self.root / "jobs.json").chmod(0o600)

    async def execute(self, tool, arguments, context):
        if self.closed:
            return ToolResult(error="Shell job manager is closed")
        if sum(job.running for job in self.jobs.values()) >= self.max_running:
            return ToolResult(
                error=f"{self.max_running} shell jobs are already running; use shell_job to wait or stop one."
            )
        for key, old in list(self.jobs.items()):
            if len(self.jobs) < 100:
                break
            if not old.running and (not old.detached or old.notified):
                del self.jobs[key]
        number = self.next_number
        self.next_number += 1
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        job = ShellJob(
            number,
            str(arguments.get("command", "")),
            str(context.workspace),
            time.monotonic(),
            CancellationToken(),
            str(self.root / f"{number}-{uuid4().hex}.log"),
        )
        self.jobs[number] = job

        try:
            self.save()
        except OSError:
            del self.jobs[number]
            raise  # No process has started if its ownership record cannot be saved.
        job.task = asyncio.create_task(self._run(job, tool, arguments, context))
        cancelled = asyncio.create_task(context.cancellation.wait())
        try:
            done, _ = await asyncio.wait(
                {job.task, cancelled}, timeout=self.yield_after, return_when=asyncio.FIRST_COMPLETED
            )
            if cancelled in done:
                job.cancellation.cancel()
                return await asyncio.shield(job.task)
            if job.task in done:
                return job.task.result()
            job.detached = True
            return ToolResult(
                output=f"Shell job #{number} is still running in the background; NOT completed. "
                f"Use shell_job with job_id={number} to wait/check/stop. "
                "Do not repeat the command or start dependent work before it succeeds. "
                f"Completion is delivered automatically. Log: {job.log}",
                metadata={"shell_execution": {"status": "background", "job_id": number}},
            )
        except asyncio.CancelledError:
            job.cancellation.cancel()
            await asyncio.shield(job.task)
            raise
        finally:
            cancelled.cancel()
            await asyncio.gather(cancelled, return_exceptions=True)

    async def _run(self, job, tool, arguments, context):
        try:
            with os.fdopen(
                os.open(job.log, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), "w", encoding="utf-8"
            ) as output:

                async def progress(chunk):
                    output.write(chunk)
                    output.flush()
                    job.tail = (job.tail + chunk)[-32768:]
                    if not job.detached:
                        await context.report_progress(chunk)

                job.result = await tool.invoke(
                    arguments,
                    replace(
                        context,
                        cancellation=job.cancellation,
                        on_update=progress,
                    ),
                )
        except Exception as exc:
            job.result = ToolResult(error=f"{type(exc).__name__}: {exc}")
        job.finished = time.monotonic()
        try:
            self.save()
        except OSError:
            self.warning = "Shell job metadata could not be saved; inspect the output log."
        if job.detached:
            self.completed.put_nowait(job)
        return job.result

    async def close(self):
        self.closed = True
        for job in self.jobs.values():
            if job.running:
                job.cancellation.cancel()
        await asyncio.gather(
            *(j.task for j in self.jobs.values() if j.task is not None), return_exceptions=True
        )


class BackgroundShell(ShellTool):
    def __init__(self, original, jobs):
        self.original, self.jobs = original, jobs
        self.description = original.description + (
            " In TUI chat, commands still running after 10 seconds return a background job ID. "
            "Use shell_job to wait before dependent work; never assume background means success."
        )

    async def execute(self, arguments, context):
        return await self.jobs.execute(self.original, arguments, context)


class ShellJobTool(BaseTool):
    name = "shell_job"
    description = (
        "Check, wait for, or stop an existing TUI shell job. Never re-executes its command."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "job_id": {"type": "integer", "minimum": 1},
            "action": {"type": "string", "enum": ["status", "wait", "stop"]},
        },
        "required": ["job_id", "action"],
        "additionalProperties": False,
    }

    def __init__(self, jobs):
        self.jobs = jobs

    async def execute(self, arguments, context):
        job = self.jobs.jobs.get(arguments["job_id"])
        if job is None:
            return ToolResult(
                error="Unknown shell job; inspect its saved log instead of replaying it."
            )
        action = arguments["action"]
        if action == "stop":
            job.stop()
        if action in {"wait", "stop"} and job.running:
            # Bounded waits let steering reach the model even for a silent command.
            await asyncio.wait({job.task}, timeout=self.jobs.yield_after)
        if job.result is not None:
            job.reported = True
            return job.result
        return ToolResult(
            output=f"At this check, job #{job.number} was still running. "
            f"Completion will be delivered automatically. Log: {job.log}\n{job.tail[-2000:]}"
        )


def install_shell_jobs(runtime):
    tools = getattr(runtime, "tools", None)
    if tools is None or getattr(runtime, "shell_jobs", None) is not None:
        return
    original = tools.get_tool("shell")
    if not isinstance(original, ShellTool):
        return
    jobs = ShellJobs(runtime)
    tools.register(BackgroundShell(original, jobs), replace=True)
    tools.register(ShellJobTool(jobs))
    runtime.shell_jobs = jobs
