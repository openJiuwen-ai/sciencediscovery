"""Syntax colors that preserve the terminal's own background."""

from pygments.styles import get_style_by_name

_GITHUB_DARK = get_style_by_name("github-dark")


class TransparentGithubDark(_GITHUB_DARK):
    """GitHub-dark token colors without its opaque canvas."""

    background_color = None
    highlight_color = None
    styles = {
        token: " ".join(part for part in style.split() if not part.startswith("bg:"))
        for token, style in _GITHUB_DARK.styles.items()
    }


TRANSPARENT_CODE_THEME = TransparentGithubDark
