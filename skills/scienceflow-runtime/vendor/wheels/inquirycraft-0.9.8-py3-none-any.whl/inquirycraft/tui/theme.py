"""InquiryCraft terminal theme kept separate from runtime projection logic."""

from textual.binding import Binding
from textual.scrollbar import ScrollBar

from .scrollbar import ThinScrollBarRender

TUI_BINDINGS = [
    Binding("pageup", "history_up", "History", priority=True),
    Binding("pagedown", "history_down", "History", priority=True),
    Binding("ctrl+end", "latest", "Latest", priority=True),
    Binding("ctrl+p", "toggle_host_panel", "Progress", priority=True),
    Binding("ctrl+enter", "submit_prompt", "Send", priority=True),
    Binding("ctrl+s", "submit_prompt", "Send", priority=True),
    Binding("ctrl+c", "confirm_quit", "Quit twice", priority=True),
    Binding("escape", "cancel_run", "Cancel", priority=True),
    Binding("ctrl+l", "clear_transcript", "Clear", priority=True),
    Binding("ctrl+r", "toggle_reasoning", "Thinking", priority=True),
    Binding("ctrl+o", "toggle_tools", "Tools", priority=True),
    Binding("f1", "show_help", "Help", priority=True),
    Binding("ctrl+q", "quit_app", "Quit", priority=True),
]

TUI_HELP = (
    "Chat: /cancel cancels the current interaction · Ctrl+Q exits TUI\n"
    "Advanced · Queue: /steer TEXT · /follow-up TEXT · /next TEXT\n"
    "Advanced · Model: /context [256K|1M|TOKENS] · /usage (chat tokens and cost)\n"
    "Context: /compact compresses idle chat context; saved history stays intact\n"
    "Advanced · View: /panel toggles progress · /clear clears the view, not saved memory\n"
    "Type / for common commands; type a prefix to find advanced commands.\n"
    "Keys: Enter/Ctrl+S send · Alt+Enter newline · Esc cancel · Ctrl+C twice within 2s / Ctrl+Q quit · Ctrl+R thinking · "
    "Shift+↑/↓ cards · Enter expand · Esc back · Ctrl+O tool details · Ctrl+L clear · F1 help"
)


def configure_terminal_colors(app):
    """Configure terminal color handling and compact scrollbars."""
    import os

    from rich.console import Console

    ScrollBar.renderer = ThinScrollBarRender
    if (not app.no_color and not os.environ.get('TEXTUAL_COLOR_SYSTEM')
            and os.environ.get('TERM') in {'screen', 'tmux'}
            and app.console.color_system == 'standard'):
        app.console = Console(
            color_system='256', file=app.console.file, force_terminal=True,
            markup=True, highlight=False, emoji=False, legacy_windows=False,
            safe_box=False, soft_wrap=False,
        )
