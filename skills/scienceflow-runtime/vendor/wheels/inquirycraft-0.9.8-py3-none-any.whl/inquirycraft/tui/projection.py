"""Project runtime events without changing their persisted representation."""

from typing import Any

from inquirycraft.events import RuntimeEvent

from .components import AssistantEntry, ToolEntry
from .controller import sanitize_terminal_text
from .shell_job_view import bind_job_entry


class TuiProjection:
    def _new_tool_entry(self, payload):
        name = str(payload.get('name', 'tool'))
        tools = getattr(self.runtime, 'tools', None)
        get_tool = getattr(tools, 'get_tool', None)
        tool = get_tool(name) if callable(get_tool) else None
        arguments = payload.get('arguments') or self.tool_arguments(
            str(payload.get('tool_call_id', 'unknown'))
        )
        return ToolEntry(
            name, arguments=arguments,
            default_timeout_sec=getattr(tool, 'default_timeout_sec', None),
        )

    async def _handle_runtime_event(self, event: RuntimeEvent) -> None:
        payload = dict(event.payload)
        if event.turn_id is not None:
            self._turn = event.turn_id
        if event.type == "session.started":
            self._set_activity_phase(
                "Preparing task"
                if getattr(self, "_hide_host_response", False)
                else "Thinking"
            )
        elif event.type == "runtime.warning" and payload.get("reason") == "max_turns_reached":
            await self._add_notice("Turn limit reached; the task may be unfinished. "
                                   "Send a message to continue.", chat_lifecycle=True)
        elif event.type == "llm.retrying":
            self._set_activity_phase("Recovering request")
            await self._add_notice(
                f"Request interrupted; retrying (attempt {payload.get('next_attempt', '?')}).",
                chat_lifecycle=True,
            )
        elif event.type == "context.compacted":
            monitor = getattr(self.runtime, "chat_monitor", None)
            if monitor is not None:
                monitor.context_compacted(payload.get("estimated_tokens"))
            await self._add_notice(
                f"Context compacted: {payload.get('omitted_messages', 0)} older messages condensed; "
                "saved history is unchanged.", chat_lifecycle=True,
            )
        elif event.type == "context.compaction.failed":
            await self._add_notice("Context compaction failed; the request may exceed the model limit.",
                                   chat_lifecycle=True)
        elif event.type == "message.started" and not getattr(self, "_hide_host_response", False):
            self._set_activity_phase("Thinking")
            entry = AssistantEntry(markdown=self.markdown)
            mounted = await self._mount_entry(entry)
            if not isinstance(mounted, AssistantEntry):
                raise TypeError("Assistant transcript entry was not mounted")
            self._assistant = mounted
            if mounted not in self._assistant_entries:
                self._assistant_entries.append(mounted)
        elif event.type == "message.delta" and self._assistant is not None:
            channel = str(payload.get("channel", "content"))
            delta = sanitize_terminal_text(payload.get("delta", ""))
            if channel == "content":
                self._set_activity_phase("Responding")
                self._assistant.append_content(delta)
            elif channel == "reasoning":
                self._set_activity_phase("Thinking")
                self._assistant.append_reasoning(delta)
            self.query_one("#transcript").content_changed()
        elif event.type == "tool.requested":
            tool_id = str(payload.get("tool_call_id", event.event_id))
            entry = self._new_tool_entry(payload)
            entry.expanded = self._tool_details
            self._tool_entries[tool_id] = entry
            self._all_tool_entries.append(entry)
            await self._mount_entry(entry)
        elif event.type == "tool.started":
            entry = await self._tool_entry(payload)
            entry.update_tool(state="running")
            tool_id = str(payload.get("tool_call_id", event.event_id))
            tool_name = sanitize_terminal_text(payload.get("name", entry.tool_name))
            self._active_tool_names[tool_id] = tool_name
            self._set_activity_phase(f"Running {tool_name[:28]}")
        elif event.type == "tool.progress":
            entry = await self._tool_entry(payload)
            chunk = sanitize_terminal_text(payload.get("chunk", ""))
            if entry.tool_name.casefold() in {'shell', 'bash'}:
                if not entry.append_shell_progress(chunk):
                    return
            else:
                preview = (entry.preview + chunk)[-4000:]
                entry.update_tool(state="running", preview=preview, output_received=bool(chunk))
        elif event.type in {"tool.completed", "tool.failed"}:
            state = "failed" if event.type.endswith("failed") else "completed"
            entry = await self._tool_entry(payload)
            entry.update_tool(
                state=state,
                preview=str(payload.get("preview", "")),
            )
            bind_job_entry(self, payload, entry)
            tool_id = str(payload.get("tool_call_id", event.event_id))
            self._active_tool_names.pop(tool_id, None)
            if self._active_tool_names:
                tool_name = next(reversed(self._active_tool_names.values()))
                self._set_activity_phase(f"Running {tool_name[:28]}")
            else:
                self._set_activity_phase(
                    "Preparing task"
                    if getattr(self, "_hide_host_response", False)
                    else "Thinking"
                )
        elif event.type == "llm.completed":
            if self._assistant is not None:
                self._assistant.flush_stream_content()
                self._assistant.tool_call_count = int(
                    payload.get('tool_call_count', 0) or 0
                )
                if self._assistant.tool_call_count == 0:
                    await self._fold_preceding_tool_sequence(self._assistant)
            self._input_tokens += int(payload.get("input_tokens", 0) or 0)
            self._output_tokens += int(payload.get("output_tokens", 0) or 0)
            if payload.get('finish_reason') == 'length':
                await self._add_notice('Response truncated by the output token limit; '
                                       'the answer may be incomplete.', chat_lifecycle=True)
        elif event.type == "llm.attempt.failed":
            self._input_tokens += int(payload.get("input_tokens", 0) or 0)
            self._output_tokens += int(payload.get("output_tokens", 0) or 0)
        elif event.type == "session.cancelled":
            self._state = "cancelling"
        elif event.type == "session.failed":
            self._state = "error"
        if event.type.startswith("tool."):
            self.query_one("#transcript").content_changed()
        self._refresh_chrome()

    async def _tool_entry(self, payload: dict[str, Any]) -> ToolEntry:
        tool_id = str(payload.get("tool_call_id", "unknown"))
        entry = self._tool_entries.get(tool_id)
        if entry is None:
            entry = self._new_tool_entry(payload)
            entry.expanded = self._tool_details
            self._tool_entries[tool_id] = entry
            self._all_tool_entries.append(entry)
            await self._mount_entry(entry)
        return entry


    def sync_tool_details(self):
        for message in self.conversation_snapshot():
            if message.get('role') == 'tool':
                entry = self._tool_entries.get(message.get('tool_call_id'))
                if entry is not None:
                    job = getattr(entry, 'background_job', None)
                    preview = job.result.render() if job and job.result is not None else str(message.get('content', ''))
                    entry.update_tool(state=entry.state, preview=preview)
        self.query_one('#transcript').content_changed()

    def tool_arguments(self, tool_id):
        import json
        for message in reversed(self.conversation_snapshot()):
            for call in message.get('tool_calls') or ():
                if call.get('id') == tool_id:
                    arguments = call.get('function', {}).get('arguments', {})
                    try:
                        return json.loads(arguments) if isinstance(arguments, str) else arguments
                    except ValueError:
                        return {}
        return {}
