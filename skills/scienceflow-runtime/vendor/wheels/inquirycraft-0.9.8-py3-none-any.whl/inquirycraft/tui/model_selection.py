"""Session-scoped chat model selection behavior for the terminal UI."""

from __future__ import annotations

import inspect
from collections.abc import Callable, Sequence
from pathlib import Path
from typing import Any

from textual.widgets import TextArea

from .chat_model_picker import ChatModelPicker


class TuiModelSelection:
    """Manage the model picker without owning application lifecycle state."""

    def _initialize_model_selection(self) -> None:
        self._chat_model_apply: Callable[[str], Any] | None = None
        self._chat_model_selector_open = False

    async def switch_chat_models(
        self,
        model_config: Path,
        *,
        aliases: tuple[str, ...],
        selection: str,
    ) -> tuple[str, ...]:
        """Switch only the current session's chat provider pool."""
        from inquirycraft.llm import ModelRegistry

        registry = ModelRegistry.from_json(model_config)
        monitor = getattr(self.runtime, "chat_monitor", None)
        if monitor is None or not callable(getattr(monitor, "select_models", None)):
            raise ValueError("This TUI runtime does not support model switching.")
        monitor.model_registry = registry
        resolved = await monitor.select_models(aliases, selection)
        self.model = ",".join(aliases)
        self._refresh_chrome()
        return tuple(resolved.aliases)

    def open_chat_model_selector(
        self,
        model_config: Path,
        *,
        aliases: Sequence[str],
        current: Sequence[str],
        selection: str,
        config_hint: str = "",
        on_applied: Callable[[tuple[str, ...]], Any] | None = None,
    ) -> None:
        """Replace the bottom composer with the current chat model selector."""

        async def apply(alias: str) -> None:
            applied = await self.switch_chat_models(
                model_config,
                aliases=(alias,),
                selection=selection,
            )
            if on_applied is not None:
                result = on_applied(applied)
                if inspect.isawaitable(result):
                    await result
            self.notify(f"Chat model applied · {alias}", timeout=3)

        self._chat_model_apply = apply
        self._chat_model_selector_open = True
        self.dismiss_completion()
        picker = self.query_one("#chat-model-picker", ChatModelPicker)
        picker.configure(aliases, current, config_hint=config_hint)
        self.query_one("#dock").add_class("model-selecting")
        self.call_after_refresh(picker.focus_options)

    def _close_chat_model_selector(self) -> None:
        self._chat_model_selector_open = False
        self._chat_model_apply = None
        self.query_one("#dock").remove_class("model-selecting")
        self.query_one("#chat-model-picker", ChatModelPicker).set_busy(False)
        self.call_after_refresh(self.query_one("#prompt", TextArea).focus)

    def on_chat_model_picker_cancelled(self, event: ChatModelPicker.Cancelled) -> None:
        event.stop()
        self._close_chat_model_selector()

    def on_chat_model_picker_selected(self, event: ChatModelPicker.Selected) -> None:
        event.stop()
        if not self._chat_model_selector_open or self._chat_model_apply is None:
            return
        self.query_one("#chat-model-picker", ChatModelPicker).set_busy(True)
        self.run_worker(
            self._apply_chat_model_selection(event.alias),
            group="chat-model-selection",
            exclusive=True,
        )

    async def _apply_chat_model_selection(self, alias: str) -> None:
        apply = self._chat_model_apply
        if apply is None:
            return
        try:
            result = apply(alias)
            if inspect.isawaitable(result):
                await result
        except (OSError, RuntimeError, TypeError, ValueError) as exc:
            self.query_one("#chat-model-picker", ChatModelPicker).set_error(str(exc))
            return
        self._close_chat_model_selector()
