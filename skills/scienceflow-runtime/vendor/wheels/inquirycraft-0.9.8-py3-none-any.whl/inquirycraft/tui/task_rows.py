"""Generic expandable host rows; task semantics stay in the embedding application."""

import re

from rich.console import Console
from rich.text import Text
from textual import events
from textual.containers import VerticalScroll
from textual.message import Message
from textual.widgets import Static

from .controller import sanitize_terminal_text
from .palette import SURFACE_COLOR
from .task_layout import task_row_widths
from .task_presentation import (
    style_task_text,
    task_state_tone,
)


class HostTaskRows(Static):
    can_focus = True
    BINDINGS = [('up', 'previous', 'Previous'), ('down', 'next', 'Next'), ('enter', 'select', 'Expand'),
                ('shift+up', 'app.focus_previous_card', 'Previous card'),
                ('shift+down', 'app.focus_next_card', 'Next card')]

    class Selected(Message):
        def __init__(self, key, worker=None):
            super().__init__()
            self.key = key
            self.worker = worker

    class OlderSelected(Message):
        pass

    def show_items(
        self,
        items,
        expanded,
        *,
        width,
        expanded_worker=None,
        older_count=0,
        older_expanded=False,
        older_label='older tasks',
    ):
        text = Text(no_wrap=True, overflow='ellipsis')
        self.line_keys = []
        cursor_spans = []
        old_keys = getattr(self, '_navigation_keys', [])
        cursor = getattr(self, 'cursor', 0)
        selected = old_keys[cursor] if 0 <= cursor < len(old_keys) else None
        self.keys = [item['key'] for item in items]
        self._navigation_keys = [*self.keys, *(['__older_tasks__'] if older_count else [])]
        if selected in self._navigation_keys:
            self.cursor = self._navigation_keys.index(selected)
        tail_key, tail_width, body_width, suffix_key, lead_width, name_width = (
            task_row_widths(items, width)
        )
        self.cursor = min(getattr(self, 'cursor', 0), max(0, len(self._navigation_keys) - 1))
        for index, item in enumerate(items):
            card_start = len(text)
            key = item['key']
            display_state = item.get('display_state', item['state'])
            tone = task_state_tone(display_state)
            prefix = '▾ ' if key == expanded else '▸ '
            content = item.get('compact', item['text']) if body_width < 100 else item['text']
            name_range = None
            if 'row_name' in item:
                lead = Text(sanitize_terminal_text(item.get('row_lead', '')))
                name = Text(sanitize_terminal_text(item['row_name']))
                name.truncate(name_width, overflow='ellipsis')
                suffix = sanitize_terminal_text(item.get(suffix_key, ''))
                padded_lead = lead.plain + ' ' * (lead_width - lead.cell_len)
                content = (padded_lead + name.plain
                           + ' ' * (name_width - name.cell_len + 1) + suffix)
                name_start = len(prefix) + len(padded_lead)
                name_range = (name_start, name_start + len(name.plain))
            row = Text(
                prefix + sanitize_terminal_text(content),
                style=tone if name_range is None else '#9297A3',
            )
            row.stylize(tone, 0, len(prefix))
            if name_range is not None:
                row.stylize('#C5D1DF', len(prefix), name_range[0])
                row.stylize('bold #DADCE7', *name_range)
            row.truncate(body_width, overflow='ellipsis')
            tail = item.get(tail_key, item.get('progress_tail'))
            if tail:
                tail = Text(sanitize_terminal_text(tail), style='#9297A3')
                row.append(' ' * max(1, width - row.cell_len - tail_width))
                row.append_text(tail)
            if key == expanded:
                row.pad_right(max(0, width - row.cell_len))
            row.highlight_regex(r'Best \S+', style='bold #DADCE7')
            text.append_text(style_task_text(row, state=item['state']))
            cursor_spans.append((card_start, len(text)))
            text.append('\n')
            self.line_keys.append(key)
            if key == expanded:
                from .dashboard import aligned_summary
                text.append('│', style='#414956')
                text.append(' ' * max(0, width - 1) + '\n')
                self.line_keys.append(None)
                name = sanitize_terminal_text(
                    item.get('row_full_name', item.get('row_name', item['text']))
                )
                for name_row in Text(name, style='bold #DADCE7').wrap(Console(), max(1, width - 4)):
                    name_row.pad_right(max(0, width - 2 - name_row.cell_len))
                    text.append('│ ', style='#414956')
                    text.append_text(name_row)
                    text.append('\n')
                    self.line_keys.append(key)
                text.append('│', style='#414956')
                text.append(' ' * max(0, width - 1) + '\n')
                self.line_keys.append(None)
                details, _ = aligned_summary(item.get('detail', ''), max(1, width - 4))
                for detail in sanitize_terminal_text(details).splitlines():
                    match = re.match(r'\s*-\s*(\w+):', detail)
                    worker = match[1] if match and match[1] in item.get('worker_details', {}) else None
                    worker_expandable = bool(worker and item.get('worker_expandable', True))
                    if worker_expandable:
                        detail = detail.replace('- ', '▾ ' if expanded_worker == (key, worker) else '▸ ', 1)
                    detail_row = Text('│ ', style='#414956')
                    detail_row.append_text(
                        style_task_text(
                            Text(detail, style='#9297A3'),
                            state=item['state'],
                        )
                    )
                    detail_row.truncate(width, overflow='ellipsis')
                    detail_row.pad_right(max(0, width - detail_row.cell_len))
                    text.append_text(detail_row)
                    text.append('\n')
                    self.line_keys.append((key, worker) if worker_expandable else None if worker else key)
                    if worker_expandable and expanded_worker == (key, worker):
                        value = sanitize_terminal_text(item['worker_details'][worker])
                        for extra in Text(value, style='#C5D1DF').wrap(Console(), max(1, width - 6)):
                            text.append('│   ', style='#414956')
                            extra.pad_right(max(0, width - 4 - extra.cell_len))
                            text.append_text(extra)
                            text.append('\n')
                            self.line_keys.append((key, worker))
                text.stylize(f'on {SURFACE_COLOR}', card_start, len(text))
                if index < len(items) - 1:
                    text.append('\n')
                    self.line_keys.append(None)
        if older_count:
            self._append_older_hint(text, cursor_spans, width, older_count, older_expanded, older_label)
        if text.plain.endswith('\n'):
            text = text[:-1]
        self._base_text = text
        self._cursor_spans = cursor_spans
        self._paint_cursor()

    def _append_older_hint(self, text, cursor_spans, width, older_count, older_expanded, older_label):
        if text.plain and not text.plain.endswith('\n'):
            text.append('\n')
        label = '▴ Show Top 5' if older_expanded else f'▾ {older_count} {older_label}'
        hint = Text(label, style='#737C8A')
        hint.truncate(width, overflow='ellipsis')
        hint_start = len(text)
        text.append_text(hint)
        cursor_spans.append((hint_start, len(text)))
        self.line_keys.append('__older_tasks__')

    def _paint_cursor(self):
        if not hasattr(self, '_base_text'):
            return
        text = self._base_text.copy()
        if self.has_focus and self._cursor_spans:
            start, end = self._cursor_spans[self.cursor]
            text.stylize('bold underline', start, end)
        self.update(text)

    def on_focus(self):
        self._paint_cursor()

    def on_blur(self):
        self._paint_cursor()

    def _reveal_cursor(self):
        if not self._navigation_keys:
            return
        panel = self.app.query_one('#research-panel', VerticalScroll)
        line = self.line_keys.index(self._navigation_keys[self.cursor])
        height = max(1, panel.scrollable_content_region.height)
        if line < panel.scroll_y:
            panel.scroll_to(y=line, animate=False)
        elif line >= panel.scroll_y + height:
            panel.scroll_to(y=line - height + 1, animate=False)

    def on_click(self, event: events.Click):
        position = event.get_content_offset(self)
        if position is not None and 0 <= position.y < len(getattr(self, 'line_keys', ())):
            key = self.line_keys[position.y]
            if key is None:
                return
            if key == '__older_tasks__':
                self.cursor = self._navigation_keys.index(key)
                self._paint_cursor()
                self.post_message(self.OlderSelected())
                event.stop()
                return
            if isinstance(key, tuple):
                task, worker = key
                self.cursor = self.keys.index(task)
                self._paint_cursor()
                self.post_message(self.Selected(task, worker))
                event.stop()
                return
            self.cursor = self.keys.index(key)
            self._paint_cursor()
            self.post_message(self.Selected(key))
            event.stop()

    def action_previous(self):
        self.cursor = max(0, getattr(self, 'cursor', 0) - 1)
        self._paint_cursor()
        self._reveal_cursor()

    def action_next(self):
        self.cursor = min(max(0, len(getattr(self, '_navigation_keys', ())) - 1),
                          getattr(self, 'cursor', 0) + 1)
        self._paint_cursor()
        self._reveal_cursor()

    def action_select(self):
        if getattr(self, '_navigation_keys', ()):
            key = self._navigation_keys[self.cursor]
            self.post_message(self.OlderSelected() if key == '__older_tasks__'
                              else self.Selected(key))


