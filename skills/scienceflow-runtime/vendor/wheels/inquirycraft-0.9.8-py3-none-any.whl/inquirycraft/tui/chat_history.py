"""Session chat numbering and reversible, source-only round summaries."""

from rich.text import Text
from textual.containers import VerticalScroll

from .components import AssistantEntry, TranscriptEntry
from .controller import sanitize_terminal_text
from .internal_messages import is_internal_shell_message
from .shell_job_restore import restore_shell_job_entry
from .tool_card import ToolEntry
from .transcript_grouping import AssistantToolGroup
from .transcript_sections import TranscriptSection


def snippet(value: str) -> str:
    """Bound display text, never summarize through another model call."""
    return ' '.join(sanitize_terminal_text(value).split())[:160]


class ChatRoundSummary(TranscriptSection):
    """Two aligned rows controlling the original widgets, including tool groups."""

    def __init__(self, number: int, prompt: str) -> None:
        super().__init__()
        self.add_class('chat-round-summary')
        self.number = number
        self.prompt = snippet(prompt)
        self.answer = ''
        self.completed = False
        self.candidates = ()
        self.current = True
        self.expanded = True
        self.display = True
        self._refresh_summary()

    def _refresh_summary(self) -> None:
        text = Text(no_wrap=True, overflow='ellipsis')
        prefix = f"{'▾' if self.expanded else '▸'} #{self.number}  "
        prefix_style = 'bold underline #B8A4E3' if self._keyboard_focused else '#8FA9C4'
        self.styles.height = 1 if self.current else 2
        if self.current:
            text.append(prefix.rstrip(), style=prefix_style)
            self.update(text)
            return
        for index, (role, content, color) in enumerate((
            ('>', self.prompt, '#8FA9C4'),
            ('-', self.answer, '#B8A4E3'),
        )):
            if index:
                text.append('\n' + ' ' * len(prefix))
            else:
                text.append(prefix, style=prefix_style)
            text.append(f'{role} ', style=color)
            text.append(content, style='#9297A3')
        self.update(text)


class TuiChatHistory:
    """Number top-level chat requests independently of runtime tool iterations."""

    supports_host_history_restore = True

    async def _begin_chat_round(self, prompt: str, *, number: int | None = None) -> None:
        self._collapse_chat_history()
        if number is None:
            self._chat_round_count += 1
            number = self._chat_round_count
        section = ChatRoundSummary(number, prompt)
        await self.query_one('#transcript', VerticalScroll).mount(section)
        self._chat_rounds.append(section)
        from .chat_archive import update_archive

        await update_archive(self)

    def _collapse_chat_history(self) -> None:
        for section in self._chat_rounds:
            if section.is_attached and section.completed and section.current:
                section.current = False
                if section.expanded:
                    section._visibility = tuple(entry.display for entry in section.entries)
                    section.expanded = False
                    for entry in section.entries:
                        entry.display = False
                section._refresh_summary()

    def _finish_chat_round(self, *, settled: bool = False, outcome: str = '') -> None:
        if not self._chat_rounds:
            return
        section = self._chat_rounds[-1]
        if section.completed or not section.is_attached:
            return
        children = list(self.query_one('#transcript', VerticalScroll).children)
        entries = []
        for entry in children[children.index(section) + 1:]:
            # Notices are independent display events, not chat-round boundaries.
            # A queued steer or shell completion can arrive between tool and
            # answer entries without changing which user request owns them.
            if isinstance(entry, TranscriptEntry) and entry.role == 'notice':
                continue
            if not isinstance(entry, (AssistantEntry, ToolEntry, AssistantToolGroup, TranscriptEntry)):
                break
            if isinstance(entry, TranscriptEntry) and entry.role not in {'user', 'assistant'}:
                return
            if (isinstance(entry, TranscriptEntry) and entry.role == 'user'
                    and not getattr(entry, 'queued_input', False)
                    and (entries or entry.segment_count != 1)):
                return
            entries.append(entry)
        finals = [entry for entry in entries if isinstance(entry, AssistantEntry)
                  and not entry.tool_call_count and entry.content_text.strip()]
        tools = [entry for entry in entries if isinstance(entry, ToolEntry)]
        if any(tool.state in {'requested', 'running'} for tool in tools):
            return
        if finals or (settled and (tools or outcome)):
            summary = outcome or (finals[-1].content_text if finals else
                                  f'{tools[-1].tool_name} · {tools[-1].state}')
            section.answer = snippet(summary)
            section.candidates = tuple(entries)
            section.completed = True
            section.entries = section.candidates
            section._visibility = tuple(entry.display for entry in entries)
            section._refresh_summary()

    async def _restore_transcript(self) -> None:
        conversation = getattr(self.runtime, 'conversation', None)
        messages = tuple(getattr(conversation, 'messages', ()))
        history_before = getattr(self.interceptor, 'history_before', None)

        async def restore_host_at(index: int) -> None:
            if not callable(history_before):
                return
            for summary in history_before(index):
                self._finish_chat_round()
                section = await self.begin_transcript_section()
                await self.notice(summary)
                await self.fold_transcript_section(section, summary)

        classifier = getattr(self.interceptor, 'is_host_task_prompt', None)
        # Consecutive inputs before one response may be queued steering. A
        # user-only saved transcript still represents distinct open rounds.
        followed_by_output = [False] * len(messages)
        next_role = ''
        for index in range(len(messages) - 1, -1, -1):
            role = str(getattr(messages[index], 'role', ''))
            if role == 'user':
                followed_by_output[index] = next_role in {'assistant', 'tool'}
            else:
                next_role = role
        numbered = []
        previous_role = ''
        for index, message in enumerate(messages):
            content = getattr(message, 'content', '')
            role = str(getattr(message, 'role', ''))
            is_user = role == 'user'
            is_host = is_user and callable(classifier) and classifier(content)
            internal = is_user and is_internal_shell_message(content)
            queued = (is_user and not is_host and not internal and previous_role == 'user'
                      and followed_by_output[index])
            if is_user and not is_host and not internal and not queued:
                self._chat_round_count += 1
            numbered.append((message, self._chat_round_count, is_host, queued))
            if not internal:
                previous_role = 'host' if is_host else role
        for index, (message, number, is_host, queued) in enumerate(numbered):
            await restore_host_at(index)
            role = str(getattr(message, 'role', ''))
            content = getattr(message, 'content', '')
            if role == 'user':
                if is_internal_shell_message(content):
                    continue
                if queued:
                    entry = TranscriptEntry('user', content)
                    entry.queued_input = True
                    await self._mount_entry(entry, merge_with_previous=False)
                    continue
                self._finish_chat_round(settled=True)
                if is_host:
                    await self.begin_transcript_section()
                elif isinstance(content, str):
                    await self._begin_chat_round(content, number=number)
                if isinstance(content, str):
                    await self._mount_entry(TranscriptEntry('user', content))
            elif role == 'assistant':
                await self._restore_assistant(message)
            elif role == 'tool' and isinstance(content, str):
                entry = ToolEntry(str(getattr(message, 'name', 'tool')),
                                  arguments=self.tool_arguments(getattr(message, 'tool_call_id', None)))
                entry.expanded = self._tool_details
                state = self._restored_tool_state(message, content)
                if not restore_shell_job_entry(self, entry, content):
                    entry.update_tool(state=state, preview=content, restored=True)
                await self._mount_entry(entry)
                self._all_tool_entries.append(entry)
        self._finish_chat_round(settled=True)
        await restore_host_at(len(messages))
        # Restored rounds are history, including the most recent completed round.
        # Live submissions still begin expanded through _begin_chat_round.
        self._collapse_chat_history()
        from .chat_archive import update_archive

        await update_archive(self)

    def _restored_tool_state(self, message, content: str) -> str:
        journal = getattr(self.runtime, 'operation_journal', None)
        call_id = getattr(message, 'tool_call_id', None)
        row = journal.latest('tool', f'tool:{call_id}') if journal and call_id else None
        if row and row.get('phase') == 'settled':
            return 'failed' if (row.get('payload') or {}).get('is_error') else 'completed'
        # Legacy transcripts have no settlement journal; only explicit errors are known.
        return 'failed' if content.startswith('Error: ') else 'unknown'

    async def _restore_assistant(self, message) -> None:
        content = getattr(message, 'content', '')
        reasoning = getattr(message, 'reasoning_content', None)
        calls = getattr(message, 'tool_calls', None) or ()
        if not isinstance(content, str) and not calls and not reasoning:
            return
        entry = AssistantEntry(markdown=self.markdown)
        entry.set_content(content if isinstance(content, str) else '')
        if isinstance(reasoning, str):
            entry.append_reasoning(reasoning)
        entry.tool_call_count = len(calls)
        mounted = await self._mount_entry(entry)
        if isinstance(mounted, AssistantEntry) and mounted not in self._assistant_entries:
            self._assistant_entries.append(mounted)
        if mounted is entry and not calls:
            await self._fold_preceding_tool_sequence(entry)
