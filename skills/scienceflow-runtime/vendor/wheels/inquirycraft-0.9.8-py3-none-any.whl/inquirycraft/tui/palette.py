"""Shared surface color for CSS widgets and Rich-rendered task cards."""

SURFACE_COLOR = "#3B4048"
