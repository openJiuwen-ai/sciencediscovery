"""Readable tool observations; raw output stays available without changing events."""

import ast
import json
from time import monotonic

from rich.console import Group
from rich.syntax import Syntax
from rich.text import Text
from textual import events
from textual.widgets import Static

from .controller import sanitize_terminal_text
from .syntax_theme import TRANSPARENT_CODE_THEME

_TOOL_LABELS = {
    'bash': 'Bash',
    'shell': 'Bash',
    'read': 'Read',
    'read_file': 'Read',
    'read_text': 'Read',
    'write': 'Write',
    'write_file': 'Write',
    'write_text': 'Write',
    'grep': 'Search',
    'search': 'Search',
    'glob': 'Files',
    'list': 'Files',
    'list_dir': 'Files',
}
_RESULT_KEY_ORDER = ('error', 'stderr', 'stdout', 'output', 'result', 'exit_code')
_SHELL_PROGRESS_RENDER_INTERVAL_SEC = 0.1


def _clock(seconds: float) -> str:
    total = max(0, int(seconds))
    hours, remainder = divmod(total, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f'{hours:d}:{minutes:02d}:{seconds:02d}' if hours else f'{minutes:02d}:{seconds:02d}'


def _tool_label(name: str) -> str:
    return _TOOL_LABELS.get(name.casefold(), name.replace('_', ' ').title())


def _result_items(value: dict):
    priority = {key: index for index, key in enumerate(_RESULT_KEY_ORDER)}
    return sorted(value.items(), key=lambda item: (priority.get(str(item[0]), 99), str(item[0])))


def _labelled_result(key, item) -> list[str]:
    if item in (None, '', [], {}):
        return []
    label = {
        'error': 'Error',
        'stderr': 'Stderr',
        'stdout': 'Output',
        'output': 'Output',
        'result': 'Result',
        'exit_code': 'Exit',
    }.get(str(key), str(key).replace('_', ' ').title())
    if isinstance(item, (dict, list)):
        rendered = readable_result(json.dumps(item, ensure_ascii=False))
    else:
        rendered = str(item)
    lines = rendered.splitlines() or ['']
    return [f'{label} · {lines[0]}', *(f'  {line}' for line in lines[1:])]


def readable_result(raw):
    """Turn structured observations into short, priority-ordered labelled lines."""
    value = raw
    try:
        value = json.loads(raw)
    except (ValueError, TypeError):
        if raw.startswith(('{', '[')):
            try:
                value = ast.literal_eval(raw)
            except (ValueError, SyntaxError, RecursionError):
                return "Structured preview is incomplete; Ctrl+click to inspect the original output."
    if isinstance(value, dict):
        return '\n'.join(
            line
            for key, item in _result_items(value)
            for line in _labelled_result(key, item)
        )
    if isinstance(value, list):
        return '\n'.join('• ' + readable_result(json.dumps(item, ensure_ascii=False))
                         if isinstance(item, (dict, list)) else '• ' + str(item) for item in value)
    return str(value)


class ToolEntry(Static):
    """One compact card across request, progress and completion."""

    def __init__(self, name, *, arguments=None, default_timeout_sec=None):
        self.tool_name = sanitize_terminal_text(name)
        self.arguments = arguments if isinstance(arguments, dict) else {}
        self.default_timeout_sec = default_timeout_sec
        self.state = 'requested'
        self.preview = ''
        self.expanded = False
        self.raw = False
        self.started = monotonic()
        self.last_output_at = self.started
        self._last_live_second = -1
        self._last_progress_render_at = None
        self._progress_dirty = False
        self.elapsed = None
        super().__init__('', classes='transcript-entry tool', markup=False)
        self._refresh_content()

    def update_tool(self, *, state, preview=None, restored=False, output_received=False):
        if state == 'running' and self.state != 'running':
            self.started = monotonic()
            self.last_output_at = self.started
        self.state = state
        if not restored and state in {'completed', 'failed', 'cancelled'} and self.elapsed is None:
            self.elapsed = monotonic() - self.started
        if preview is not None:
            self.preview = sanitize_terminal_text(preview)
        if output_received:
            self.last_output_at = monotonic()
        if state in {'completed', 'failed', 'cancelled'}:
            self._progress_dirty = False
        self._refresh_content()

    def append_shell_progress(self, chunk: str) -> bool:
        """Keep every preview chunk while limiting expensive card renders."""
        if self.state != 'running':
            self.update_tool(state='running')
        now = monotonic()
        clean = sanitize_terminal_text(chunk)
        was_quiet = bool(clean) and now - self.last_output_at >= 15
        self.preview = (self.preview + clean)[-4000:]
        if clean:
            self.last_output_at = now
        if (was_quiet or self._last_progress_render_at is None
                or now - self._last_progress_render_at >= _SHELL_PROGRESS_RENDER_INTERVAL_SEC):
            self._last_progress_render_at = now
            self._last_live_second = int(now - self.started)
            self._progress_dirty = False
            self._refresh_content()
            return True
        self._progress_dirty = True
        return False

    def refresh_running_status(self):
        """Refresh only the visible clock; no synthetic tool output is emitted."""
        if self.state != 'running' or self.tool_name.casefold() not in {'shell', 'bash'}:
            return False
        second = int(monotonic() - self.started)
        if self._progress_dirty or second != self._last_live_second:
            self._last_live_second = second
            self._last_progress_render_at = monotonic()
            self._progress_dirty = False
            self._refresh_content()
            return True
        return False

    def toggle_details(self):
        self.expanded = not self.expanded
        self._refresh_content()

    def on_click(self, event: events.Click):
        transcript = self.parent
        if hasattr(transcript, 'pause_follow'):
            transcript.pause_follow()
        if event.ctrl:
            self.raw = not self.raw
            self.expanded = True
        else:
            self.toggle_details()
        self._refresh_content()
        event.stop()

    def _refresh_content(self):
        symbol = {'completed': '✓', 'failed': '×', 'running': '●'}.get(self.state, '○')
        tone = (
            '#E99AA3'
            if self.state == 'failed'
            else '#8FA9C4'
            if self.state == 'running'
            else '#9297A3'
        )
        hint = next((str(self.arguments[k]) for k in ('path', 'file_path', 'command', 'pattern')
                     if k in self.arguments), '')
        label = _tool_label(self.tool_name)
        title = Text(no_wrap=True, overflow='ellipsis')
        title.append(symbol, style=tone)
        title.append(f' {label}', style='bold #C5D1DF')
        state_label = {'requested': 'queued', 'running': 'running', 'failed': 'failed',
                       'unknown': 'unknown', 'cancelled': 'cancelled', 'background': 'background'}.get(self.state)
        if state_label:
            title.append(f' · {state_label}', style=tone)
        if self.state == 'running' and self.tool_name.casefold() in {'shell', 'bash'}:
            now = monotonic()
            timeout = self.arguments.get('timeout', self.default_timeout_sec)
            budget = f'/{_clock(float(timeout))}' if isinstance(timeout, (int, float)) and timeout > 0 else ''
            title.append(f' · {_clock(now - self.started)}{budget}', style='#C5D1DF')
            quiet = now - self.last_output_at
            if quiet >= 15:
                title.append(f' · no output {_clock(quiet)}', style='#D8BE91')
        if hint:
            compact_hint = sanitize_terminal_text(hint).replace('\n', ' ')[:120]
            title.append(f' · {compact_hint}', style='#9297A3')
        if self.elapsed is not None:
            duration = '<0.1s' if self.elapsed < 0.05 else f'{self.elapsed:.1f}s'
            title.append(f' · {duration}', style='#9297A3')
        body = self.preview if self.raw else readable_result(self.preview)
        lines = body.splitlines()
        limit = 3
        hidden = max(0, len(lines) - limit)
        if not self.expanded:
            lines = [line[:180] + ('…' if len(line) > 180 else '') for line in lines[:limit]]
        parts = [title]
        if lines:
            text = '\n'.join(lines)
            if self.raw:
                parts.append(Syntax(text, 'json', theme=TRANSPARENT_CODE_THEME, word_wrap=True))
            elif self.tool_name in {'read_text', 'read_file'} and not self.preview.startswith(('{', '[')):
                from pathlib import Path
                language = {'.py': 'python', '.sh': 'bash', '.yaml': 'yaml', '.md': 'markdown'}.get(Path(hint).suffix, 'text')
                parts.append(Syntax(text, language, theme=TRANSPARENT_CODE_THEME, word_wrap=True))
            else:
                indented = '\n'.join(f'  {line}' for line in lines)
                parts.append(Text(indented, style='#DADCE7', no_wrap=not self.expanded, overflow='ellipsis'))
            if self.expanded:
                footer = Text('Click to collapse', style='#70757D')
                footer.append(
                    ' · Ctrl+click: ' + ('formatted' if self.raw else 'raw'),
                    style='#70757D',
                )
                parts.append(footer)
            elif hidden:
                parts.append(Text(f'+{hidden} lines · click to expand', style='#70757D'))
        self.update(Group(*parts))
