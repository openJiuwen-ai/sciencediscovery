"""Generic expandable host rows; task semantics stay in the embedding application."""


from textual.containers import VerticalScroll
from textual.widgets import Button, Static

from .task_presentation import (
    ACTIVE_TASK_STATES,
    TaskPulse,
)
from .task_rows import HostTaskRows
from .task_widgets import TaskPanel as TaskPanel
from .task_widgets import TaskToggle as TaskToggle


class TuiTaskDashboard(TaskPulse):
    TASK_PREVIEW_LIMIT = 5
    COMPACT_TASK_PREVIEW_LIMIT = 2
    COMPACT_TASK_HEIGHT = 36

    def _sync_task_panel_height(self):
        """Start folded; only an explicit user action changes visibility."""
        if not getattr(self, '_panel_user_override', False):
            self._panel_collapsed = True

    def _visible_host_items(self, items):
        if getattr(self, '_tasks_show_all', False):
            return items
        if (getattr(self, '_panel_user_override', False)
                or self.size.height >= self.COMPACT_TASK_HEIGHT):
            return items[:self.TASK_PREVIEW_LIMIT]
        active = [item for item in items if item.get('state') in ACTIVE_TASK_STATES]
        selected = active[:self.COMPACT_TASK_PREVIEW_LIMIT]
        selected_keys = {item['key'] for item in selected}
        for item in items:
            if len(selected) >= self.COMPACT_TASK_PREVIEW_LIMIT:
                break
            if item['key'] not in selected_keys:
                selected.append(item)
        return tuple(selected)

    def _host_task_presentation(self, title, items):
        """Keep hidden task timing changes from repainting a collapsed panel."""
        collapsed = getattr(self, '_panel_collapsed', False)
        visible = self._visible_host_items(items)
        content = (
            tuple((item.get('key'), item.get('state'), item.get('display_state')) for item in visible)
            if collapsed else visible
        )
        return (
            title,
            content,
            collapsed,
            getattr(self, '_expanded_host_task', None),
            getattr(self, '_expanded_host_worker', None),
            self.size.width,
            self.size.height,
        )

    def set_host_tasks(self, title: str, items: tuple[dict, ...]) -> None:
        """Optional host API; keys must remain stable across updates and sorting."""
        self._host_tasks = (title, items)
        self._set_task_pulse(any(item.get('state') in ACTIVE_TASK_STATES for item in items))
        self._sync_task_panel_height()
        presentation = self._host_task_presentation(title, items)
        if presentation == getattr(self, '_last_host_task_presentation', None):
            return
        panel = self.query_one('#research-panel', VerticalScroll)
        rows = self.query_one('#research-workers', HostTaskRows)
        collapsed = getattr(self, '_panel_collapsed', False)
        position = getattr(self, '_tasks_scroll_y', 0) if collapsed else panel.scroll_y
        old_lines = getattr(rows, 'line_keys', [])
        anchor = None
        if position > 0:
            start = max(0, int(position) - 1)
            for line in range(min(start, len(old_lines)), len(old_lines)):
                key = old_lines[line]
                if key is not None:
                    anchor = (key, line - old_lines.index(key), position - line)
                    break
        self._render_host_tasks()
        if anchor is not None and anchor[0] in rows.line_keys:
            key, occurrence, offset = anchor
            target = max(0, rows.line_keys.index(key) + occurrence + offset)
            if collapsed:
                self._tasks_scroll_y = target
            elif target != position:
                self.call_after_refresh(self._restore_task_anchor, position, target)

    def _restore_task_anchor(self, previous, target):
        panel = self.query_one('#research-panel', VerticalScroll)
        # A user scroll made after the update takes precedence.
        if not getattr(self, '_panel_collapsed', False) and panel.scroll_y == previous:
            panel.scroll_to(y=target, animate=False, immediate=True, force=True)

    def expand_host_task(self, key: str):
        if getattr(self, '_host_tasks', None) is None:
            return
        items = self._host_tasks[1]
        index = next((i for i, item in enumerate(items) if item['key'] == key), None)
        if index is not None:
            self._panel_user_override = True
            if index >= self.TASK_PREVIEW_LIMIT:
                self._tasks_show_all = True
            self._expanded_host_task = key
            self._panel_collapsed = False
            self._render_host_tasks()
            self.call_after_refresh(self._reveal_host_task, key)

    def _reveal_host_task(self, key):
        panel = self.query_one('#research-panel', VerticalScroll)
        rows = self.query_one('#research-workers', HostTaskRows)
        if (key not in rows.line_keys or getattr(self, '_panel_collapsed', False)
                or key != getattr(self, '_expanded_host_task', None)):
            return
        line = rows.line_keys.index(key)
        visible = max(1, panel.scrollable_content_region.height - 1)
        if line < panel.scroll_y:
            panel.scroll_to(y=line, animate=False, immediate=True, force=True)
        elif line + 3 > panel.scroll_y + visible:
            panel.scroll_to(y=max(0, line + 3 - visible), animate=False, immediate=True, force=True)

    def _render_host_tasks(self):
        title, items = self._host_tasks
        self._sync_task_panel_height()
        collapsed = getattr(self, '_panel_collapsed', False)
        show_all = getattr(self, '_tasks_show_all', False)
        visible_items = self._visible_host_items(items)
        older_count = len(items) - len(visible_items)
        if show_all:
            older_count = max(0, len(items) - self.TASK_PREVIEW_LIMIT)
        panel = self.query_one('#research-panel', VerticalScroll)
        panel.add_class('task-list')
        was_collapsed = getattr(self, '_tasks_were_collapsed', False)
        if collapsed and not was_collapsed:
            self._tasks_scroll_y = panel.scroll_y
        self._tasks_were_collapsed = collapsed
        panel.display = bool(items)
        panel.set_class(collapsed, 'collapsed')
        panel.styles.height = 1 if collapsed else 'auto'
        if collapsed:
            panel.styles.max_height = 1
        elif self.size.height < 28:
            panel.styles.max_height = 9 if getattr(self, '_expanded_host_task', None) else 6
        else:
            panel.styles.max_height = max(7, min(16, self.size.height // 3))
        self._refresh_task_heading()
        self.query_one('#research-filter', Button).display = False
        self.query_one('#research-page', Static).display = False
        for name in ('prev', 'next'):
            self.query_one('#research-' + name, Button).display = False
        self.query_one('#research-summary', Static).display = False
        widget = self.query_one('#research-workers', HostTaskRows)
        widget.display = not collapsed
        available = min(self.size.width - 6, widget.content_region.width or self.size.width - 6)
        widget.show_items(visible_items, getattr(self, '_expanded_host_task', None), width=available,
                          expanded_worker=getattr(self, '_expanded_host_worker', None),
                          older_count=older_count, older_expanded=show_all,
                          older_label=('more tasks' if len(visible_items) < self.TASK_PREVIEW_LIMIT
                                       else 'older tasks'))
        self._last_host_task_presentation = self._host_task_presentation(title, items)
        if was_collapsed and not collapsed:
            self.call_after_refresh(panel.scroll_to, y=getattr(self, '_tasks_scroll_y', 0),
                                    animate=False, immediate=True, force=True)

    def toggle_host_task_list(self):
        """Expand older tasks or return to the five newest task rows."""
        if getattr(self, '_host_tasks', None) is None:
            return
        items = self._host_tasks[1]
        self._panel_user_override = True
        self._tasks_show_all = not getattr(self, '_tasks_show_all', False)
        if not self._tasks_show_all:
            visible = {item['key'] for item in items[:self.TASK_PREVIEW_LIMIT]}
            if getattr(self, '_expanded_host_task', None) not in visible:
                self._expanded_host_task = None
                self._expanded_host_worker = None
        self._render_host_tasks()
        panel = self.query_one('#research-panel', VerticalScroll)
        self.call_after_refresh(
            panel.scroll_home, animate=False, immediate=True, force=True
        )

    def on_host_task_rows_older_selected(self, event: HostTaskRows.OlderSelected):
        self.toggle_host_task_list()
        event.stop()

    def on_host_task_rows_selected(self, event: HostTaskRows.Selected):
        if getattr(self, '_host_tasks', None) is None:
            return
        self._panel_user_override = True
        if event.worker:
            target = (event.key, event.worker)
            self._expanded_host_worker = None if getattr(self, '_expanded_host_worker', None) == target else target
            self._render_host_tasks()
            event.stop()
            return
        self._expanded_host_task = None if getattr(self, '_expanded_host_task', None) == event.key else event.key
        self._render_host_tasks()
        if self._expanded_host_task is not None:
            self.call_after_refresh(self._reveal_host_task, event.key)
        event.stop()
