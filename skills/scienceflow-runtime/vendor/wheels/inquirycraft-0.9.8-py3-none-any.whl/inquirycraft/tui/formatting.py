"""Compact terminal durations; formatting never owns lifecycle state."""


def duration(seconds: float, *, relative: bool = False) -> str:
    seconds = max(0, int(seconds))
    if relative:
        return f'{seconds}s' if seconds < 60 else (f'{seconds // 60}m' if seconds < 3600 else f'{seconds / 3600:.1f}h')
    hours, remainder = divmod(seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    if hours:
        return f'{hours}h {minutes:02d}m'
    return f'{minutes}m {seconds:02d}s' if minutes else f'{seconds}s'


def style_progress(text):
    """Accent host-provided control groups without introducing backgrounds."""
    text.highlight_regex(r'(?m)^Time[^\n]*', style='bold #B8D7E8')
    text.highlight_regex(r'(?m)^Total[^\n]*', style='bold #DADCE7')
    text.highlight_regex(r'(?m)^Result[^\n]*', style='bold #DADCE7')
    text.highlight_regex(r'\bBest\s+[^·\n]+', style='bold #DADCE7')
    text.highlight_regex(r'(?m)^Usage[^\n]*', style='#C5D1DF')
    text.highlight_regex(r'ESTRA(?: [0-9—/]+)?', style='bold #B8A4E3')
    text.highlight_regex(r'(?m)^ESTRA[^\n]*', style='#B8A4E3')
    text.highlight_regex(r'(?m)^ESTRA', style='bold #B8A4E3')
    text.highlight_regex(r'\bEEC(?: [0-9—]+)?', style='bold #8FA9C4')
    text.highlight_regex(r'\b(?:Disk|Storage)\s+(?:~?[0-9.]+[MG]|—)', style='#C5D1DF')
    text.highlight_regex(r'Cost ~?\$[0-9.,]+(?: \(partial\))?', style='#D8BE91')
    text.highlight_regex(r'(?<!\w)~?\$[0-9.,]+[KMBT]?', style='#D8BE91')
    return text
