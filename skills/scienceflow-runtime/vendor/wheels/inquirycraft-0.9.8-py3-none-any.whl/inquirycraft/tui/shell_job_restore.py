"""Reconcile saved shell tool cards with durable job outcomes."""

import re

_BACKGROUND_JOB = re.compile(r"^Shell job #(\d+) is still running in the background\b")


def restore_shell_job_entry(app, entry, content):
    match = _BACKGROUND_JOB.match(content)
    manager = getattr(app, "_shell_jobs", None)
    if match is None or manager is None:
        return False
    number = int(match.group(1))
    row = next((row for row in manager.previous if row["number"] == number), None)
    if row is None or row["status"] not in {"done", "failed", "interrupted"}:
        return False
    state = "completed" if row["status"] == "done" else "failed"
    preview = str(row.get("result") or f"Job #{number} {row['status']}; log: {row.get('log', '')}")
    entry.update_tool(state=state, preview=preview, restored=True)
    return True
