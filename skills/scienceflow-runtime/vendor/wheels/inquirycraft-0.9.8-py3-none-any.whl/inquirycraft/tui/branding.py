"""InquiryCraft-owned terminal branding."""

from __future__ import annotations

from dataclasses import dataclass

INQUIRYCRAFT_WORDMARK = "InquiryCraft"
INQUIRYCRAFT_MONOGRAM = "IQ"
TRANSPARENT_PIXEL = "transparent"

INQUIRYCRAFT_LOGO = """╭────╮
│ IQ │  InquiryCraft
╰────╯  Agent Runtime"""

INQUIRYCRAFT_COMPACT_LOGO = "IQ · InquiryCraft"
INQUIRYCRAFT_WELCOME = (
    "Ready. Enter sends; Alt+Enter inserts a new line. "
    "While running, ordinary submissions steer the active run."
)



@dataclass(frozen=True)
class TuiBranding:
    """Application identity supplied by a host; pixel grids accept ``transparent``."""

    large_title: bool = False
    accent_text: str = ""
    accent_color: str = "#83ded1"
    hide_compact_subtitle: bool = False
    pixels: tuple[tuple[str, ...], ...] = ()
    compact_pixels: tuple[tuple[str, ...], ...] = ()
    name: str = "InquiryCraft"
    subtitle: str = "Agent Runtime"
    logo: str = INQUIRYCRAFT_LOGO
    compact_logo: str = INQUIRYCRAFT_COMPACT_LOGO
    notice_label: str = "IQCRAFT"
    large_subtitle: bool = False
    organization_name: str = ""
    lab_name: str = ""
    team_name: str = ""
    version: str = ""
    welcome_text: str = INQUIRYCRAFT_WELCOME
    welcome_emphasis: tuple[str, ...] = ()
    prompt_placeholder: str = "/help"
    notice_background: str = ""
    fold_system_notices: bool = False
