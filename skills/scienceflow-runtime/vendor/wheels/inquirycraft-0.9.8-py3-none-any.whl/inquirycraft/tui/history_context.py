"""Mark notices emitted directly by a slash-command submission."""

import asyncio
from contextvars import ContextVar

HISTORY_COMMAND: ContextVar[asyncio.Task | None] = ContextVar("tui_history_command", default=None)


def exclude_from_history() -> bool:
    """Inherited child tasks must not inherit the command's display policy."""
    return HISTORY_COMMAND.get() is asyncio.current_task()
