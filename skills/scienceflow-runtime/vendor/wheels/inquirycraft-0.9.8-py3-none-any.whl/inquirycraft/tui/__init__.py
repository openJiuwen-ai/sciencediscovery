"""Optional full-screen terminal host for InquiryCraft."""

from typing import TYPE_CHECKING, Any

from .branding import (
    INQUIRYCRAFT_COMPACT_LOGO,
    INQUIRYCRAFT_LOGO,
    TRANSPARENT_PIXEL,
    TuiBranding,
)
from .contracts import (
    DelegatingTuiInterceptor,
    TuiCommandProvider,
    TuiCommandSpec,
    TuiCompletionProvider,
    TuiHistoryClassifier,
    TuiHostPort,
    TuiInputInterceptor,
    TuiInputPreprocessor,
    TuiInterceptorFactory,
    TuiModelRegistryHook,
    TuiMountHook,
    TuiPreparationPort,
    TuiTranscriptSectionPort,
)
from .controller import TuiSubmission, parse_submission, sanitize_terminal_text

if TYPE_CHECKING:
    from .app import InquiryCraftTui
    from .chat_model_picker import ChatModelPicker

__all__ = [
    "INQUIRYCRAFT_COMPACT_LOGO",
    "INQUIRYCRAFT_LOGO",
    "TRANSPARENT_PIXEL",
    "InquiryCraftTui",
    "ChatModelPicker",
    "TuiSubmission",
    "DelegatingTuiInterceptor",
    "TuiCommandProvider",
    "TuiCompletionProvider",
    "TuiHistoryClassifier",
    "TuiHostPort",
    "TuiPreparationPort",
    "TuiTranscriptSectionPort",
    "TuiCommandSpec",
    "TuiBranding",
    "TuiInputInterceptor",
    "TuiInputPreprocessor",
    "TuiInterceptorFactory",
    "TuiModelRegistryHook",
    "TuiMountHook",
    "parse_submission",
    "sanitize_terminal_text",
]


def __getattr__(name: str) -> Any:
    if name == 'ChatModelPicker':
        from .chat_model_picker import ChatModelPicker

        return ChatModelPicker
    if name == "InquiryCraftTui":
        from .app import InquiryCraftTui

        return InquiryCraftTui
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
