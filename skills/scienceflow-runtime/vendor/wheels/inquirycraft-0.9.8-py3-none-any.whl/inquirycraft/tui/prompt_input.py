"""TUI input editing, completion and submission history."""

from textual import events
from textual.binding import Binding
from textual.widgets import TextArea


class PromptInput(TextArea):
    """Chat composer with explicit multiline insertion and safe paste handling."""

    BINDINGS = [
        Binding("enter", "app.submit_prompt", "Send", priority=True),
        Binding("tab", "complete_command", "Complete", priority=True),
        Binding("up", "completion_up", show=False, priority=True),
        Binding("down", "completion_down", show=False, priority=True),
        Binding("shift+up", "previous_card", show=False, priority=True),
        Binding("alt+enter", "newline", "New line", priority=True),
        Binding("shift+enter", "newline", "New line", priority=True),
    ]

    def action_complete_command(self):
        if not self.app.complete_prompt():
            self.screen.focus_next()

    def action_completion_up(self):
        if not self.app.select_completion(-1) and not self.recall_submission(-1):
            self.action_cursor_up()

    def action_completion_down(self):
        if not self.app.select_completion(1) and not self.recall_submission(1):
            self.action_cursor_down()

    def action_previous_card(self):
        if self.cursor_location[0] != 0:
            self.action_cursor_up(True)
        elif not self.app.action_focus_previous_card():
            self.app.notify('No task or chat history cards in this view.', title='Cards', timeout=2)

    def remember_submission(self, text: str) -> None:
        history = getattr(self, '_sent_history', [])
        if not history or history[-1] != text:
            history.append(text)
        self._sent_history = history[-200:]
        self._history_index = None
        self._history_draft = ''

    def recall_submission(self, direction: int) -> bool:
        history = getattr(self, '_sent_history', [])
        if not history:
            return False
        index = getattr(self, '_history_index', None)
        if index is not None and self.text != getattr(self, '_history_view', ''):
            self._history_index = index = None
        if index is None:
            # Multiline drafts retain normal cursor movement away from the first line.
            if direction > 0 or self.cursor_location[0] != 0:
                return False
            self._history_draft = self.text
            index = len(history)
        target = max(0, min(len(history), index + direction))
        text = history[target] if target < len(history) else self._history_draft
        self._history_index = target if target < len(history) else None
        self._history_view = text
        self.load_text(text)
        lines = text.split('\n')
        self.move_cursor((len(lines) - 1, len(lines[-1])))
        return True

    def on_paste(self, event: events.Paste) -> None:
        # TextArea inserts the text; keep it from bubbling back to the screen.
        event.stop()

    def action_newline(self) -> None:
        if not self.read_only:
            self.replace("\n", *self.selection, maintain_selection_offset=False)
