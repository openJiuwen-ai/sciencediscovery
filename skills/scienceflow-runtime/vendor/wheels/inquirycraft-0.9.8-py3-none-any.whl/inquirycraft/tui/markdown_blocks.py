"""Markdown block presentation without interactive controls."""

from rich.markdown import BlockQuote
from rich.segment import Segment


class BorderlessBlockQuote(BlockQuote):
    """Keep quote indentation and styling without the decorative vertical bar."""

    def __rich_console__(self, console, options):
        lines = console.render_lines(
            self.elements, options.update(width=max(1, options.max_width - 4)), style=self.style
        )
        for line in lines:
            yield Segment("  ", self.style)
            yield from line
            yield Segment.line()
