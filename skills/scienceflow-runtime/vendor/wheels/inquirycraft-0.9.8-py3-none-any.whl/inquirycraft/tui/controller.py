"""Dependency-light command parsing and display sanitization for the TUI host."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal

TuiAction = Literal[
    "cancel",
    "clear",
    "empty",
    "follow_up",
    "help",
    "next_run",
    "run",
    "status",
    "steer",
]

_ANSI_ESCAPE = re.compile(r"\x1b(?:\][^\x07]*(?:\x07|\x1b\\)|\[[0-?]*[ -/]*[@-~]|[@-_])")
_CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1a\x1c-\x1f\x7f]")


@dataclass(frozen=True, slots=True)
class TuiSubmission:
    action: TuiAction
    content: str = ""
    command: str = ""


def parse_submission(text: str, *, busy: bool) -> TuiSubmission:
    """Map editor input to one explicit runtime or host action."""

    content = text.strip()
    if not content:
        return TuiSubmission("empty")
    if not content.startswith("/"):
        return TuiSubmission("steer" if busy else "run", content)

    command, _, argument = content[1:].partition(" ")
    command = command.strip().lower().replace("-", "_")
    argument = argument.strip()
    aliases = {
        "followup": "follow_up",
        "follow": "follow_up",
        "next": "next_run",
    }
    command = aliases.get(command, command)
    no_argument: dict[str, TuiAction] = {
        "cancel": "cancel",
        "clear": "clear",
        "help": "help",
        "status": "status",
    }
    if command in no_argument:
        return TuiSubmission(no_argument[command], command=command)
    queued: dict[str, TuiAction] = {
        "follow_up": "follow_up",
        "next_run": "next_run",
        "steer": "steer",
    }
    if command in queued:
        return TuiSubmission(queued[command], argument, command)
    if command == "run":
        return TuiSubmission("run", argument, command)
    # A leading slash can also be ordinary text (for example, a file path).
    return TuiSubmission("steer" if busy else "run", content)


def sanitize_terminal_text(value: object) -> str:
    """Remove terminal control sequences while retaining readable line structure."""

    text = _ANSI_ESCAPE.sub("", str(value))
    return _CONTROL.sub("", text).replace("\r\n", "\n").replace("\r", "\n")


def submission_preview(value: object, *, limit: int = 48) -> str:
    """Return a compact, single-line prefix for queued-message feedback."""

    text = " ".join(sanitize_terminal_text(value).split())
    if len(text) <= limit:
        return text
    return text[: max(1, limit - 1)].rstrip() + "…"
