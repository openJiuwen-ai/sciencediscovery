"""Keyboard navigation across task cards and folded chat rounds."""

from textual.containers import VerticalScroll

from .chat_history import ChatRoundSummary
from .task_panel import HostTaskRows, TaskToggle
from .transcript_sections import TranscriptSection


class TuiCardNavigation:
    def _card_has_focus(self) -> bool:
        return isinstance(
            self.screen.focused,
            (
                TaskToggle,
                HostTaskRows,
                TranscriptSection,
            ),
        )

    def _card_targets(self):
        targets = []
        panel = self.query_one("#research-panel", VerticalScroll)
        if panel.display:
            toggle = self.query_one("#research-toggle", TaskToggle)
            targets.append(toggle)
            rows = self.query_one("#research-workers", HostTaskRows)
            if rows.display and getattr(rows, "_navigation_keys", ()):
                targets.append(rows)
        transcript = self.query_one("#transcript", VerticalScroll)
        targets.extend(
            entry
            for entry in transcript.children
            if entry.display
            and isinstance(entry, TranscriptSection)
            and not (isinstance(entry, ChatRoundSummary) and entry.current)
        )
        return targets

    def _move_card(self, step: int) -> bool:
        targets = self._card_targets()
        if not targets:
            return False
        focused = self.screen.focused
        if isinstance(focused, HostTaskRows) and focused in targets:
            cursor = getattr(focused, "cursor", 0)
            count = len(focused._navigation_keys)
            if step < 0 and cursor > 0:
                focused.action_previous()
                return True
            if step > 0 and cursor < count - 1:
                focused.action_next()
                return True
        index = targets.index(focused) if focused in targets else len(targets) if step < 0 else -1
        target = targets[max(0, min(len(targets) - 1, index + step))]
        if isinstance(target, HostTaskRows) and target is not focused:
            target.cursor = len(target._navigation_keys) - 1 if step < 0 else 0
            target._paint_cursor()
        if target.parent is self.query_one("#transcript", VerticalScroll):
            target.parent.pause_follow()
        target.focus()
        if isinstance(target, HostTaskRows):
            target._reveal_cursor()
        if focused not in targets:
            self.notify("Shift+↑/↓ cards · Enter expand · Esc back", title="Cards", timeout=3)
        return True

    def action_focus_previous_card(self) -> bool:
        return self._move_card(-1)

    def action_focus_next_card(self) -> bool:
        return self._move_card(1)
