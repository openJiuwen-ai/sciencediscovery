"""Host-owned, reversible transcript folding without changing conversations."""

from rich.text import Text
from textual import events
from textual.containers import VerticalScroll
from textual.widgets import Static

from .controller import sanitize_terminal_text


class TranscriptSection(Static):
    """An initially hidden boundary, then a summary of existing display entries."""

    can_focus = True
    BINDINGS = [('enter', 'toggle', 'Expand'),
                ('shift+up', 'app.focus_previous_card', 'Previous card'),
                ('shift+down', 'app.focus_next_card', 'Next card')]

    def __init__(self) -> None:
        super().__init__('', classes='transcript-entry transcript-section', markup=False)
        self.display = False
        self.entries = ()
        self._visibility = ()
        self.summary = ''
        self.expanded = False
        self._keyboard_focused = False

    def fold(self, entries: tuple[Static, ...], summary: str) -> None:
        self.entries = entries
        self._visibility = tuple(entry.display for entry in entries)
        self.summary = sanitize_terminal_text(summary).replace('\n', ' ')
        for entry in entries:
            entry.display = False
        self.display = True
        self._refresh_summary()

    def _refresh_summary(self) -> None:
        tone = 'bold underline #B8A4E3' if self._keyboard_focused else '#8FA9C4'
        text = Text('▾ ' if self.expanded else '▸ ', style=tone, no_wrap=True, overflow='ellipsis')
        text.append(self.summary, style='#C5D1DF')
        self.update(text)

    def on_focus(self) -> None:
        self._keyboard_focused = True
        self._refresh_summary()

    def on_blur(self) -> None:
        self._keyboard_focused = False
        self._refresh_summary()

    def action_toggle(self) -> None:
        if not self.entries:
            return
        if self.expanded:
            self._visibility = tuple(entry.display for entry in self.entries)
        self.expanded = not self.expanded
        for entry, visible in zip(self.entries, self._visibility, strict=True):
            if entry.is_attached:
                entry.display = visible if self.expanded else False
        self._refresh_summary()
        transcript = self.app.query_one('#transcript', VerticalScroll)
        transcript.pause_follow()
        transcript.content_changed()

    def on_click(self, event: events.Click) -> None:
        self.action_toggle()
        event.stop()


async def begin_section(app) -> TranscriptSection:
    """Mount a boundary so preparation cannot merge with preceding chat entries."""
    section = TranscriptSection()
    await app.query_one('#transcript', VerticalScroll).mount(section)
    return section


async def fold_section(app, section: object, summary: str) -> bool:
    """Fold only this section, stopping at any subsequent host section boundary."""
    transcript = app.query_one('#transcript', VerticalScroll)
    if not isinstance(section, TranscriptSection) or section.parent is not transcript:
        return False
    if section.entries:
        return False
    children = list(transcript.children)
    entries = []
    for entry in children[children.index(section) + 1:]:
        if isinstance(entry, TranscriptSection):
            break
        entries.append(entry)
    if not entries:
        return False
    section.fold(tuple(entries), summary)
    from .chat_archive import ensure_archive

    archive = await ensure_archive(app)
    archive.synchronize()
    transcript.content_changed()
    return True
