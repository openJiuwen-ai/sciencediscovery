"""Low-level widgets used by the expandable task panel."""

from textual import events
from textual.containers import VerticalScroll
from textual.widgets import Button


class TaskPanel(VerticalScroll):
    """Keep task-list wheel events local, including at either scroll boundary."""

    def _on_mouse_scroll_down(self, event: events.MouseScrollDown) -> None:
        super()._on_mouse_scroll_down(event)
        if self.has_class("task-list"):
            event.stop()

    def _on_mouse_scroll_up(self, event: events.MouseScrollUp) -> None:
        super()._on_mouse_scroll_up(event)
        if self.has_class("task-list"):
            event.stop()


class TaskToggle(Button):
    """Left-align the label with the task rows while preserving its hit box."""

    BINDINGS = [('shift+up', 'app.focus_previous_card', 'Previous card'),
                ('shift+down', 'app.focus_next_card', 'Next card')]

    def action_press(self) -> None:
        if self.disabled or not self.display:
            return
        self._keyboard_activation = True
        super().action_press()

    def render_line(self, y):
        line = super().render_line(y)
        leading_cells = len(line.text) - len(line.text.lstrip())
        return line.crop(leading_cells).extend_cell_length(
            self.size.width,
            self.visual_style.rich_style,
        )
