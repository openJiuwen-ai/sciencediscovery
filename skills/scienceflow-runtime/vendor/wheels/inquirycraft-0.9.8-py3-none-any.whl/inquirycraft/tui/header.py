"""Responsive branding header for the terminal UI."""

from __future__ import annotations

from rich.text import Text
from textual import events
from textual.widgets import Static

from .branding import TRANSPARENT_PIXEL, TuiBranding
from .controller import sanitize_terminal_text
from .wordmark import large_wordmark, subtitle_wordmark

BRAND_PRIMARY_COLOR = "#F4EBD9"
BRAND_SECONDARY_COLOR = "#AEBED0"
BRAND_AFFILIATION_COLOR = "#9297A3"
BRAND_MUTED_COLOR = "#5F6B7A"


def _append_pixel_pair(line: Text, top: str, bottom: str) -> None:
    """Render two vertical pixels without painting transparent logo cells."""
    top_visible = top != TRANSPARENT_PIXEL
    bottom_visible = bottom != TRANSPARENT_PIXEL
    if top_visible and bottom_visible:
        line.append("▀", style=f"{top} on {bottom}")
    elif top_visible:
        line.append("▀", style=top)
    elif bottom_visible:
        line.append("▄", style=bottom)
    else:
        line.append(" ")


class BrandHeader(Static):
    """Responsive wordmark with optional, width-safe affiliation text."""

    def __init__(self, branding: TuiBranding | None = None) -> None:
        self.branding = branding or TuiBranding()
        super().__init__(self.branding.logo, id="brand", markup=False)

    def _team_label(self, width: int = 0) -> Text:
        team = sanitize_terminal_text(self.branding.team_name).strip()
        if " " in team and Text(team).cell_len < width:
            name, last = team.rsplit(" ", 1)
            team = name + " " * (width - Text(team).cell_len + 1) + last
        text = Text()
        accent = sanitize_terminal_text(self.branding.accent_text).strip()
        accent_at = team.find(accent) if accent else -1
        if accent_at < 0:
            text.append(team, style=f"{BRAND_AFFILIATION_COLOR} not bold")
            return text
        text.append(team[:accent_at], style=f"{BRAND_AFFILIATION_COLOR} not bold")
        text.append(accent, style=f"{self.branding.accent_color} not bold")
        text.append(
            team[accent_at + len(accent) :],
            style=f"{BRAND_AFFILIATION_COLOR} not bold",
        )
        return text

    def _affiliation_options(self) -> tuple[tuple[Text, ...], ...]:
        organization = sanitize_terminal_text(self.branding.organization_name).strip()
        lab = sanitize_terminal_text(self.branding.lab_name).strip()
        team = sanitize_terminal_text(self.branding.team_name).strip()
        version = sanitize_terminal_text(self.branding.version).strip()
        if not any((organization, lab, team, version)):
            return ()
        first = Text()
        if organization:
            first.append(organization, style=f"{BRAND_AFFILIATION_COLOR} not bold")
        if organization and lab:
            first.append(" · ", style=f"{BRAND_MUTED_COLOR} not bold")
        if lab:
            first.append(lab, style=f"{BRAND_AFFILIATION_COLOR} not bold")
        full = tuple(item for item in (first, self._team_label(first.cell_len)) if item.plain)
        compact = Text()
        if lab:
            compact.append(lab, style=f"{BRAND_AFFILIATION_COLOR} not bold")
        if lab and team:
            compact.append(" · ", style=f"{BRAND_MUTED_COLOR} not bold")
        if team:
            compact.append_text(self._team_label())
        version_rows = (
            (Text(f"v{version}", style=f"{BRAND_MUTED_COLOR} not bold"),) if version else ()
        )
        return (full + version_rows, ((compact,) if compact.plain else ()) + version_rows)

    def _affiliation_for(self, lines: list[Text], width: int, bottom: int) -> tuple[Text, ...]:
        if width < 58:
            return ()
        for option in self._affiliation_options():
            start = bottom + 1 - len(option)
            if start < 0 or start + len(option) > len(lines):
                continue
            block_width = max(item.cell_len for item in option)
            if all(
                width - lines[start + index].cell_len - block_width >= 3
                for index in range(len(option))
            ):
                return option
        return ()

    def _content_width(self, event: events.Resize) -> int:
        """Return the width available inside the padded brand widget."""
        region = getattr(self, "content_region", None)
        width = getattr(region, "width", 0)
        if isinstance(width, int) and width > 0:
            return width
        return max(1, event.size.width - 6)

    def on_resize(self, event: events.Resize) -> None:
        content_width = self._content_width(event)
        compact = content_width < 54 or self.app.size.height < 30
        pixels = self.branding.compact_pixels if compact else self.branding.pixels
        if not pixels:
            self.update(self.branding.compact_logo if compact else self.branding.logo)
            return
        height = len(pixels) // 2
        large = (
            large_wordmark(
                self.branding.name,
                self.branding.accent_text,
                self.branding.accent_color,
                base_color=BRAND_PRIMARY_COLOR,
            )
            if self.branding.large_title
            else ()
        )
        if large and len(pixels[0]) + 2 + large[0].cell_len > content_width:
            large = ()
        show_subtitle = (
            not (compact and self.branding.hide_compact_subtitle)
            and len(pixels[0]) + 2 + Text(self.branding.subtitle).cell_len <= content_width
        )
        subtitle = (
            subtitle_wordmark(self.branding.subtitle, color=BRAND_SECONDARY_COLOR)
            if self.branding.large_subtitle
            else ()
        )
        if (
            compact
            or not large
            or (subtitle and len(pixels[0]) + 2 + subtitle[0].cell_len > content_width)
        ):
            subtitle = ()
        title_row = max(0, (height - (2 if show_subtitle else 1)) // 2)
        large_start = max(
            0,
            (height - len(large) - (1 + (len(subtitle) or 1)) * int(show_subtitle)) // 2,
        )
        lines = []
        for row in range(height):
            line = Text()
            for top, bottom in zip(pixels[row * 2], pixels[row * 2 + 1]):
                _append_pixel_pair(line, top, bottom)
            if large:
                if large_start <= row < large_start + len(large):
                    line.append("  ")
                    line.append_text(large[row - large_start])
                elif show_subtitle:
                    subtitle_index = row - large_start - len(large) - 1
                    if subtitle and 0 <= subtitle_index < len(subtitle):
                        line.append("  ")
                        line.append_text(subtitle[subtitle_index])
                    elif not subtitle and subtitle_index == 0:
                        line.append(
                            "  " + self.branding.subtitle,
                            style=f"{BRAND_SECONDARY_COLOR} bold",
                        )
            elif row == title_row:
                name = self.branding.name
                accent = self.branding.accent_text
                if accent and name.endswith(accent):
                    line.append(
                        "  " + name[: -len(accent)],
                        style=f"{BRAND_PRIMARY_COLOR} bold",
                    )
                    line.append(accent, style=f"{self.branding.accent_color} bold")
                else:
                    line.append("  " + name, style=f"{BRAND_PRIMARY_COLOR} bold")
            elif show_subtitle and row == title_row + 1 and content_width >= 40:
                line.append(
                    "  " + self.branding.subtitle,
                    style=f"{BRAND_SECONDARY_COLOR} bold",
                )
            lines.append(line)
        affiliation_bottom = height - 1
        if show_subtitle:
            affiliation_bottom = (
                large_start + len(large) + (len(subtitle) or 1) if large else title_row + 1
            )
            affiliation_bottom = min(affiliation_bottom, height - 1)
        affiliation = self._affiliation_for(lines, content_width, affiliation_bottom)
        affiliation_start = affiliation_bottom + 1 - len(affiliation)
        affiliation_column = content_width - max((item.cell_len for item in affiliation), default=0)
        rendered_lines: list[Text] = []
        for row, line in enumerate(lines):
            rendered = line.copy()
            affiliation_index = row - affiliation_start
            if 0 <= affiliation_index < len(affiliation):
                column = affiliation_column
                if self.branding.version.strip() and affiliation_index == len(affiliation) - 1:
                    column = content_width - affiliation[affiliation_index].cell_len
                gap = column - rendered.cell_len
                if gap >= 3:
                    rendered.append(" " * gap)
                    rendered.append_text(affiliation[affiliation_index])
            rendered_lines.append(rendered)
        if any(line.cell_len > content_width for line in rendered_lines):
            rendered_lines = lines
        text = Text(no_wrap=True, overflow="ellipsis")
        for row, line in enumerate(rendered_lines):
            text.append_text(line)
            if row < height - 1:
                text.append("\n")
        self.update(text)
