"""Pure width calculations for task rows."""

from collections.abc import Mapping, Sequence
from typing import Any

from rich.text import Text

from .controller import sanitize_terminal_text


def task_row_widths(
    items: Sequence[Mapping[str, Any]], width: int
) -> tuple[str, int, int, str, int, int]:
    """Return tail, body, suffix, lead, and task-name sizing decisions."""
    tail_key = (
        "progress_tail_narrow"
        if width < 90 and any(item.get("progress_tail_narrow") for item in items)
        else "progress_tail_compact"
        if width < 110
        else "progress_tail"
    )
    tail_width = max(
        (
            Text(sanitize_terminal_text(item.get(tail_key, item.get("progress_tail", "")))).cell_len
            for item in items
        ),
        default=0,
    )
    body_width = max(0, width - tail_width - 2) if tail_width else width
    suffix_key = (
        "row_narrow_suffix"
        if body_width < 120 and any(item.get("row_narrow_suffix") for item in items)
        else "row_compact_suffix"
        if body_width < 150
        else "row_suffix"
    )
    suffix_width = max(
        (Text(sanitize_terminal_text(item.get(suffix_key, ""))).cell_len for item in items),
        default=0,
    )
    lead_width = max(
        (Text(sanitize_terminal_text(item.get("row_lead", ""))).cell_len for item in items),
        default=0,
    )
    name_slot_width = max(1, body_width - lead_width - suffix_width - 3)
    name_limits: list[int] = []
    for item in items:
        try:
            limit = int(item.get("row_name_max_width", 0))
        except (TypeError, ValueError):
            continue
        if limit > 0:
            name_limits.append(limit)
    longest_name_width = max(
        (Text(sanitize_terminal_text(item.get("row_name", ""))).cell_len for item in items),
        default=1,
    )
    name_width = min(name_slot_width, max(1, longest_name_width))
    if name_limits:
        name_width = min(name_width, min(name_limits))
    return tail_key, tail_width, body_width, suffix_key, lead_width, name_width
