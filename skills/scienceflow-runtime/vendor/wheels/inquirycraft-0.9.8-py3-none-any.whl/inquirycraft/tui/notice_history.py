"""Host-only notice folding, separate from chat numbering and stored memory."""

import re

from textual.containers import VerticalScroll

from .chat_archive import ensure_archive
from .components import TranscriptEntry
from .transcript_sections import TranscriptSection


class TaskNoticeSummary(TranscriptSection):
    """A task launch notice stays separate from general system history."""


def is_task_launch_notice(entry) -> bool:
    heading = entry.content_text.splitlines()[0] if entry.content_text else ''
    return (entry.role == 'notice' and not entry._failed()
            and bool(re.match(r'^Task \d+ · ', heading) and re.search(r'\bstarted\b', heading)))


async def fold_task_notice(app, entry) -> None:
    """Immediately fold launch details, never questions, failures or commands."""
    if not getattr(app.branding, 'fold_system_notices', False) or not is_task_launch_notice(entry):
        return
    heading = entry.content_text.splitlines()[0]
    transcript = app.query_one('#transcript', VerticalScroll)
    if entry.parent is not transcript:
        return
    # A host preparing a task owns its entries until that section is folded.
    children = list(transcript.children)
    for boundary in reversed(children[:children.index(entry)]):
        if type(boundary) is TranscriptSection:
            if not boundary.entries:
                return
            break
        if isinstance(boundary, TranscriptSection):
            break
    section = TaskNoticeSummary()
    await transcript.mount(section, before=entry)
    count = entry.segment_count
    section.fold((entry,), f"{app.branding.notice_label} · {heading} · {count} {'notice' if count == 1 else 'notices'}")
    history = await ensure_archive(app)
    history.synchronize()
    transcript.content_changed()


async def archive_system_notices(app) -> None:
    """Archive prior display notices, leaving active task questions visible."""
    if not getattr(app.branding, 'fold_system_notices', False):
        return
    transcript = app.query_one('#transcript', VerticalScroll)
    children = list(transcript.children)
    history = getattr(app, '_chat_archive', None)
    owned = {entry for section in children if isinstance(section, TranscriptSection)
             and section is not history for entry in section.entries}
    candidates = []
    preparing = False
    for entry in children:
        if type(entry) is TranscriptSection:
            preparing = not entry.entries
        elif isinstance(entry, TranscriptSection) and entry is not history:
            preparing = False
        if (isinstance(entry, TranscriptEntry) and entry.role == 'notice'
                and entry not in owned and not preparing):
            candidates.append(entry)
    if not candidates:
        return
    history = await ensure_archive(app)
    history.synchronize(notices=candidates, label=app.branding.notice_label)
    transcript.content_changed()
