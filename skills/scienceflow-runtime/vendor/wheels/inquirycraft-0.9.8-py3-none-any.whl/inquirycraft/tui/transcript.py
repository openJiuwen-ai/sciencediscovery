"""Transcript scrolling with explicit user ownership and coalesced following."""

from textual.containers import VerticalScroll
from textual.widgets import Button


class TranscriptScroll(VerticalScroll):
    """Keep streaming output visible until the reader takes control."""

    following = True
    _pending_follow = False
    _automatic = False
    _manual = False

    def on_mount(self):
        self.set_interval(0.1, self._flush_follow)

    def content_changed(self):
        if self.following:
            self._pending_follow = True
        else:
            self._indicator(True)

    def _indicator(self, visible):
        if self.app.is_mounted:
            self.app.query_one('#jump-latest', Button).display = visible

    def pause_follow(self):
        self.following = False
        self._pending_follow = False
        self._manual = True

    def resume_follow(self):
        self._manual = False
        self.following = True
        self._pending_follow = True
        self._indicator(False)

    def _flush_follow(self):
        if self._pending_follow and self.following and self.app.mouse_captured is None:
            self._pending_follow = False
            self.call_after_refresh(self._follow_after_layout)

    def _follow_after_layout(self):
        if not self.following or self.app.mouse_captured is not None:
            return
        self._automatic = True
        try:
            self.scroll_end(animate=False, immediate=True, x_axis=False)
        finally:
            self._automatic = False

    def watch_scroll_y(self, old_value, new_value):
        super().watch_scroll_y(old_value, new_value)
        if self._automatic:
            return
        if self._manual and self.max_scroll_y - new_value <= 1:
            self.resume_follow()

    def _on_mouse_scroll_up(self, event):
        self.pause_follow()
        super()._on_mouse_scroll_up(event)

    def _on_mouse_scroll_down(self, event):
        self.pause_follow()
        super()._on_mouse_scroll_down(event)
        if self.is_vertical_scroll_end:
            self.resume_follow()

    def _on_scroll_to(self, message):
        self.pause_follow()
        self.scroll_to(message.x, message.y, animate=False, immediate=True)
        message.stop()

    def _on_scroll_up(self, event):
        self.pause_follow()
        super()._on_scroll_up(event)

    def action_scroll_up(self):
        self.pause_follow()
        self.scroll_up(animate=False)

    def action_page_up(self):
        self.pause_follow()
        self.scroll_page_up(animate=False)

    def on_resize(self):
        if self.following:
            self._pending_follow = True
