"""Single-row model footer with an optional second host-resource row."""

from pathlib import Path

from rich.text import Text
from textual import events
from textual.widgets import Static

from .controller import sanitize_terminal_text


class HostFooter(Static):
    """Footer whose model label toggles the host-resource detail row."""

    def on_click(self, event: events.Click) -> None:
        position = event.get_content_offset(self)
        if (
            position is not None
            and position.y == 0
            and position.x < getattr(self, "toggle_width", 0)
        ):
            self.app._toggle_resource_status()
            event.stop()


class TuiResourceStatus:
    """Render model/context metadata and collapsible host telemetry together."""

    def set_resource_status(self, text: str) -> None:
        self._resource_status = sanitize_terminal_text(text).replace("\n", " ").strip()
        self._last_footer_state = None
        self._refresh_resource_footer()

    def _active_model_name(self) -> str:
        monitor = getattr(self.runtime, "chat_monitor", None)
        if monitor is not None and monitor.active >= 0:
            return sanitize_terminal_text(monitor.routes[monitor.active][1])
        return sanitize_terminal_text(self.model)

    def _workspace_label(self) -> str:
        """Keep the active workspace recognizable without consuming the footer."""
        try:
            relative = self.workspace.relative_to(Path.home())
        except ValueError:
            parts = self.workspace.parts
            if len(parts) <= 3:
                return self.workspace.as_posix()
            return "…/" + "/".join(parts[-2:])
        if not relative.parts:
            return "~"
        if len(relative.parts) <= 2:
            return "~/" + relative.as_posix()
        return "~/…/" + "/".join(relative.parts[-2:])

    def _footer_right_text(self) -> str:
        monitor = getattr(self.runtime, "chat_monitor", None)
        if monitor is None:
            return 'Cache —'
        stats = sorted(monitor.stats(), key=lambda stat: stat.startswith('Cache '))
        return ' · '.join(stat.removeprefix('Context ').removeprefix('Cost ') for stat in stats)

    def _refresh_resource_footer(self) -> None:
        footer = self.query_one("#footer", HostFooter)
        width = max(1, footer.content_region.width)
        resource_status = getattr(self, "_resource_status", "")
        expanded = bool(resource_status) and getattr(self, "_resources_expanded", False)
        model = self._active_model_name()
        workspace = self._workspace_label()
        marker = "▾ " if expanded else "▸ " if resource_status else ""
        model_label = Text(marker + model, style="bold #F5F7FA", no_wrap=True)
        left = model_label.copy()
        left.append(" · " + workspace, style="#9297A3")
        right = Text(self._footer_right_text(), style="#8FA9C4", no_wrap=True)
        right.truncate(max(0, width - 3), overflow="ellipsis")
        left.truncate(max(1, width - right.cell_len - 1), overflow="ellipsis")
        row = Text(no_wrap=True, overflow="ellipsis")
        row.append_text(left)
        row.append(" " * max(1, width - left.cell_len - right.cell_len))
        row.append_text(right)
        if expanded:
            detail = resource_status.removeprefix("Host · ").removeprefix("Host ")
            host = Text("Host", style="bold #C5CAD1", no_wrap=True)
            if detail:
                host.append(" · " + detail, style="#9297A3")
            host.truncate(width, overflow="ellipsis")
            row.append("\n")
            row.append_text(host)
        state = (model, workspace, right.plain, resource_status, expanded, width)
        if state != getattr(self, "_last_footer_state", None):
            footer.toggle_width = model_label.cell_len
            footer.set_class(expanded, "expanded")
            footer.update(row)
            self._last_footer_state = state

    def _toggle_resource_status(self) -> None:
        if not getattr(self, "_resource_status", ""):
            return
        self._resources_expanded = not getattr(self, "_resources_expanded", False)
        self._last_footer_state = None
        self._refresh_resource_footer()
