"""Pure layout helpers for host progress summaries."""


def aligned_summary(summary: str, width: int) -> tuple[str, str]:
    """Align known progress fields while preserving unfamiliar host lines."""
    output, title = [], ""
    for line in summary.splitlines():
        fields = [part.strip() for part in line.split(" · ")]
        if " · Workers " in line:
            title = fields.pop(0)
            label, count = fields[0].split(maxsplit=1)
            fields[0] = "Total " + count
        elif line.startswith("Time "):
            output.append("Time".ljust(11) + line[5:])
            continue
        elif line.startswith("Result "):
            metric = fields.pop(0).removeprefix("Result").strip()
            label = "Result"
            fields = [item.strip() for part in fields for item in part.split(" / ")]
            fields.append(metric)
        elif fields[0] in {"ESTRA", "EEC", "Resources", "Research usage"}:
            label = fields.pop(0).replace("Research usage", "Usage")
            fields = [item.strip() for part in fields for item in part.split(" / ")]
        else:
            output.append(line)
            continue
        if label in {"Workers", "ESTRA", "EEC", "Resources"}:
            fields = [field for field in fields if not field.endswith(" 0")]
            if not fields:
                fields = ["No events"]
        cells = []
        for field in fields:
            key, sep, value = field.rpartition(" ")
            if sep and (value == "—" or value.rstrip("KM%").replace(".", "", 1).isdigit()):
                if label == "Usage" and key.lower() in {"in", "out"}:
                    key += " token"
                cells.append(f"{key.capitalize()} {value}")
            else:
                cells.append(field)
        output.append(f"{label:<11}" + " · ".join(cells))
    return "\n".join(output), title
