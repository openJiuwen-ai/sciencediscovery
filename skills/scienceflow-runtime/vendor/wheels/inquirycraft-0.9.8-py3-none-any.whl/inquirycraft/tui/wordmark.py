"""Compact two-row terminal lettering for optional host wordmarks."""

from rich.text import Text

_GLYPHS = {
    ' ': ('0', '0', '0', '0'),
    '-': ('000', '111', '000', '000'),
    ',': ('00', '00', '01', '10'),
    'a': ('010', '101', '111', '101'),
    'b': ('110', '111', '101', '110'),
    'd': ('110', '101', '101', '110'),
    'g': ('111', '100', '101', '111'),
    'h': ('101', '111', '101', '101'),
    'k': ('101', '110', '110', '101'),
    'm': ('10001', '11011', '10101', '10001'),
    'p': ('110', '101', '110', '100'),
    'r': ('110', '101', '110', '101'),
    't': ('111', '010', '010', '010'),
    'u': ('101', '101', '101', '111'),
    'v': ('101', '101', '101', '010'),
    'y': ('101', '101', '010', '010'),
    'z': ('111', '001', '010', '111'),
    's': ('111', '100', '011', '111'),
    'c': ('111', '100', '100', '111'),
    'i': ('111', '010', '010', '111'),
    'e': ('111', '110', '100', '111'),
    'n': ('110', '101', '101', '101'),
    'f': ('111', '110', '100', '100'),
    'l': ('100', '100', '100', '111'),
    'o': ('111', '101', '101', '111'),
    'w': ('10001', '10101', '10101', '01010'),
}


def large_wordmark(
    name: str,
    accent: str,
    color: str,
    *,
    base_color: str = "#D2D7DF",
) -> tuple[Text, ...]:
    if not name or any(letter.lower() not in _GLYPHS for letter in name):
        return ()
    accent_start = len(name) - len(accent) if accent and name.endswith(accent) else len(name)
    rows = []
    for y in (0, 2):
        row = Text()
        for index, letter in enumerate(name):
            glyph = _GLYPHS[letter.lower()]
            style = color if index >= accent_start else base_color
            top = glyph[y]
            bottom = glyph[y + 1]
            pixels = ''.join({('0', '0'): ' ', ('1', '0'): '▀',
                              ('0', '1'): '▄', ('1', '1'): '█'}[a, b]
                             for a, b in zip(top, bottom))
            row.append(pixels + (' ' if index < len(name) - 1 else ''), style=style)
        rows.append(row)
    return tuple(rows)


# Three half-cell rows: 1.5 terminal rows, packed horizontally with quadrants.
_SUBTITLE_GLYPHS = {
    'a': ('010', '111', '101'), 'b': ('110', '111', '110'),
    'c': ('111', '100', '111'), 'd': ('110', '101', '110'),
    'e': ('111', '110', '111'), 'f': ('111', '110', '100'),
    'g': ('111', '101', '111'), 'h': ('101', '111', '101'),
    'i': ('1', '1', '1'), 'k': ('101', '110', '101'),
    'l': ('100', '100', '111'), 'm': ('11011', '10101', '10001'),
    'n': ('110', '101', '101'), 'o': ('010', '101', '010'),
    'p': ('111', '111', '100'), 'r': ('110', '111', '101'),
    's': ('011', '010', '110'), 't': ('111', '010', '010'),
    'u': ('101', '101', '111'), 'v': ('101', '101', '010'),
    'w': ('10001', '10101', '01010'), 'y': ('101', '010', '010'),
    'z': ('110', '010', '011'), '-': ('00', '11', '00'),
    ',': ('0', '0', '1'), ' ': ('00', '00', '00'),
}
_QUADRANTS = ' ▘▝▀▖▌▞▛▗▚▐▜▄▙▟█'


def subtitle_wordmark(text: str, *, color: str = "#8F9BAA") -> tuple[Text, ...]:
    """Render a compact three-pixel slogan without changing terminal font size."""
    if not text or any(char.lower() not in _SUBTITLE_GLYPHS for char in text):
        return ()
    raster = ['0'.join(_SUBTITLE_GLYPHS[char.lower()][y] for char in text) for y in range(3)]
    width = len(raster[0])
    raster = [row.ljust(width + width % 2, '0') for row in raster]
    raster.append('0' * len(raster[0]))
    rows = []
    for y in (0, 2):
        cells = []
        for x in range(0, len(raster[0]), 2):
            bits = (int(raster[y][x]) + 2 * int(raster[y][x + 1])
                    + 4 * int(raster[y + 1][x]) + 8 * int(raster[y + 1][x + 1]))
            cells.append(_QUADRANTS[bits])
        rows.append(Text(''.join(cells), style=color))
    return tuple(rows)
