"""One reversible history entry with separate chat and host-notice counts."""

from .transcript_sections import TranscriptSection

RECENT_CHAT_ROUNDS = 2


class ChatHistoryArchive(TranscriptSection):
    """One history row retaining independent round and nested tool states."""

    def __init__(self) -> None:
        super().__init__()
        self.rounds = ()
        self.notices = ()
        self.notice_label = ''

    def synchronize(self, rounds=None, *, notices=None, label: str = '') -> None:
        if rounds is not None:
            self.rounds = tuple(rounds)
        if notices is not None:
            self.notices = tuple(dict.fromkeys((*self.notices, *notices)))
        if label:
            self.notice_label = label
        from .chat_history import ChatRoundSummary

        sections = tuple(
            entry for entry in (self.parent.children if self.parent else ())
            if isinstance(entry, TranscriptSection)
            and entry is not self and not isinstance(entry, ChatRoundSummary)
            and entry.entries
        )
        previous = dict(zip(self.entries, self._visibility, strict=True))
        entries = tuple(dict.fromkeys([
            *(entry for section in self.rounds for entry in (section, *section.entries)),
            *self.notices,
            *(entry for section in sections for entry in (section, *section.entries)),
        ]))
        visibility = tuple(entry.display if self.expanded or entry not in previous else previous[entry]
                           for entry in entries)
        for entry, visible in previous.items():
            if entry not in entries and entry.is_attached:
                entry.display = visible
        self.entries, self._visibility = entries, visibility
        parts = ['History']
        if self.rounds:
            parts.extend((f'{len(self.rounds)} rounds', f'#{self.rounds[0].number}–#{self.rounds[-1].number}'))
        if self.notices:
            count = sum(entry.segment_count for entry in self.notices)
            parts.append(f"{self.notice_label} · {count} {'notice' if count == 1 else 'notices'}")
        if sections:
            count = len(sections)
            parts.append(f"{count} task {'record' if count == 1 else 'records'}")
        self.summary = ' · '.join(parts)
        self.display = True
        for entry, visible in zip(entries, visibility, strict=True):
            entry.display = visible if self.expanded else False
        self._refresh_summary()


async def ensure_archive(app):
    """Both record types use the same top-of-transcript control."""
    from textual.containers import VerticalScroll

    archive = getattr(app, '_chat_archive', None)
    if archive is None or not archive.is_attached:
        transcript = app.query_one('#transcript', VerticalScroll)
        archive = ChatHistoryArchive()
        await transcript.mount(archive, before=transcript.children[0] if transcript.children else None)
        app._chat_archive = archive
    return archive


async def update_archive(app) -> None:
    """Keep two prior chat summaries plus the current, fully visible exchange."""
    from textual.containers import VerticalScroll

    rounds = [section for section in app._chat_rounds if section.is_attached and section.entries]
    older = rounds[:-RECENT_CHAT_ROUNDS]
    if not older and getattr(app, '_chat_archive', None) is None:
        return
    transcript = app.query_one('#transcript', VerticalScroll)
    archive = await ensure_archive(app)
    archive.synchronize(older)
    transcript.content_changed()
