from __future__ import annotations

from typing import Any


def build_llm_call_record(
    source_llm: Any,
    *,
    operation: str,
    duration_sec: float,
    call_seq: int,
    round_idx: int | None,
    status: str = "ok",
    recovery: bool = False,
    turn_kind: str | None = None,
    first_tool_name: str | None = None,
    first_bash_kind: str | None = None,
    llm_role: str | None = None,
) -> dict[str, Any]:
    """Build one provider-neutral LLM telemetry record.

    Attribute names support compatibility clients and remain optional so lightweight
    clients need not implement usage data.
    """

    fields = (
        ("tokens_input", "_last_call_input_tokens", int),
        ("tokens_output", "_last_call_output_tokens", int),
        ("ttft_sec", "_last_call_ttft", float),
        ("tpot_ms", "_last_call_tpot", float),
        ("tokens_cached", "_last_call_input_cached_tokens", int),
        ("pool_index", "_last_call_pool_index", int),
        ("failover_count", "_last_call_failover_count", int),
    )
    values = dict.fromkeys(name for name, _, _ in fields)
    if status == "ok":
        try:
            raw = [getattr(source_llm, attr, None) for _, attr, _ in fields]
            for (name, _, convert), value in zip(fields, raw, strict=True):
                if value is not None:
                    values[name] = convert(value)
        except (TypeError, ValueError):
            pass

    model = getattr(source_llm, "model", None)
    record: dict[str, Any] = {
        "operation": operation,
        "duration_sec": float(duration_sec),
        "call_seq": call_seq,
        "round_idx": round_idx,
        "recovery": recovery,
        **values,
        "model": str(model) if model is not None else None,
        "status": status,
    }
    for name, value in (
        ("turn_kind", turn_kind), ("llm_role", llm_role),
        ("first_tool_name", first_tool_name), ("first_bash_kind", first_bash_kind),
    ):
        if value is not None:
            record[name] = value
    return record
