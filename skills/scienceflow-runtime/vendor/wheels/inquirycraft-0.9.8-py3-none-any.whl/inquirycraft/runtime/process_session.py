from __future__ import annotations

import asyncio
import hashlib
import inspect
import json
import time
import uuid
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .process_models import (
    ProcessAdapter,
    ProcessChunkConsumer,
    ProcessLifecycle,
    ProcessLifecycleState,
    ProcessObservation,
    ProcessObserver,
    ProcessOutcome,
    ProcessOutput,
    ProcessRequest,
    ProcessSpawnError,
    ProcessStatus,
    ProcessStream,
    ProcessStreamChunk,
    RawOutputArtifactRef,
)
from .subprocess import (
    live_process_group_ids,
    spawn_exec,
    spawn_shell,
    terminate_tree,
    terminate_tree_recoverable,
    unregister_process_group,
)


@dataclass(frozen=True, slots=True)
class LocalProcessAdapter:
    spawn_shell_fn: Callable[..., Awaitable[Any]] = spawn_shell
    spawn_exec_fn: Callable[..., Awaitable[Any]] = spawn_exec
    terminate_fn: Callable[..., Awaitable[None]] = terminate_tree
    terminate_recoverable_fn: Callable[..., Awaitable[None]] = terminate_tree_recoverable
    unregister_fn: Callable[[int], None] = unregister_process_group
    live_pgids_fn: Callable[[], tuple[int, ...]] = live_process_group_ids

    async def spawn(self, request: ProcessRequest) -> Any:
        kwargs = {
            "stdin": asyncio.subprocess.DEVNULL,
            "stdout": asyncio.subprocess.PIPE,
            "stderr": asyncio.subprocess.PIPE,
            "cwd": str(request.cwd),
            "limit": max(1, request.stream_limit_bytes),
        }
        if request.environment:
            kwargs["env"] = dict(request.environment)
        if request.command:
            return await self.spawn_shell_fn(request.command, **kwargs)
        if request.argv:
            return await self.spawn_exec_fn(*request.argv, **kwargs)
        raise ValueError("process request requires command or argv")

    async def terminate(self, process: Any, **kwargs: Any) -> None:
        recoverable = bool(kwargs.pop("recoverable", False))
        if recoverable:
            await self.terminate_recoverable_fn(process, **kwargs)
        else:
            await self.terminate_fn(process, grace=float(kwargs.get("sigterm_grace", 5.0)))

    def unregister(self, process_group_id: int) -> None:
        self.unregister_fn(process_group_id)

    def live_process_group_ids(self) -> tuple[int, ...]:
        return self.live_pgids_fn()


class ProcessExecutionSession:
    """Own one process from spawn through lossless stream capture and cleanup."""

    def __init__(
        self,
        request: ProcessRequest,
        *,
        adapter: ProcessAdapter | None = None,
        on_chunk: ProcessChunkConsumer | None = None,
        observers: tuple[ProcessObserver, ...] = (),
    ) -> None:
        self.request = request
        self.session_id = request.session_id or f"process-{uuid.uuid4().hex[:12]}"
        self.adapter = adapter or LocalProcessAdapter()
        self.on_chunk = on_chunk
        self.observers = observers
        self.process: Any | None = None
        self.lifecycle = ProcessLifecycle()
        self.last_outcome: ProcessOutcome | None = None
        self._sequence = self._observation_sequence = 0
        self._stdout: list[bytes] = []
        self._stderr: list[bytes] = []
        self._observer_failures: list[str] = []
        self._started_at = self._started_monotonic = 0.0
        self._termination_lock = asyncio.Lock()

    @property
    def process_group_id(self) -> int | None:
        value = getattr(self.process, "pid", None)
        return int(value) if value is not None else None

    async def start(self) -> Any:
        if self.process is not None:
            raise RuntimeError("process session has already started")
        self._started_at, self._started_monotonic = time.time(), time.monotonic()
        self.lifecycle.state = ProcessLifecycleState.STARTING
        await self._emit("process.starting")
        try:
            self.process = await self.adapter.spawn(self.request)
        except Exception as exc:
            self.lifecycle.state = ProcessLifecycleState.FAILED
            await self._emit("process.spawn_failed", detail=f"{type(exc).__name__}: {exc}")
            raise ProcessSpawnError(exc) from exc
        self.lifecycle.state = ProcessLifecycleState.RUNNING
        await self._emit("process.started")
        return self.process

    async def run(self) -> ProcessOutcome:
        operation: asyncio.Future[Any] | None = None
        try:
            if self.process is None:
                await self.start()
            assert self.process is not None
            stdout_task = asyncio.create_task(self._pump(self.process.stdout, ProcessStream.STDOUT, self._stdout))
            stderr_task = asyncio.create_task(self._pump(self.process.stderr, ProcessStream.STDERR, self._stderr))
            operation = asyncio.gather(stdout_task, stderr_task, self.process.wait())
            if self.request.timeout_sec > 0:
                await asyncio.wait_for(asyncio.shield(operation), self.request.timeout_sec)
            else:
                await operation
            status = (
                ProcessStatus.SUCCEEDED if self.process.returncode == 0 else ProcessStatus.FAILED
            )
            if self.lifecycle.state is ProcessLifecycleState.RUNNING:
                self.lifecycle.state = ProcessLifecycleState(status.value)
            else:
                status = ProcessStatus(self.lifecycle.state.value)
            await self._emit("process.exited", returncode=self.process.returncode)
        except asyncio.TimeoutError:
            status = ProcessStatus.TIMED_OUT
            await self.terminate(status)
            await asyncio.gather(operation, return_exceptions=True)
        except asyncio.CancelledError:
            await self.terminate(ProcessStatus.CANCELLED)
            await asyncio.gather(*((operation,) if operation else ()), return_exceptions=True)
            self.last_outcome = self._outcome(ProcessStatus.CANCELLED) if self.process else None
            raise
        except BaseException:
            await self.terminate(ProcessStatus.TERMINATED)
            await asyncio.gather(*((operation,) if operation else ()), return_exceptions=True)
            raise
        finally:
            if self.process_group_id is not None:
                self.adapter.unregister(self.process_group_id)
        self.last_outcome = self._outcome(status)
        return self.last_outcome

    async def terminate(
        self, status: ProcessStatus = ProcessStatus.TERMINATED, **kwargs: Any
    ) -> None:
        if self.process is None or self.process.returncode is not None:
            return
        async with self._termination_lock:
            if self.process.returncode is not None:
                return
            await self._emit("process.terminating", detail=status.value)
            self.lifecycle.state = ProcessLifecycleState(status.value)
            await self.adapter.terminate(self.process, **kwargs)
            await self._emit(f"process.{status.value}", returncode=self.process.returncode)

    def set_chunk_consumer(self, consumer: ProcessChunkConsumer | None) -> None:
        if self._stdout or self._stderr:
            raise RuntimeError("stream pumping has already started")
        self.on_chunk = consumer

    async def _pump(self, stream: Any, name: ProcessStream, target: list[bytes]) -> None:
        if stream is None:
            return
        while raw := await self._read_stream_chunk(stream):
            value = raw.encode() if isinstance(raw, str) else bytes(raw)
            target.append(value)
            self._sequence += 1
            chunk = ProcessStreamChunk(self._sequence, name, value, value.decode(errors="replace"))
            await self._emit(
                "process.stream",
                stream=name,
                chunk_sequence=chunk.sequence,
                byte_count=len(value),
            )
            if self.on_chunk is not None:
                result = self.on_chunk(chunk)
                if inspect.isawaitable(result):
                    await result

    async def _read_stream_chunk(self, stream: Any) -> bytes | str:
        if not isinstance(stream, asyncio.StreamReader):
            return await stream.readline()
        try:
            return await stream.readuntil(b"\n")
        except asyncio.LimitOverrunError as exc:
            consumed = max(1, min(int(exc.consumed), 1024 * 1024))
            return await stream.readexactly(consumed)
        except asyncio.IncompleteReadError as exc:
            return exc.partial

    async def _emit(self, kind: str, **kwargs: Any) -> None:
        self._observation_sequence += 1
        observation = ProcessObservation(
            self._observation_sequence,
            self.session_id,
            kind,
            self.process_group_id,
            **kwargs,
        )
        for observer in self.observers:
            try:
                result = observer(observation)
                if inspect.isawaitable(result):
                    await result
            except Exception as exc:
                name = getattr(observer, "__name__", type(observer).__name__)
                self._observer_failures.append(f"{name}: {type(exc).__name__}: {exc}")

    def _outcome(self, status: ProcessStatus) -> ProcessOutcome:
        output = ProcessOutput(b"".join(self._stdout), b"".join(self._stderr))
        raw_ref = persist_raw_output(output, self.request.raw_output_dir, self.session_id)
        return ProcessOutcome(
            self.session_id,
            status,
            getattr(self.process, "returncode", None),
            self.process_group_id,
            self._started_at,
            time.time(),
            max(0.0, time.monotonic() - self._started_monotonic),
            output,
            raw_ref,
            tuple(self._observer_failures),
        )


def persist_raw_output(
    output: ProcessOutput, directory: Path | None, session_id: str
) -> RawOutputArtifactRef | None:
    if directory is None:
        return None
    directory.mkdir(parents=True, exist_ok=True)
    safe = (
        "".join(char if char.isalnum() or char in "-_" else "_" for char in session_id) or "process"
    )
    stdout_path, stderr_path = directory / f"{safe}.stdout.bin", directory / f"{safe}.stderr.bin"
    manifest_path = directory / f"{safe}.json"
    stdout_path.write_bytes(output.stdout_bytes)
    stderr_path.write_bytes(output.stderr_bytes)
    stdout_sha, stderr_sha = (
        hashlib.sha256(output.stdout_bytes).hexdigest(),
        hashlib.sha256(output.stderr_bytes).hexdigest(),
    )
    manifest_path.write_text(
        json.dumps(
            {"session_id": session_id, "stdout_sha256": stdout_sha, "stderr_sha256": stderr_sha},
            sort_keys=True,
        )
        + "\n"
    )
    return RawOutputArtifactRef(stdout_path, stderr_path, manifest_path, stdout_sha, stderr_sha)


def render_process_output(output: ProcessOutput) -> str:
    parts = [output.stdout]
    if output.stderr.strip():
        parts.append(f"[stderr]\n{output.stderr.rstrip()}")
    return "\n".join(parts).rstrip()


render_combined_output = render_process_output
InquiryCraftProcessAdapter = LocalProcessAdapter
