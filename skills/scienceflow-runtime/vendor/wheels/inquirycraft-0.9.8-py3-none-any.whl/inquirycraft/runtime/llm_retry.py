from __future__ import annotations

import inspect
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, replace

from inquirycraft.llm import (
    CompletionRequest,
    is_missing_reasoning_replay_error,
    is_retryable_empty_tool_stream_error,
    project_reasoning_messages,
)

from .hooks import RuntimeContext

_REPETITION_NUDGE = (
    "Your previous response was interrupted due to excessive repetition or verbosity. "
    "Respond concisely, avoid repeating prior analysis, and proceed directly to the next "
    "action/tool call."
)


@dataclass(frozen=True, slots=True)
class LLMRetryRequest:
    error: BaseException
    attempt: int
    request: CompletionRequest
    context: RuntimeContext


LLMRetryAdapter = Callable[
    [LLMRetryRequest], CompletionRequest | None | Awaitable[CompletionRequest | None]
]


def default_same_round_retry_adapter(retry: LLMRetryRequest) -> CompletionRequest | None:
    """Return a safe same-round request projection for recognized failures."""

    if is_missing_reasoning_replay_error(retry.error):
        messages = project_reasoning_messages(retry.request.messages, "required")
        return (
            replace(retry.request, messages=messages)
            if messages != retry.request.messages
            else None
        )
    if is_retryable_empty_tool_stream_error(retry.error):
        return retry.request
    message = str(retry.error)
    if any(
        marker in message
        for marker in (
            "Stream guard stopped output: repetition",
            "Stream guard stopped output: output_soft_limit",
        )
    ):
        return replace(
            retry.request,
            messages=(*retry.request.messages, {"role": "user", "content": _REPETITION_NUDGE}),
        )
    return None


async def resolve_retry_request(
    adapter: LLMRetryAdapter,
    retry: LLMRetryRequest,
) -> CompletionRequest | None:
    value = adapter(retry)
    return await value if inspect.isawaitable(value) else value
