from __future__ import annotations

from enum import Enum


class AgentState(str, Enum):
    """Shared lifecycle state for stateful agent integrations."""

    IDLE = "IDLE"
    RUNNING = "RUNNING"
    FINISHED = "FINISHED"
    ERROR = "ERROR"
