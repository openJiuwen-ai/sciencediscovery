from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from inquirycraft.llm import ReasoningReplayPolicy

from .queues import DrainMode


@dataclass(frozen=True, slots=True)
class RuntimeOptions:
    model: str
    workspace: Path
    system_prompt: str = "You are a helpful agent."
    max_turns: int | None = 20  # None: no turn ceiling; cancellation remains available.
    temperature: float | None = None
    max_tokens: int | None = None
    timeout: float | None = 300.0
    session_id: str = ""
    run_id: str = ""
    agent_id: str = "agent"
    session_log: Path | None = None
    tool_execution: Literal["sequential", "parallel"] = "sequential"
    stream_llm: bool = False
    max_output_chars_soft: int = 0
    operation_log: Path | None = None
    queue_drain_mode: DrainMode = "all"
    preserve_empty_reasoning_content: bool = False
    model_routing: str = "round_robin"
    use_proxies: tuple[bool | None, ...] = ()
    reasoning_replay: ReasoningReplayPolicy = "preserve"
