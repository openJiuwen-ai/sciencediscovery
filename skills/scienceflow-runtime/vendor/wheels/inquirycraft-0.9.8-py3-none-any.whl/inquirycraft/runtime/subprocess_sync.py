"""Synchronous process-group execution built on InquiryCraft's shared registry."""

from __future__ import annotations

import os
import signal
import subprocess
from collections.abc import Sequence
from typing import Any

from .subprocess import (
    _LIVE_PGIDS,
    _kill_snapshot_survivors,
    _pdeathsig_setup,
    _snapshot_descendants,
)


def run_in_process_group(
    args: Sequence[str] | str,
    *,
    timeout: float | None = None,
    input: str | bytes | None = None,
    capture_output: bool = False,
    check: bool = False,
    grace: float = 5.0,
    **kwargs: Any,
) -> subprocess.CompletedProcess:
    """Synchronous ``subprocess.run`` variant with process-group cleanup.

    This is for legacy synchronous call sites that run user ``solution.py``
    directly. It mirrors the important ``subprocess.run`` behavior used in this
    codebase, but starts the child in its own session, registers the PGID for
    CLI shutdown cleanup, and kills the whole process group on timeout or
    interruption.
    """
    if kwargs.get("start_new_session") is not None:
        raise ValueError("run_in_process_group owns start_new_session")
    if kwargs.get("preexec_fn") is not None:
        raise ValueError("run_in_process_group owns preexec_fn")
    if capture_output:
        if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
            raise ValueError("stdout and stderr may not be used with capture_output")
        kwargs["stdout"] = subprocess.PIPE
        kwargs["stderr"] = subprocess.PIPE
    if input is not None:
        if kwargs.get("stdin") is not None:
            raise ValueError("stdin may not be used with input")
        kwargs["stdin"] = subprocess.PIPE

    proc: subprocess.Popen | None = None
    try:
        proc = subprocess.Popen(
            args,
            start_new_session=True,
            preexec_fn=_pdeathsig_setup,
            **kwargs,
        )
        _LIVE_PGIDS.add(proc.pid)
        try:
            stdout, stderr = proc.communicate(input=input, timeout=timeout)
        except subprocess.TimeoutExpired as exc:
            stdout = exc.output
            stderr = exc.stderr
            terminate_tree_sync(proc, grace=grace)
            try:
                killed_stdout, killed_stderr = proc.communicate(timeout=1)
                if killed_stdout is not None:
                    stdout = killed_stdout
                if killed_stderr is not None:
                    stderr = killed_stderr
            except Exception:
                pass
            raise subprocess.TimeoutExpired(
                exc.cmd,
                exc.timeout,
                output=stdout,
                stderr=stderr,
            ) from None

        ret = subprocess.CompletedProcess(args, proc.returncode, stdout, stderr)
        if check and ret.returncode:
            raise subprocess.CalledProcessError(
                ret.returncode,
                ret.args,
                output=ret.stdout,
                stderr=ret.stderr,
            )
        return ret
    except BaseException:
        if proc is not None and proc.poll() is None:
            terminate_tree_sync(proc, grace=grace)
        raise
    finally:
        if proc is not None:
            _LIVE_PGIDS.discard(proc.pid)


def terminate_tree_sync(proc: subprocess.Popen, *, grace: float = 5.0) -> None:
    """Synchronous process-group terminator for ``run_in_process_group``."""
    pgid = proc.pid
    _LIVE_PGIDS.discard(pgid)
    pre_descendants = _snapshot_descendants(pgid)

    try:
        os.killpg(pgid, signal.SIGTERM)
    except (ProcessLookupError, PermissionError):
        pass

    try:
        proc.wait(timeout=grace)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(pgid, signal.SIGKILL)
        except (ProcessLookupError, PermissionError):
            pass
        try:
            proc.wait(timeout=2)
        except Exception:
            pass

    _kill_snapshot_survivors(pre_descendants)


# Compatibility for callers that imported the pre-0.7.2 private helper.
_terminate_tree_sync = terminate_tree_sync
