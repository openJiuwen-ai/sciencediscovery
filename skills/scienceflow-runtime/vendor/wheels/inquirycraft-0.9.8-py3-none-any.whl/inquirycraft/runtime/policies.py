"""Domain-neutral provider-turn decisions owned by the runtime."""

from __future__ import annotations

import inspect
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass, field
from typing import Any, Literal, TypeAlias

from inquirycraft.llm import CompletionResult
from inquirycraft.memory import Message

from .hooks import RuntimeContext

ToolChoice: TypeAlias = str | Mapping[str, Any] | None
TurnAction: TypeAlias = Literal["default", "continue", "terminate"]


@dataclass(frozen=True, slots=True)
class ToolChoiceRequest:
    turn: int
    messages: tuple[Mapping[str, Any], ...]
    tools: tuple[Mapping[str, Any], ...]
    context: RuntimeContext


ToolChoicePolicy: TypeAlias = Callable[[ToolChoiceRequest], ToolChoice | Awaitable[ToolChoice]]


@dataclass(frozen=True, slots=True)
class TurnDecisionRequest:
    result: CompletionResult
    context: RuntimeContext


@dataclass(frozen=True, slots=True)
class TurnDecision:
    """A host decision that does not transfer loop ownership to the host."""

    action: TurnAction = "default"
    reason: str = ""
    inject_messages: tuple[Message, ...] = field(default_factory=tuple)
    suppress_assistant: bool = False
    route: str = ""
    output: str | None = None


TurnDecisionPolicy: TypeAlias = Callable[
    [TurnDecisionRequest], TurnDecision | Awaitable[TurnDecision]
]


@dataclass(frozen=True, slots=True)
class ExhaustionRequest:
    final_content: str
    context: RuntimeContext


@dataclass(frozen=True, slots=True)
class ExhaustionDecision:
    additional_turns: int = 0
    inject_messages: tuple[Message, ...] = field(default_factory=tuple)
    output: str | None = None
    reason: str = ""


ExhaustionPolicy: TypeAlias = Callable[
    [ExhaustionRequest], ExhaustionDecision | Awaitable[ExhaustionDecision]
]


async def resolve_tool_choice(policy: ToolChoicePolicy, request: ToolChoiceRequest) -> ToolChoice:
    value = policy(request)
    return await value if inspect.isawaitable(value) else value


async def resolve_turn_decision(
    policy: TurnDecisionPolicy | None, request: TurnDecisionRequest
) -> TurnDecision:
    if policy is None:
        return TurnDecision()
    value = policy(request)
    decision = await value if inspect.isawaitable(value) else value
    if not isinstance(decision, TurnDecision):
        raise TypeError("TurnDecisionPolicy must return TurnDecision")
    return decision


async def resolve_exhaustion_decision(
    policy: ExhaustionPolicy | None, request: ExhaustionRequest
) -> ExhaustionDecision:
    if policy is None:
        return ExhaustionDecision()
    value = policy(request)
    decision = await value if inspect.isawaitable(value) else value
    if not isinstance(decision, ExhaustionDecision):
        raise TypeError("ExhaustionPolicy must return ExhaustionDecision")
    return decision
