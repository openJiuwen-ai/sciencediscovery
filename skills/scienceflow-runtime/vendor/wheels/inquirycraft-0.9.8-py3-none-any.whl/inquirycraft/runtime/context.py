from __future__ import annotations

import inspect
from collections.abc import Awaitable, Callable, Mapping, Sequence
from dataclasses import asdict, dataclass
from typing import Any, Literal, Protocol

from inquirycraft.llm import (
    ReasoningReplayPolicy,
    normalize_reasoning_replay,
    project_reasoning_messages,
)

from .active_context import ActiveContext
from .context_compaction import ContextCompactionMixin
from .hooks import RuntimeContext
from .token_estimation import TokenCalibration, estimate_tokens


class ContextProjectionExit(Exception):
    def __init__(self, output: str, reason: str = "context_projection_exit") -> None:
        super().__init__(reason)
        self.output, self.reason = output, reason


class ContextTransformer(Protocol):
    def transform(
        self,
        messages: Sequence[Mapping[str, Any]],
        context: RuntimeContext,
    ) -> Sequence[Mapping[str, Any]] | Awaitable[Sequence[Mapping[str, Any]]]: ...


@dataclass(frozen=True, slots=True)
class ProtectedContextSegment:
    start: int
    end: int
    label: str = ""


@dataclass(frozen=True, slots=True)
class ContextProjectionRequest:
    source_messages: tuple[Mapping[str, Any], ...]
    provider_messages: tuple[Mapping[str, Any], ...]
    estimate: TokenEstimate
    context: RuntimeContext
    reason: str = "turn"


@dataclass(frozen=True, slots=True)
class CompactionDecision:
    messages: tuple[Mapping[str, Any], ...] | None = None
    protected_segments: tuple[ProtectedContextSegment, ...] = ()
    cancel: bool = False
    reason: str = ""
    checkpoint_metadata: Mapping[str, Any] | None = None


ContextDecisionPolicy = Callable[
    [ContextProjectionRequest], CompactionDecision | None | Awaitable[CompactionDecision | None]
]


@dataclass(frozen=True, slots=True)
class CompactionPolicy:
    enabled: bool = False
    max_context_tokens: int = 0
    reserve_tokens: int = 2_000
    keep_recent_tokens: int = 4_000


@dataclass(frozen=True, slots=True)
class TokenEstimate:
    tokens: int
    source: Literal["heuristic", "provider_usage"]
    heuristic_tokens: int
    provider_input_tokens: int | None = None

    def project(self, messages, **metadata) -> ProviderContext:
        return ProviderContext(messages, self.tokens, estimate_source=self.source,
                               provider_input_tokens=self.provider_input_tokens, **metadata)


@dataclass(frozen=True, slots=True)
class ProviderUsageObservation:
    input_tokens: int
    heuristic_tokens: int


@dataclass(frozen=True, slots=True)
class ProviderContext:
    messages: tuple[Mapping[str, Any], ...]
    estimated_tokens: int
    compacted: bool = False
    omitted_messages: int = 0
    estimate_source: Literal["heuristic", "provider_usage"] = "heuristic"
    provider_input_tokens: int | None = None
    tokens_before: int | None = None
    checkpoint: Mapping[str, Any] | None = None


class ContextPipeline(ContextCompactionMixin):
    def __init__(
        self,
        *,
        transformers: Sequence[ContextTransformer] = (),
        compaction: CompactionPolicy | None = None,
        decision_policy: ContextDecisionPolicy | None = None,
        reasoning_replay: ReasoningReplayPolicy = "preserve",
    ) -> None:
        self.transformers = tuple(transformers)
        self.compaction = compaction or CompactionPolicy()
        self.decision_policy = decision_policy
        self.reasoning_replay = normalize_reasoning_replay(reasoning_replay)
        self._provider_usage: ProviderUsageObservation | None = None
        self._calibration = TokenCalibration()
        self._active = ActiveContext()

    @property
    def uses_active_context(self) -> bool:
        return self.compaction.enabled and not self.transformers and self.decision_policy is None

    def set_reasoning_replay(self, policy: ReasoningReplayPolicy | str) -> None:
        normalized = normalize_reasoning_replay(policy)
        if normalized != self.reasoning_replay:
            self._active = ActiveContext()
        self.reasoning_replay = normalized

    def estimate(self, messages: Sequence[Mapping[str, Any]]) -> TokenEstimate:
        heuristic = estimate_tokens(messages)
        observed = self._provider_usage
        if observed is None or observed.input_tokens <= 0:
            return TokenEstimate(heuristic, "heuristic", heuristic)
        return TokenEstimate(self._calibration.estimate(heuristic), "provider_usage",
                             heuristic, observed.input_tokens)

    def observe_provider_usage(
        self,
        messages: Sequence[Mapping[str, Any]],
        input_tokens: int,
        *, additional_tokens: int = 0,
    ) -> None:
        if input_tokens > 0:
            self._provider_usage = ProviderUsageObservation(input_tokens,
                                                           estimate_tokens(messages) + additional_tokens)
            self._calibration.observe(input_tokens, self._provider_usage.heuristic_tokens)

    def restore_checkpoint(self, payload: Mapping[str, Any]) -> None:
        if payload.get("reasoning_replay", "preserve") == self.reasoning_replay:
            self._active.restore(payload)
        self._calibration.restore(payload.get("token_calibration") or {})
        usage = self._calibration.restore(payload.get("provider_usage") or {})
        if usage is not None:
            self._provider_usage = ProviderUsageObservation(*usage)

    def checkpoint_payload(
        self,
        provider_context: ProviderContext,
        source_messages: Sequence[Mapping[str, Any]],
    ) -> Mapping[str, Any]:
        payload = dict(provider_context.checkpoint or {})
        payload.update(checkpoint_schema_version="1.0",
                       source_messages=[dict(message) for message in source_messages],
                       provider_messages=[dict(message) for message in provider_context.messages],
                       estimated_tokens=provider_context.estimated_tokens,
                       tokens_before=provider_context.tokens_before,
                       omitted_messages=provider_context.omitted_messages,
                       estimate_source=provider_context.estimate_source,
                       provider_input_tokens=provider_context.provider_input_tokens,
                       reasoning_replay=self.reasoning_replay,
                       token_calibration=asdict(self._calibration))
        payload["provider_usage"] = asdict(self._provider_usage) if self._provider_usage else None
        return payload

    def remember_compaction(self, source, provider) -> None:
        if self.uses_active_context:
            self._active.remember(source, provider)

    async def project(
        self,
        messages: Sequence[Mapping[str, Any]],
        context: RuntimeContext,
        *,
        additional_tokens: int = 0,
        force: bool = False,
    ) -> ProviderContext:
        active = self._active.project(messages) if self.uses_active_context else messages
        projected = tuple(dict(message) for message in active)
        for transformer in self.transformers:
            value = transformer.transform(projected, context)
            if inspect.isawaitable(value):
                value = await value
            projected = tuple(dict(message) for message in value)
        projected = project_reasoning_messages(projected, self.reasoning_replay)
        estimate = self.estimate(projected)
        decision = None
        if self.decision_policy is not None:
            value = self.decision_policy(
                ContextProjectionRequest(tuple(messages), projected, estimate, context)
            )
            decision = await value if inspect.isawaitable(value) else value
            if decision is not None and decision.cancel:
                raise RuntimeError(f"context projection cancelled: {decision.reason or 'policy'}")
            if decision is not None and decision.messages is not None:
                projected = project_reasoning_messages(decision.messages, self.reasoning_replay)
                estimate = self.estimate(projected)
        policy = self.compaction
        limit = max(0, policy.max_context_tokens - policy.reserve_tokens - additional_tokens)
        if not policy.enabled or not limit or (not force and estimate.tokens <= limit):
            return estimate.project(projected, tokens_before=estimate.tokens)
        protected = decision.protected_segments if decision is not None else ()
        compacted, omitted, summary, boundary = self._compact(
            projected, target=min(limit, policy.keep_recent_tokens), protected=protected
        )
        compacted_estimate = self.estimate(compacted)
        if force and (not omitted or compacted_estimate.tokens >= estimate.tokens):
            return estimate.project(projected, tokens_before=estimate.tokens)
        usage = self._provider_usage
        checkpoint = {
            "checkpoint_schema_version": "1.0",
            "trigger": "manual" if force else "automatic",
            "summary": dict(summary),
            "source_message_boundary": {"start": boundary[0], "end": boundary[1]},
            "tokens_before": estimate.tokens,
            "retained_tail": [dict(message) for message in compacted[boundary[2] :]],
            "policy": asdict(policy),
            "estimate": asdict(compacted_estimate),
            "provider_usage": asdict(usage) if usage is not None else None,
        }
        if decision is not None:
            checkpoint["decision"] = {
                "reason": decision.reason,
                "protected_segments": [asdict(item) for item in protected],
                "metadata": dict(decision.checkpoint_metadata or {}),
            }
        return compacted_estimate.project(compacted, compacted=True, omitted_messages=omitted,
                                         tokens_before=estimate.tokens, checkpoint=checkpoint)
