from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import asdict, replace
from typing import Any

from inquirycraft.events import RuntimeEvent
from inquirycraft.llm import (
    CompletionRequest,
    CompletionResult,
    LLMClient,
    SameRoundRetryPolicy,
    Usage,
)

from .cancellation import CancellationToken
from .hooks import AgentHooks, RuntimeContext
from .llm_retry import LLMRetryAdapter, LLMRetryRequest, resolve_retry_request
from .operations import JsonlOperationJournal
from .provider import (
    ProviderObservation,
    ProviderObserver,
    correlate_completion_request,
    llm_intent_payload,
    llm_settled_payload,
    publish_provider_observation,
)
from .streaming import StreamAssembler, StreamOutputGuard

Emit = Callable[[str, Mapping[str, Any] | None, str | None], Awaitable[RuntimeEvent]]


class RuntimeLLMPipeline:
    def __init__(
        self,
        *,
        llm: LLMClient,
        context: RuntimeContext,
        hooks: AgentHooks,
        emit: Emit,
        cancellation: CancellationToken,
        streaming: bool,
        stream_guard: StreamOutputGuard | None = None,
        journal: JsonlOperationJournal | None = None,
        retry_policy: SameRoundRetryPolicy | None = None,
        retry_adapter: LLMRetryAdapter | None = None,
        provider_observer: ProviderObserver | None = None,
    ) -> None:
        self.llm = llm
        self.context = context
        self.hooks = hooks
        self.emit = emit
        self.cancellation = cancellation
        self.streaming = streaming
        self.stream_guard = stream_guard
        self.journal = journal
        self.retry_policy = retry_policy
        self.retry_adapter = retry_adapter
        self.provider_observer = provider_observer
        self._stream_ttft_sec: float | None = None

    async def complete(
        self,
        request: CompletionRequest,
        *,
        parent_event_id: str,
    ) -> CompletionResult:
        current = request
        attempt = 0
        while True:
            try:
                return await self._complete_once(current, parent_event_id=parent_event_id, attempt=attempt + 1)
            except BaseException as exc:
                replacement = await self._replacement_request(exc, attempt, current)
                if replacement is None:
                    await self.emit(
                        "llm.failed",
                        {"error_type": type(exc).__name__, "error": str(exc)},
                        parent_event_id,
                    )
                    raise
                delay = self.retry_policy.delay_after(attempt) if self.retry_policy else 0.0
                await self.emit(
                    "llm.retrying",
                    {
                        "attempt": attempt + 1,
                        "next_attempt": attempt + 2,
                        "delay_sec": delay,
                        "error_type": type(exc).__name__,
                        "error": str(exc),
                    },
                    parent_event_id,
                )
                await publish_provider_observation(
                    self.provider_observer,
                    ProviderObservation(
                        phase="retrying",
                        model=current.model,
                        attempt=attempt + 1,
                        error_type=type(exc).__name__,
                        error=str(exc),
                        metadata=correlate_completion_request(self.context, current).metadata,
                    ),
                    self.context,
                )
                if delay > 0:
                    await self._cancellable(asyncio.sleep(delay))
                current = replacement
                attempt += 1

    async def _replacement_request(
        self,
        error: BaseException,
        attempt: int,
        request: CompletionRequest,
    ) -> CompletionRequest | None:
        if self.retry_policy is None or self.retry_adapter is None:
            return None
        if not self.retry_policy.can_retry(attempt):
            return None
        retry = LLMRetryRequest(error, attempt, request, self.context)
        return await resolve_retry_request(self.retry_adapter, retry)

    async def _complete_once(
        self,
        request: CompletionRequest,
        *,
        parent_event_id: str,
        attempt: int,
    ) -> CompletionResult:
        provider_request = request
        audit_request = correlate_completion_request(self.context, request)
        await self.hooks.before_llm(audit_request, self.context)
        requested = await self.emit(
            "llm.requested",
            {
                "message_count": len(provider_request.messages),
                "tool_count": len(provider_request.tools),
            },
            parent_event_id,
        )
        audit_request = replace(audit_request, metadata={**audit_request.metadata, "request_id": requested.event_id})
        step_id = f"llm:{self.context.turn_id}"
        journal_attempt = self.journal.next_attempt("llm", step_id) if self.journal else attempt
        if self.journal is not None:
            self.journal.append(
                "llm",
                "intent",
                step_id=step_id,
                attempt=journal_attempt,
                payload=llm_intent_payload(provider_request, audit_request),
            )
        started_at = time.monotonic()
        self._stream_ttft_sec = None
        try:
            result = (
                await self._stream(provider_request, requested.event_id)
                if self.streaming
                else await self._cancellable(self.llm.complete(provider_request))
            )
        except BaseException as exc:
            usage = getattr(exc, "usage", None) or Usage()
            await publish_provider_observation(
                self.provider_observer,
                ProviderObservation(
                    phase="failed",
                    model=provider_request.model,
                    attempt=attempt,
                    elapsed_sec=time.monotonic() - started_at,
                    ttft_sec=self._stream_ttft_sec,
                    error_type=type(exc).__name__,
                    error=str(exc),
                    usage=usage,
                    finish_reason=getattr(exc, "finish_reason", "unknown"),
                    metadata={
                        **audit_request.metadata,
                        "pool_index": getattr(exc, "pool_index", None),
                    },
                ),
                self.context,
            )
            await self.emit(
                "llm.attempt.failed",
                {
                    "error_type": type(exc).__name__,
                    "error": str(exc),
                    **asdict(usage),
                    "usage_known": getattr(exc, "usage", None) is not None,
                    "failure_phase": getattr(exc, "phase", "provider"),
                    "finish_reason": getattr(exc, "finish_reason", "unknown"),
                },
                requested.event_id,
            )
            raise
        elapsed = time.monotonic() - started_at
        output_tokens = result.usage.output_tokens
        tpot = (
            max(0.0, elapsed - self._stream_ttft_sec) / max(1, output_tokens - 1)
            if self._stream_ttft_sec is not None and output_tokens > 1
            else None
        )
        await publish_provider_observation(
            self.provider_observer,
            ProviderObservation(
                phase="completed",
                model=provider_request.model,
                attempt=attempt,
                elapsed_sec=elapsed,
                ttft_sec=self._stream_ttft_sec,
                tpot_sec=tpot,
                route=str(audit_request.metadata.get("route") or ""),
                usage=result.usage,
                finish_reason=result.finish_reason,
                tool_call_count=len(result.tool_calls),
                tool_names=tuple(
                    str((call.get("function") or {}).get("name") or "")
                    for call in result.tool_calls
                ),
                metadata={**audit_request.metadata, "pool_index": result.pool_index},
            ),
            self.context,
        )
        await self.hooks.after_llm(result, self.context)
        if self.journal is not None:
            self.journal.append(
                "llm",
                "settled",
                step_id=step_id,
                attempt=journal_attempt,
                payload=llm_settled_payload(result, audit_request),
            )
        await self.emit(
            "llm.completed",
            {
                "finish_reason": result.finish_reason,
                **asdict(result.usage),
                "tool_call_count": len(result.tool_calls),
            },
            requested.event_id,
        )
        return result

    async def _cancellable(self, operation: Awaitable[Any]) -> Any:
        completion = asyncio.create_task(operation)
        waiters = completion, asyncio.create_task(self.cancellation.wait())
        try:
            await asyncio.wait(waiters, return_when=asyncio.FIRST_COMPLETED)
            self.cancellation.raise_if_cancelled()
            return completion.result()
        finally:
            # The caller itself may be cancelled (for example by an outer
            # wall-clock timeout) while ``anext()`` is still running.  Reap
            # both child tasks before the stream iterator's ``aclose()`` runs;
            # otherwise Python tries to close an async generator that still
            # has an active ``__anext__`` and raises a misleading RuntimeError.
            for waiter in waiters:
                waiter.cancel()
            await asyncio.gather(*waiters, return_exceptions=True)

    async def _stream(self, request: CompletionRequest, parent_id: str) -> CompletionResult:
        started = await self.emit("message.started", {"role": "assistant"}, parent_id)
        stream_started = time.monotonic()
        assembler = StreamAssembler()
        if self.stream_guard is not None:
            self.stream_guard.reset()
        try:
            async for chunk in self._cancellable_chunks(request):
                if self._stream_ttft_sec is None:
                    self._stream_ttft_sec = time.monotonic() - stream_started
                assembler.add(chunk)
                channels = (
                    ("content", chunk.content),
                    ("reasoning", chunk.reasoning_content),
                    ("tool_preview", chunk.tool_call_preview),
                    ("tool_call", dict(chunk.tool_call_delta) if chunk.tool_call_delta else None),
                )
                for channel, delta in channels:
                    if delta:
                        if channel != "tool_call":
                            self._check_guard(channel, delta)
                        await self.emit(
                            "message.delta", {"channel": channel, "delta": delta}, started.event_id,
                        )
        except BaseException as exc:
            partial = assembler.result()
            await self.emit(
                "message.failed",
                {
                    "error_type": type(exc).__name__,
                    "error": str(exc),
                    "message": {
                        "role": "assistant",
                        "content": partial.content,
                        "reasoning_content": partial.reasoning_content,
                        "tool_calls": [dict(call) for call in partial.tool_calls],
                    },
                },
                started.event_id,
            )
            raise
        result = assembler.result()
        await self.emit(
            "message.completed",
            {
                "finish_reason": result.finish_reason,
                "content_chars": len(result.content),
                "tool_call_count": len(result.tool_calls),
            },
            started.event_id,
        )
        return result

    async def _cancellable_chunks(self, request: CompletionRequest):
        iterator = self.llm.stream(request).__aiter__()
        try:
            while True:
                try:
                    yield await self._cancellable(anext(iterator))
                except StopAsyncIteration:
                    break
        finally:
            close = getattr(iterator, "aclose", None)
            if close is not None:
                await close()

    def _check_guard(self, channel: str, text: str) -> None:
        if self.stream_guard is None:
            return
        hit = self.stream_guard.feed(channel, text)
        if hit is not None:
            raise RuntimeError(f"Stream guard stopped output: {hit.reason} ({hit.detail})")
