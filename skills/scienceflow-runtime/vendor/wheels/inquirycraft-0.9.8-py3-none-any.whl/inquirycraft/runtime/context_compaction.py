"""Deterministic compaction and tool-pair preservation, independent of chat state."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import TYPE_CHECKING, Any

from .token_estimation import estimate_tokens

if TYPE_CHECKING:
    from .context import ProtectedContextSegment


class ContextCompactionMixin:
    def _compact(
        self, messages: tuple[Mapping[str, Any], ...], *, target: int,
        protected: Sequence[ProtectedContextSegment] = (),
    ) -> tuple[tuple[Mapping[str, Any], ...], int, Mapping[str, Any], tuple[int, int, int]]:
        system = messages[:1] if messages and messages[0].get("role") == "system" else ()
        start = len(messages)
        tokens = 0
        floor = len(system)
        tail_target = max(1, target * 2 // 3)
        while start > floor:
            candidate = messages[start - 1]
            candidate_tokens = estimate_tokens((candidate,))
            if tokens and tokens + candidate_tokens > tail_target:
                break
            tokens += candidate_tokens
            start -= 1
        while start > floor and messages[start].get("role") == "tool":
            start -= 1
        keep = set(range(start, len(messages))) | set(range(len(system)))
        for segment in protected:
            keep.update(range(max(floor, segment.start), min(len(messages), segment.end)))
        self._include_tool_pairs(messages, keep)
        omitted_rows = tuple(message for index, message in enumerate(messages) if index not in keep)
        retained = tuple(message for index, message in enumerate(messages) if index in keep)
        summary = self._summary(omitted_rows, max_chars=max(80, target * 4 // 3))
        return ((*system, summary, *retained[len(system):]), len(omitted_rows), summary,
                (floor, start, len(system) + 1))

    @staticmethod
    def _include_tool_pairs(messages: Sequence[Mapping[str, Any]], keep: set[int]) -> None:
        call_owner = {str(call['id']): index for index, message in enumerate(messages)
                      for call in message.get('tool_calls') or () if call.get('id')}
        result_owner = {str(message['tool_call_id']): index for index, message in enumerate(messages)
                        if message.get('role') == 'tool' and message.get('tool_call_id')}
        changed = True
        while changed:
            before = len(keep)
            for index in tuple(keep):
                message = messages[index]
                if message.get("role") == "tool":
                    owner = call_owner.get(str(message.get("tool_call_id") or ""))
                    if owner is not None:
                        keep.add(owner)
                for call in message.get("tool_calls") or ():
                    result = result_owner.get(str(call.get("id") or ""))
                    if result is not None:
                        keep.add(result)
            changed = len(keep) != before

    @staticmethod
    def _summary(messages: Sequence[Mapping[str, Any]], *, max_chars: int) -> Mapping[str, Any]:
        lines = []
        for message in messages:
            role = str(message.get("role", "unknown"))
            content = str(message.get("content", "")).replace("\n", " ")[:240]
            lines.append(f"{role}: {content}")
        text = "\n".join(lines)[:max_chars]
        return {"role": "system",
                "content": "Compacted earlier conversation (deterministic projection):\n" + text}
