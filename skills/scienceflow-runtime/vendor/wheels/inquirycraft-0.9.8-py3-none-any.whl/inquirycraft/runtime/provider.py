from __future__ import annotations

import inspect
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import asdict, dataclass, field, replace
from typing import Any, Literal

from inquirycraft.llm import CompletionRequest, CompletionResult, Usage
from inquirycraft.memory import coerce_message

from .hooks import RuntimeContext


@dataclass(frozen=True, slots=True)
class ProviderObservation:
    phase: Literal["completed", "failed", "retrying"]
    model: str
    attempt: int
    elapsed_sec: float = 0.0
    ttft_sec: float | None = None
    tpot_sec: float | None = None
    route: str = ""
    usage: Usage = field(default_factory=Usage)
    error_type: str = ""
    error: str = ""
    finish_reason: str = ""
    tool_call_count: int = 0
    tool_names: tuple[str, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)


ProviderObserver = Callable[[ProviderObservation, RuntimeContext], None | Awaitable[None]]


def prepare_call_correlation(
    context: RuntimeContext,
    request_metadata: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Bind the active turn to one immutable logical provider-call identity."""
    metadata = dict(request_metadata or {})
    request_correlation = dict(metadata.get("correlation") or {})
    correlation = dict(context.metadata.get("correlation") or {})
    correlation.update(request_correlation)
    correlation.update(
        {
            "run_id": context.run_id,
            "session_id": context.session_id,
            "worker_id": context.agent_id,
            "turn_id": context.turn_id,
            "call_id": f"{context.session_id}:llm:{context.turn_id}",
        }
    )
    for name in ("stage_id", "lineage_id", "node_uid"):
        value = metadata.get(name) or request_correlation.get(name) or context.metadata.get(name)
        if value not in (None, ""):
            correlation[name] = value
        else:
            correlation.pop(name, None)
    context.metadata["call_id"] = correlation["call_id"]
    context.metadata["correlation"] = correlation
    return correlation


def correlate_completion_request(
    context: RuntimeContext,
    request: CompletionRequest,
) -> CompletionRequest:
    """Return an audit request carrying the active logical-call correlation."""
    metadata = dict(request.metadata)
    correlation = prepare_call_correlation(context, metadata)
    metadata["call_id"] = correlation["call_id"]
    metadata["correlation"] = correlation
    return replace(request, metadata=metadata)


async def publish_provider_observation(
    observer: ProviderObserver | None,
    observation: ProviderObservation,
    context: RuntimeContext,
) -> None:
    if observer is None:
        return
    value = observer(observation, context)
    if inspect.isawaitable(value):
        await value


def llm_intent_payload(
    provider_request: CompletionRequest,
    audit_request: CompletionRequest,
) -> dict[str, Any]:
    """Serialize the replayable provider input and its audit classification."""
    metadata = audit_request.metadata
    system_messages = tuple(metadata.get("system_msgs") or ())
    return {
        "model": provider_request.model,
        "system_messages": [coerce_message(message).to_dict() for message in system_messages],
        "provider_messages": [dict(message) for message in provider_request.messages],
        "call_kind": metadata.get("call_kind", "agent"),
        "turn_kind": metadata.get("turn_kind"),
        "route": metadata.get("route"),
        "llm_role": metadata.get("llm_role"),
        "correlation": dict(metadata.get("correlation") or {}),
    }


def llm_settled_payload(
    result: CompletionResult,
    audit_request: CompletionRequest,
) -> dict[str, Any]:
    """Serialize the complete assistant result for replay and training export."""
    return {
        "finish_reason": result.finish_reason,
        "correlation": dict(audit_request.metadata.get("correlation") or {}),
        "message": {
            "role": "assistant",
            "content": result.content,
            "tool_calls": [dict(call) for call in result.tool_calls],
            **({"reasoning_content": result.reasoning_content} if result.reasoning_content else {}),
        },
        "usage": asdict(result.usage),
    }
