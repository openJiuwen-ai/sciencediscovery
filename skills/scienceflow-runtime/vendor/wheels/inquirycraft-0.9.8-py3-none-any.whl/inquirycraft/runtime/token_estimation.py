"""Dependency-free estimates calibrated conservatively by actual provider usage."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any


def estimate_tokens(messages: Sequence[Mapping[str, Any]]) -> int:
    chars = sum(len(str(value)) for message in messages for value in message.values())
    return max(1, (chars + 3) // 4)


@dataclass
class TokenCalibration:
    """Keep the highest observed density; compaction must not lower the safety bound."""

    input_tokens: int = 1
    heuristic_tokens: int = 1

    def observe(self, input_tokens: int, heuristic_tokens: int) -> None:
        if input_tokens > 0 and heuristic_tokens > 0:
            if input_tokens * self.heuristic_tokens > self.input_tokens * heuristic_tokens:
                self.input_tokens, self.heuristic_tokens = input_tokens, heuristic_tokens

    def estimate(self, heuristic: int) -> int:
        return max(1, (heuristic * self.input_tokens + self.heuristic_tokens - 1)
                   // self.heuristic_tokens)

    def restore(self, payload: Mapping[str, Any]) -> tuple[int, int] | None:
        try:
            pair = int(payload.get("input_tokens", 0)), int(payload.get("heuristic_tokens", 0))
        except (AttributeError, TypeError, ValueError):
            return None
        if min(pair) > 0:
            self.observe(*pair)
            return pair
        return None
