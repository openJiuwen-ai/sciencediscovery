from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal, Mapping, cast
from uuid import uuid4

QueueName = Literal["steer", "follow_up", "next_run"]
DrainMode = Literal["one-at-a-time", "all"]


@dataclass(frozen=True, slots=True)
class QueuedMessage:
    id: str
    queue: QueueName
    content: str


class RuntimeMessageQueues:
    def __init__(self, *, drain_mode: DrainMode = "all") -> None:
        self.drain_mode = drain_mode
        self._items: dict[QueueName, list[QueuedMessage]] = {
            "steer": [],
            "follow_up": [],
            "next_run": [],
        }

    def put(self, queue: QueueName, content: str) -> QueuedMessage:
        if not content.strip():
            raise ValueError("Queued message cannot be empty")
        item = QueuedMessage(f"msg_{uuid4().hex}", queue, content)
        self._items[queue].append(item)
        return item

    def restore(self, item: QueuedMessage) -> None:
        if item.id not in {existing.id for existing in self.pending()}:
            self._items[item.queue].append(item)

    def restore_journal(self, rows: tuple[Mapping[str, Any], ...]) -> None:
        latest: dict[str, Mapping[str, Any]] = {}
        for row in rows:
            if row.get("kind") == "queue":
                latest[str(row.get("step_id"))] = row
        for message_id, row in latest.items():
            if row.get("phase") != "accepted":
                continue
            payload = row.get("payload") or {}
            queue = str(payload.get("queue"))
            if queue in self._items:
                self.restore(
                    QueuedMessage(
                        message_id,
                        cast(QueueName, queue),
                        str(payload.get("content", "")),
                    )
                )

    def drain(self, queue: QueueName) -> tuple[QueuedMessage, ...]:
        items = self._items[queue]
        count = 1 if self.drain_mode == "one-at-a-time" else len(items)
        drained = tuple(items[:count])
        del items[:count]
        return drained

    def pending(self, queue: QueueName | None = None) -> tuple[QueuedMessage, ...]:
        if queue is not None:
            return tuple(self._items[queue])
        return tuple(item for name in self._items for item in self._items[name])

    def cancel(self, message_id: str) -> bool:
        for items in self._items.values():
            for index, item in enumerate(items):
                if item.id == message_id:
                    del items[index]
                    return True
        return False
