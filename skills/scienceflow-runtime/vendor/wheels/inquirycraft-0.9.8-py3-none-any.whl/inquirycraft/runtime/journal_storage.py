"""Streaming journal recovery with a compact, latest-state in-memory index."""

from __future__ import annotations

import json
from collections.abc import Mapping
from copy import deepcopy
from pathlib import Path
from typing import Any

OPERATION_SCHEMA_VERSION = '2.0'
TERMINAL_PHASES = frozenset({'cancelled', 'completed', 'failed', 'suspended'})


class JournalStorage:
    def __init__(self, path: str | Path, *, operation_id: str) -> None:
        from inquirycraft.memory.file_lock import exclusive_file_lock

        self.path = Path(path).expanduser().resolve()
        self._index: dict[tuple[str, str], dict[str, Any]] = {}
        self._projection_messages: list[Mapping[str, Any]] = []
        self._projection_sequence = self._sequence = 0
        self._lock_path = self.path.with_name(self.path.name + '.append.lock')
        with exclusive_file_lock(self._lock_path):
            self._load()
            self._loaded_size = self.path.stat().st_size if self.path.exists() else 0
        self.operation_id = str(self._rows[-1].get('operation_id')) if self._rows else operation_id

    @property
    def _rows(self) -> tuple[dict[str, Any], ...]:
        return tuple(dict(sorted((row['sequence'], row) for row in self._index.values())).values())

    def _remember(self, row: dict[str, Any]) -> None:
        kind, phase = row.get('kind'), row.get('phase')
        payload = row.get('payload') or {}
        if kind == 'projection':
            if phase == 'delta':
                self._validate_delta(payload)
                messages = [*self._projection_messages, *payload['appended_messages']]
                row = {**row, 'payload': {**payload, 'messages': messages}}
            else:
                messages = payload.get('messages', [])
            self._projection_messages = messages
            self._projection_sequence = int(row['sequence'])
        if kind == 'operation' and phase in TERMINAL_PHASES:
            projection = payload.get('projection') or {}
            if isinstance(projection.get('messages'), list):
                self._projection_messages = projection['messages']
                self._projection_sequence = int(row['sequence'])
            self._index[('terminal', '')] = row
        key = (str(kind), '' if kind in {'projection', 'context'} else str(row.get('step_id', '')))
        self._index[key] = row
        self._sequence = max(self._sequence, int(row.get('sequence', 0)))

    def _validate_delta(self, payload) -> None:
        if (payload.get('base_sequence'), payload.get('base_message_count')) != (
                self._projection_sequence, len(self._projection_messages)):
            raise ValueError('Projection delta does not match its durable base')
        appended = payload.get('appended_messages')
        if not isinstance(appended, list) or not all(isinstance(message, Mapping) for message in appended):
            raise ValueError('Projection delta requires a list of appended messages')

    def _load(self) -> None:
        if not self.path.exists():
            return
        with self.path.open('rb') as stream:
            valid_offset = 0
            for line in stream:
                try:
                    row = json.loads(line)
                except (json.JSONDecodeError, UnicodeDecodeError):
                    if line.endswith((b'\n', b'\r')):
                        raise ValueError(f'Invalid operation journal while reopening {self.path}')
                    with self.path.open('r+b') as handle:
                        handle.truncate(valid_offset)
                    break
                if not isinstance(row, dict) or row.get('schema_version') not in {'1.0', OPERATION_SCHEMA_VERSION}:
                    raise ValueError(f'Unsupported operation journal schema in {self.path}')
                self._remember(row)
                valid_offset += len(line)
                if not line.endswith((b'\n', b'\r')):
                    with self.path.open('ab') as handle:
                        handle.write(b'\n')
                    break

    @property
    def rows(self) -> tuple[Mapping[str, Any], ...]:
        """Explicit full audit view; normal recovery uses the compact index."""
        if not self.path.exists():
            return ()
        with self.path.open('rb') as stream:
            return tuple(json.loads(line) for line in stream)

    @property
    def recovery_rows(self) -> tuple[Mapping[str, Any], ...]:
        return deepcopy(self._rows)
