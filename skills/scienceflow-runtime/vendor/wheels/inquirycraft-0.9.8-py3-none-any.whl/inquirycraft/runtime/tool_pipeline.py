from __future__ import annotations

import inspect
from collections.abc import Awaitable, Callable, Mapping, Sequence
from typing import Any

from inquirycraft.events import RuntimeEvent
from inquirycraft.memory import Message
from inquirycraft.tools import (
    ToolBundleMode,
    ToolCollection,
    ToolContext,
    ToolExecutionEngine,
    ToolExecutionRecord,
    ToolPostprocessDecision,
    ToolPreflightDecision,
    ToolResult,
)
from inquirycraft.tools.output_processing import ToolOutputProcessor
from inquirycraft.tools.validation import ToolArgumentValidator

from .hooks import AgentHooks, RuntimeContext, ToolCommitDecision, ToolCommitObservation
from .operations import JsonlOperationJournal

Emit = Callable[[str, Mapping[str, Any] | None, str | None], Awaitable[RuntimeEvent]]
Append = Callable[[Message], None]
ToolBundlePolicy = Callable[
    [Sequence[Any], RuntimeContext], ToolBundleMode | Awaitable[ToolBundleMode]
]
ToolCallTransformer = Callable[
    [Sequence[Any], RuntimeContext], Sequence[Any] | Awaitable[Sequence[Any]]
]
_PARALLEL_MODES = {"parallel_readonly", "parallel_bash"}


class RuntimeToolPipeline:
    """Runtime adapter around the canonical validated tool execution engine."""

    def __init__(
        self,
        *,
        tools: ToolCollection,
        context: RuntimeContext,
        hooks: AgentHooks,
        emit: Emit,
        append: Append,
        concurrent: bool,
        journal: JsonlOperationJournal | None = None,
        validator: ToolArgumentValidator | None = None,
        output_processor: ToolOutputProcessor | None = None,
        bundle_policy: ToolBundlePolicy | None = None,
        call_transformer: ToolCallTransformer | None = None,
        validate_arguments: bool = True,
    ) -> None:
        self.tools = tools
        self.context = context
        self.hooks = hooks
        self.emit = emit
        self.append = append
        self.concurrent = concurrent
        self.journal = journal
        self.output_processor = output_processor
        self.bundle_policy = bundle_policy
        self.call_transformer = call_transformer
        self.validate_arguments = validate_arguments
        self.recovering = False
        self._bundle_mode: ToolBundleMode = "single"
        self.engine = ToolExecutionEngine(tools, validator=validator)

    async def execute(
        self, calls: Sequence[Any], *, recovering: bool = False
    ) -> list[ToolExecutionRecord]:
        self.recovering = recovering
        mode = await self._plan(calls)
        if len(calls) > 1:
            await self.emit("tool.bundle.planned", {"mode": mode, "count": len(calls)}, None)
        self._bundle_mode = mode
        try:
            records = await self.engine.execute(
                calls,
                concurrent=mode in _PARALLEL_MODES,
                validate_arguments=self.validate_arguments,
                strict_arguments=True,
                before_execute=self._before,
                after_execute=self._after,
                on_complete=self._completed,
                context_factory=self._context_for,
                on_start=self._started,
                finalize=self._finalize,
            )
        finally:
            self.recovering = False
            self._bundle_mode = "single"
        for record in records:
            result = record.result or ToolResult(error="Tool produced no result")
            message = Message(
                "tool",
                result.render(),
                name=record.invocation.name,
                tool_call_id=record.invocation.id,
            )
            self.append(message)
            await self.emit(
                "memory.appended",
                {"role": "tool", "name": record.invocation.name},
                None,
            )
            await self._after_commit(record, message, mode=mode, recovering=recovering)
        return records

    async def transform_calls(self, calls: Sequence[Any]) -> tuple[Any, ...]:
        if self.call_transformer is None:
            return tuple(calls)
        transformed = self.call_transformer(calls, self.context)
        value = await transformed if inspect.isawaitable(transformed) else transformed
        return tuple(value)

    async def _plan(self, calls: Sequence[Any]) -> ToolBundleMode:
        if len(calls) <= 1:
            return "single"
        if self.bundle_policy is None:
            return "parallel_readonly" if self.concurrent else "sequential"
        value = self.bundle_policy(calls, self.context)
        mode = await value if inspect.isawaitable(value) else value
        if mode not in {
            "single",
            "parallel_readonly",
            "parallel_bash",
            "blocked_write_edit_bundle",
            "sequential",
        }:
            raise ValueError(f"Unsupported tool bundle mode: {mode}")
        return mode

    async def _before(self, record: ToolExecutionRecord) -> ToolPreflightDecision | None:
        step_id = f"tool:{record.invocation.id}"
        tool = self.tools.get_tool(record.invocation.name)
        latest = self.journal.latest("tool", step_id) if self.journal is not None else None
        if self.recovering and latest is not None and latest.get("phase") == "settled":
            payload = latest.get("payload") or {}
            rendered = str(payload.get("rendered", ""))
            recovered = ToolResult(
                error=rendered.removeprefix("Error: ") if payload.get("is_error") else None,
                output=None if payload.get("is_error") else rendered,
            )
            return ToolPreflightDecision(result=recovered)
        if (
            self.recovering
            and self.journal is not None
            and self.journal.is_unsettled("tool", step_id)
            and getattr(tool, "replay_policy", "never") == "never"
        ):
            return ToolPreflightDecision(
                block=True,
                reason="Interrupted tool has unknown effects and replay_policy='never'",
            )
        decision = await self.hooks.before_tool(record.invocation, self.context)
        requested = await self.emit(
            "tool.requested",
            {"tool_call_id": record.invocation.id, "name": record.invocation.name},
            None,
        )
        record.metadata["requested_event_id"] = requested.event_id
        if self._bundle_mode == "blocked_write_edit_bundle":
            return ToolPreflightDecision(
                block=True,
                reason="Tool bundle blocked by execution policy",
            )
        return decision

    async def _started(self, record: ToolExecutionRecord) -> None:
        step_id = f"tool:{record.invocation.id}"
        tool = self.tools.get_tool(record.invocation.name)
        requested_id = record.metadata.get("requested_event_id")
        await self.emit(
            "tool.started",
            {"tool_call_id": record.invocation.id, "name": record.invocation.name},
            str(requested_id) if requested_id else None,
        )
        if self.journal is not None:
            attempt = self.journal.next_attempt("tool", step_id)
            record.metadata["journal_attempt"] = attempt
            self.journal.append(
                "tool",
                "intent",
                step_id=step_id,
                attempt=attempt,
                payload={
                    "name": record.invocation.name,
                    "replay_policy": getattr(tool, "replay_policy", "never"),
                    "correlation": dict(self.context.metadata.get("correlation") or {}),
                },
            )

    def _context_for(self, record: ToolExecutionRecord) -> ToolContext:
        async def update(chunk: str) -> None:
            await self.hooks.on_tool_stream(chunk, self.context)
            await self.emit(
                "tool.progress",
                {
                    "tool_call_id": record.invocation.id,
                    "name": record.invocation.name,
                    "chunk": chunk,
                },
                record.metadata.get("requested_event_id"),
            )

        return ToolContext(
            session_id=self.context.session_id,
            run_id=self.context.run_id,
            agent_id=self.context.agent_id,
            workspace=self.context.workspace,
            event_sink=self.context.event_sink,
            cancellation=self.context.cancellation,
            metadata=self.context.metadata,
            on_update=update,
        )

    async def _after(
        self, record: ToolExecutionRecord
    ) -> ToolResult | ToolPostprocessDecision | None:
        record.metadata["raw_result"] = record.result
        return await self.hooks.after_tool(record.invocation, record.result, self.context)

    async def _finalize(self, record: ToolExecutionRecord) -> ToolResult | None:
        if self.output_processor is None or record.result is None:
            return None
        return self.output_processor.process(
            tool_name=record.invocation.name,
            arguments=record.invocation.arguments,
            result=record.result,
        )

    async def _completed(self, record: ToolExecutionRecord) -> None:
        result = record.result or ToolResult(error="Tool produced no result")
        requested_id = record.metadata.get("requested_event_id")
        if not requested_id:
            requested = await self.emit(
                "tool.requested",
                {"tool_call_id": record.invocation.id, "name": record.invocation.name},
                None,
            )
            requested_id = requested.event_id
        rendered = result.render()
        if self.journal is not None and not record.metadata.get("recovered"):
            step_id = f"tool:{record.invocation.id}"
            attempt = int(record.metadata.get("journal_attempt", 1))
            self.journal.append(
                "tool",
                "settled",
                step_id=step_id,
                attempt=attempt,
                payload={
                    "is_error": result.is_error,
                    "blocked": record.blocked,
                    "rendered": rendered,
                    "raw_output_artifact": result.metadata.get("raw_output_artifact"),
                    "shell_execution": result.metadata.get("shell_execution"),
                    "correlation": dict(self.context.metadata.get("correlation") or {}),
                    "message": {
                        "role": "tool",
                        "content": rendered,
                        "name": record.invocation.name,
                        "tool_call_id": record.invocation.id,
                    },
                },
            )
        event_payload = {
            "tool_call_id": record.invocation.id,
            "name": record.invocation.name,
            "output_bytes": len(rendered.encode("utf-8")),
            "preview": rendered[:1000],
        }
        if record.blocked:
            event_payload["blocked"] = True
        if execution := result.metadata.get("shell_execution"):
            event_payload["shell_execution"] = dict(execution)
        if record.terminate:
            event_payload["terminate"] = True
        if error_category := record.metadata.get("error_category"):
            event_payload["error_category"] = error_category
        completed = await self.emit(
            "tool.failed" if result.is_error else "tool.completed",
            event_payload,
            str(requested_id),
        )
        record.metadata["settled_event_id"] = completed.event_id
        if self.journal is not None:
            latest = self.journal.latest("tool", f"tool:{record.invocation.id}")
            if latest is not None:
                record.metadata["journal_sequence"] = int(latest.get("sequence", 0) or 0)
                record.metadata.setdefault("journal_attempt", int(latest.get("attempt", 0) or 0))

    async def _after_commit(
        self,
        record: ToolExecutionRecord,
        message: Message,
        *,
        mode: ToolBundleMode,
        recovering: bool,
    ) -> None:
        result = record.result or ToolResult(error="Tool produced no result")
        observation = ToolCommitObservation(
            call=record.call,
            invocation=record.invocation,
            raw_result=record.metadata.get("raw_result") or result,
            result=result,
            message=message,
            bundle_index=record.index,
            bundle_mode=mode,
            recovering=recovering,
            replayed=recovering and not bool(record.metadata.get("recovered")),
            journal_attempt=int(record.metadata.get("journal_attempt", 0) or 0),
            journal_sequence=int(record.metadata.get("journal_sequence", 0) or 0),
            settled_event_id=str(record.metadata.get("settled_event_id") or ""),
        )
        decision = await self.hooks.after_tool_commit(observation, self.context)
        if decision is None:
            return
        if not isinstance(decision, ToolCommitDecision):
            raise TypeError("after_tool_commit must return ToolCommitDecision or None")
        record.metadata["post_commit_decision"] = decision
        record.terminate = record.terminate or decision.action == "terminate_session"
        if decision.reason:
            self.context.metadata["tool_commit_reason"] = decision.reason
        if decision.route:
            self.context.metadata["route"] = decision.route
        for injected in decision.inject_messages:
            self.append(injected)
            await self.emit(
                "memory.appended",
                {"role": injected.role, "injected": True, "source": "tool_commit"},
                None,
            )
        await self.emit(
            "tool.commit.observed",
            {
                "tool_call_id": record.invocation.id,
                "name": record.invocation.name,
                "action": decision.action,
                "reason": decision.reason,
                "route": decision.route,
                "injected_message_count": len(decision.inject_messages),
                "recovering": observation.recovering,
                "replayed": observation.replayed,
                "journal_sequence": observation.journal_sequence,
            },
            observation.settled_event_id or None,
        )
