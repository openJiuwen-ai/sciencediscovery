"""Append-only provider view over an unchanged factual conversation."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from copy import deepcopy
from typing import Any


class ActiveContext:
    """Pin one accepted compacted prefix until another compaction is necessary.

    Hosts with custom context transformers/decisions keep owning their projection.
    This cache is only used by the runtime's default chat compaction path.
    """

    def __init__(self) -> None:
        self.source: tuple[Mapping[str, Any], ...] = ()
        self.provider: tuple[Mapping[str, Any], ...] = ()

    def remember(
        self,
        source: Sequence[Mapping[str, Any]],
        provider: Sequence[Mapping[str, Any]],
    ) -> None:
        self.source = deepcopy(tuple(source))
        self.provider = deepcopy(tuple(provider))

    def project(self, source: Sequence[Mapping[str, Any]]) -> tuple[Mapping[str, Any], ...]:
        messages = tuple(source)
        if not self.source:
            return messages
        boundary = len(self.source)
        if messages[:boundary] != self.source:
            raise ValueError("Active context no longer matches the append-only conversation")
        return (*deepcopy(self.provider), *messages[boundary:])

    def restore(self, payload: Mapping[str, Any]) -> None:
        source = payload.get("source_messages")
        provider = payload.get("provider_messages")
        if not isinstance(source, (list, tuple)) or not isinstance(provider, (list, tuple)):
            return  # Older checkpoints may contain only usage calibration.
        if source and provider and all(isinstance(row, Mapping) for row in (*source, *provider)):
            self.remember(source, provider)
