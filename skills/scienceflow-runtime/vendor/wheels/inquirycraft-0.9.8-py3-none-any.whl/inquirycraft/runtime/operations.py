from __future__ import annotations

import json
import os
from collections.abc import Mapping, Sequence
from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from .journal_storage import OPERATION_SCHEMA_VERSION, TERMINAL_PHASES, JournalStorage
from .resume import next_logical_turn_id

PROJECTION_CHECKPOINT_VERSION = "1.0"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


@dataclass(frozen=True, slots=True)
class OperationState:
    phase: str = "new"
    attempt: int = 0
    terminal: bool = False
    cancellation_requested: bool = False
    unsettled_steps: tuple[str, ...] = ()


class JsonlOperationJournal(JournalStorage):
    """Append-only intent/settlement journal with trailing-write recovery."""

    def append(
        self,
        kind: str,
        phase: str,
        *,
        step_id: str = "",
        attempt: int = 1,
        payload: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        from inquirycraft.memory.file_lock import exclusive_file_lock

        with exclusive_file_lock(self._lock_path):
            size = self.path.stat().st_size if self.path.exists() else 0
            if size != self._loaded_size:
                raise RuntimeError('Operation journal changed in another writer; reopen before writing')
            return self._append_locked(kind, phase, step_id=step_id, attempt=attempt, payload=payload)

    def _append_locked(self, kind, phase, *, step_id, attempt, payload):
        if (kind, phase) == ('projection', 'delta'):
            self._validate_delta(payload or {})
        row = {
            "schema_version": OPERATION_SCHEMA_VERSION,
            "sequence": self._sequence + 1,
            "timestamp": _now(),
            "operation_id": self.operation_id,
            "kind": kind,
            "phase": phase,
            "step_id": step_id,
            "attempt": attempt,
            "payload": dict(payload or {}),
        }
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + '\n')
            handle.flush()
            os.fsync(handle.fileno())
            self._loaded_size = os.fstat(handle.fileno()).st_size
        self._remember(deepcopy(row))
        return row

    def latest(self, kind: str, step_id: str) -> Mapping[str, Any] | None:
        key = (kind, '' if kind in {'projection', 'context'} else step_id)
        row = self._index.get(key)
        return deepcopy(row) if row and row.get('step_id') == step_id else None

    def is_unsettled(self, kind: str, step_id: str) -> bool:
        latest = self.latest(kind, step_id)
        return latest is not None and latest.get("phase") == "intent"

    def next_attempt(self, kind: str, step_id: str) -> int:
        row = self.latest(kind, step_id)
        return int(row.get('attempt', 1)) + 1 if row else 1

    def begin_operation(self, *, resumed: bool) -> dict[str, Any]:
        return self.append('operation', 'accepted', step_id='operation',
                           attempt=self.next_attempt('operation', 'operation'),
                           payload={'active': True, 'resumed': resumed})

    def request_cancellation(self) -> dict[str, Any]:
        return self.append('operation', 'cancellation_requested', step_id='operation',
                           attempt=max(1, self.state.attempt), payload={'active': True})

    def append_projection(
        self,
        messages: Sequence[Mapping[str, Any]],
        *,
        turn_id: int,
    ) -> dict[str, Any]:
        base = self._projection_messages
        incremental = bool(base and len(messages) >= len(base)
                           and list(messages[:len(base)]) == base and len(messages) % 64)
        payload = {'checkpoint_schema_version': PROJECTION_CHECKPOINT_VERSION, 'turn_id': turn_id}
        if incremental:
            payload.update(base_sequence=self._projection_sequence, base_message_count=len(base),
                           appended_messages=[dict(message) for message in messages[len(base):]])
        else:
            payload['messages'] = [dict(message) for message in messages]
        return self.append('projection', 'delta' if incremental else 'checkpoint',
                           step_id=f'projection:{turn_id}:{len(messages)}', payload=payload)

    def commit_terminal(
        self,
        phase: str,
        *,
        messages: Sequence[Mapping[str, Any]],
        payload: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        if phase not in TERMINAL_PHASES:
            raise ValueError(f"Unsupported terminal operation phase: {phase}")
        terminal_payload = dict(payload or {})
        terminal_payload.update(active=False, active_step_ids=[], projection={
            "checkpoint_schema_version": PROJECTION_CHECKPOINT_VERSION,
            "messages": [dict(message) for message in messages],
        })
        return self.append(
            "operation",
            phase,
            step_id="operation",
            attempt=max(1, self.state.attempt),
            payload=terminal_payload,
        )

    def latest_projection(self) -> tuple[Mapping[str, Any], ...]:
        return self.rebuild_projection()

    def rebuild_projection(self) -> tuple[Mapping[str, Any], ...]:
        messages: list[Mapping[str, Any]] = []
        checkpoint_index = -1
        for allow_context in (False, True):
            checkpoint_index, messages = self._projection_checkpoint(allow_context=allow_context)
            if checkpoint_index >= 0:
                break
        if checkpoint_index < 0:
            return ()
        pending_tools: list[Mapping[str, Any]] = []
        for row in self._rows[checkpoint_index + 1 :]:
            if (row.get("kind"), row.get("phase")) not in {
                ("llm", "settled"),
                ("tool", "settled"),
                ("queue", "consumed"),
            }:
                continue
            message = (row.get("payload") or {}).get("message")
            if isinstance(message, Mapping):
                candidate = dict(message)
                if candidate.get("role") == "tool":
                    pending_tools.append(candidate)
                    continue
                self._flush_tool_messages(messages, pending_tools)
                if not messages or messages[-1] != candidate:
                    messages.append(candidate)
        self._flush_tool_messages(messages, pending_tools)
        return deepcopy(tuple(messages))

    @staticmethod
    def _flush_tool_messages(
        messages: list[Mapping[str, Any]], pending: list[Mapping[str, Any]]
    ) -> None:
        if not pending:
            return
        assistant_index = next((index for index in range(len(messages) - 1, -1, -1)
                                if messages[index].get('role') == 'assistant'
                                and messages[index].get('tool_calls')), -1)
        calls = messages[assistant_index].get("tool_calls") or [] if assistant_index >= 0 else []
        expected_ids = [str(call['id']) for call in calls if isinstance(call, Mapping) and call.get('id')]
        existing_ids = {str(message['tool_call_id']) for message in messages[assistant_index + 1:]
                        if message.get('role') == 'tool' and message.get('tool_call_id')}
        by_id = {str(message.get("tool_call_id")): message for message in pending}
        ordered = [by_id[call_id] for call_id in expected_ids if call_id in by_id]
        for message in (*ordered, *pending):
            call_id = str(message.get("tool_call_id") or "")
            if not call_id or call_id not in existing_ids:
                messages.append(message)
                if call_id:
                    existing_ids.add(call_id)
        pending.clear()

    def _projection_checkpoint(self, *, allow_context: bool) -> tuple[int, list[Mapping[str, Any]]]:
        for index, row in reversed(tuple(enumerate(self._rows))):
            payload = row.get("payload") or {}
            if row.get("kind") == "operation" and row.get("phase") in TERMINAL_PHASES:
                projection = payload.get("projection") or {}
                checkpoint_messages = projection.get("messages")
            elif row.get("kind") == "projection" and row.get("phase") in {"checkpoint", "delta"}:
                checkpoint_messages = payload.get("messages")
            elif allow_context and row.get("kind") == "context" and row.get("phase") == "checkpoint":
                checkpoint_messages = payload.get("source_messages")
            else:
                continue
            if isinstance(checkpoint_messages, list):
                return index, [dict(message) for message in checkpoint_messages if isinstance(message, Mapping)]
        return -1, []

    def unprojected_llm_message(self) -> Mapping[str, Any] | None:
        """Return a settled assistant result not yet covered by a durable projection."""

        projection_sequence = max(
            (
                int(row.get("sequence", 0))
                for row in self._rows
                if row.get("kind") in {"projection", "operation"}
                and (row.get("kind") == "projection" or row.get("phase") in TERMINAL_PHASES)
            ),
            default=0,
        )
        for row in reversed(self._rows):
            if row.get("kind") != "llm" or row.get("phase") != "settled":
                continue
            if int(row.get("sequence", 0)) <= projection_sequence:
                return None
            message = (row.get("payload") or {}).get("message")
            return deepcopy(dict(message)) if isinstance(message, Mapping) else None
        return None

    def latest_checkpoint(self, kind: str) -> Mapping[str, Any] | None:
        row = next((row for row in reversed(self._rows)
                    if row.get('kind') == kind and row.get('phase') == 'checkpoint'), None)
        return deepcopy(row)

    def next_turn_id(self) -> int:
        """Return the logical turn to execute after reopening this journal."""
        return next_logical_turn_id(self._rows, self.state.unsettled_steps)

    @property
    def state(self) -> OperationState:
        operation = max((row for row in self._index.values() if row.get('kind') == 'operation'),
                        key=lambda row: row['sequence'], default=None)
        unsettled = tuple(
            sorted(
                str(row['step_id']) for row in self._index.values()
                if row.get('kind') not in {'operation', 'projection', 'context', 'queue'}
                and row.get('step_id') and row.get('phase') == 'intent'
            )
        )
        if operation is None:
            return OperationState(unsettled_steps=unsettled)
        phase = str(operation.get("phase", "new"))
        terminal = phase in TERMINAL_PHASES
        return OperationState(
            phase=phase,
            attempt=int(operation.get("attempt", 0)),
            terminal=terminal,
            cancellation_requested=phase == "cancellation_requested",
            unsettled_steps=() if terminal else unsettled,
        )
