from __future__ import annotations

import asyncio
from typing import Any, Mapping
from uuid import uuid4

from inquirycraft.events import EventSink, NullEventSink, RuntimeEvent
from inquirycraft.llm import LLMClient, ReasoningReplayPolicy, SameRoundRetryPolicy
from inquirycraft.memory import Conversation, JsonlConversationStore, Message
from inquirycraft.tools.artifacts import RawToolOutputStore, ToolOutputReducerRegistry
from inquirycraft.tools.collection import ToolCollection
from inquirycraft.tools.output_processing import ToolOutputPolicy, ToolOutputProcessor
from inquirycraft.tools.validation import ToolArgumentValidator

from .cancellation import CancellationToken
from .completion_context import RuntimeCompletionContextMixin
from .context import CompactionPolicy, ContextDecisionPolicy, ContextPipeline, ContextTransformer
from .control import RuntimeControlMixin
from .hooks import AgentHooks, RuntimeContext
from .llm_pipeline import RuntimeLLMPipeline
from .llm_retry import LLMRetryAdapter, default_same_round_retry_adapter
from .operations import JsonlOperationJournal
from .options import RuntimeOptions
from .policies import (
    ExhaustionPolicy,
    ExhaustionRequest,
    ToolChoicePolicy,
    TurnDecisionPolicy,
    resolve_exhaustion_decision,
)
from .provider import ProviderObserver
from .queues import RuntimeMessageQueues
from .resume import PendingToolCall, inspect_resume_messages
from .session_lifecycle import RuntimeSessionMixin
from .streaming import StreamOutputGuard
from .tool_pipeline import RuntimeToolPipeline, ToolBundlePolicy, ToolCallTransformer
from .turn_execution import RuntimeTurnMixin


class AgentRuntime(
    RuntimeControlMixin, RuntimeSessionMixin, RuntimeCompletionContextMixin, RuntimeTurnMixin
):
    """Minimal LLM/tool loop with stable hooks and runtime events."""

    def __init__(
        self,
        *,
        llm: LLMClient,
        options: RuntimeOptions,
        tools: ToolCollection | None = None,
        conversation: Conversation | None = None,
        conversation_store: JsonlConversationStore | None = None,
        event_sink: EventSink | None = None,
        hooks: AgentHooks | None = None,
        cancellation: CancellationToken | None = None,
        context_transformers: tuple[ContextTransformer, ...] = (),
        compaction_policy: CompactionPolicy | None = None,
        context_decision_policy: ContextDecisionPolicy | None = None,
        tool_validator: ToolArgumentValidator | None = None,
        validate_tool_arguments: bool = True,
        tool_output_policy: ToolOutputPolicy | None = None,
        tool_output_reducers: ToolOutputReducerRegistry | None = None,
        raw_tool_output_store: RawToolOutputStore | None = None,
        tool_choice_policy: ToolChoicePolicy | None = None,
        turn_decision_policy: TurnDecisionPolicy | None = None,
        tool_bundle_policy: ToolBundlePolicy | None = None,
        tool_call_transformer: ToolCallTransformer | None = None,
        llm_retry_policy: SameRoundRetryPolicy | None = None,
        llm_retry_adapter: LLMRetryAdapter | None = None,
        provider_observer: ProviderObserver | None = None,
        stream_guard: StreamOutputGuard | None = None,
        exhaustion_policy: ExhaustionPolicy | None = None,
    ) -> None:
        self.llm = llm
        self.options = options
        self.tools = tools or ToolCollection()
        self.conversation = conversation or Conversation()
        self.conversation_store = conversation_store
        self._ephemeral_context = ''
        self.event_sink = event_sink or NullEventSink()
        self.hooks = hooks or AgentHooks()
        self.cancellation = cancellation or CancellationToken()
        self._tool_choice_policy = tool_choice_policy
        self._turn_decision_policy = turn_decision_policy
        self._exhaustion_policy = exhaustion_policy
        self.context = RuntimeContext(
            session_id=options.session_id or f"session_{uuid4().hex}",
            run_id=options.run_id or f"run_{uuid4().hex}",
            agent_id=options.agent_id,
            workspace=options.workspace.resolve(),
            event_sink=self.event_sink,
            cancellation=self.cancellation,
        )
        self.operation_journal = None
        if options.operation_log is not None:
            self.operation_journal = JsonlOperationJournal(
                options.operation_log, operation_id=self.context.run_id
            )
        self._context_pipeline = ContextPipeline(
            transformers=context_transformers,
            compaction=compaction_policy,
            decision_policy=context_decision_policy,
            reasoning_replay=options.reasoning_replay,
        )
        if self.operation_journal is not None:
            checkpoint = self.operation_journal.latest_checkpoint("context")
            if checkpoint is not None:
                self._context_pipeline.restore_checkpoint(checkpoint.get("payload") or {})
        output_policy = tool_output_policy or ToolOutputPolicy()
        output_store = raw_tool_output_store or RawToolOutputStore(self.context.workspace)
        output_processor = ToolOutputProcessor(
            store=output_store,
            policy=output_policy,
            reducers=tool_output_reducers,
        )
        self._tool_pipeline = RuntimeToolPipeline(
            tools=self.tools,
            context=self.context,
            hooks=self.hooks,
            emit=self._pipeline_emit,
            append=self._append,
            concurrent=options.tool_execution == "parallel",
            journal=self.operation_journal,
            validator=tool_validator,
            output_processor=output_processor,
            bundle_policy=tool_bundle_policy,
            call_transformer=tool_call_transformer,
            validate_arguments=validate_tool_arguments,
        )
        guard = stream_guard
        if guard is None and options.max_output_chars_soft:
            guard = StreamOutputGuard(max_output_chars_soft=options.max_output_chars_soft)
        self._llm_pipeline = RuntimeLLMPipeline(
            llm=self.llm,
            context=self.context,
            hooks=self.hooks,
            emit=self._pipeline_emit,
            cancellation=self.cancellation,
            streaming=options.stream_llm,
            stream_guard=guard,
            journal=self.operation_journal,
            retry_policy=llm_retry_policy,
            retry_adapter=(
                llm_retry_adapter or default_same_round_retry_adapter
                if llm_retry_policy is not None
                else None
            ),
            provider_observer=provider_observer,
        )
        self._event_queue: asyncio.Queue[RuntimeEvent | None] | None = None
        self._queues = RuntimeMessageQueues(drain_mode=options.queue_drain_mode)
        if self.operation_journal is not None:
            self._queues.restore_journal(self.operation_journal.recovery_rows)
        self._run_lock = asyncio.Lock()

    def set_reasoning_replay(self, policy: ReasoningReplayPolicy | str) -> None:
        """Change only future provider projections; factual memory is untouched."""

        self._context_pipeline.set_reasoning_replay(policy)

    async def _emit(
        self,
        event_type: str,
        payload: Mapping[str, Any] | None = None,
        *,
        parent_event_id: str | None = None,
    ) -> RuntimeEvent:
        event_payload = dict(payload or {})
        if correlation := self.context.metadata.get("correlation"):
            event_payload.setdefault("correlation", dict(correlation))
        emitted = await self.event_sink.emit(
            RuntimeEvent(
                type=event_type,
                session_id=self.context.session_id,
                run_id=self.context.run_id,
                agent_id=self.context.agent_id,
                turn_id=self.context.turn_id or None,
                parent_event_id=parent_event_id,
                payload=event_payload,
            )
        )
        if self._event_queue is not None:
            await self._event_queue.put(emitted)
        return emitted

    async def _pipeline_emit(
        self,
        event_type: str,
        payload: Mapping[str, Any] | None,
        parent_event_id: str | None,
    ) -> RuntimeEvent:
        return await self._emit(event_type, payload, parent_event_id=parent_event_id)

    def _append(self, message: Message) -> None:
        self.conversation.append(message)
        if self.conversation_store is not None:
            self.conversation_store.append(message)
        if self.operation_journal is not None:
            self.operation_journal.append_projection(
                self.conversation.to_openai(), turn_id=self.context.turn_id
            )

    async def resume(self) -> str:
        """Continue an existing conversation without duplicating its task message.

        If the in-memory conversation is empty and a store was supplied, the store is
        loaded first. A single assistant tool call interrupted before its result is
        executed exactly once before the next provider request.
        """
        if not self.conversation.messages and self.conversation_store is not None:
            self.conversation = self.conversation_store.load()
        self._restore_journal_projection()
        state = inspect_resume_messages(self.conversation.messages)
        if state.action == "fresh_start":
            raise ValueError("Cannot resume an empty conversation; call run(task) instead")
        if state.action == "pending_tool_bundle_unsupported":
            raise RuntimeError(
                "Cannot safely resume multiple pending tool calls without execution state"
            )
        return await self._run_guarded(
            task=None,
            resumed=True,
            pending_tool_calls=state.pending_tool_calls,
        )

    async def resume_pending_tools_only(self) -> bool:
        """Execute one safely resumable pending tool bundle without a provider turn."""

        if not self.conversation.messages and self.conversation_store is not None:
            self.conversation = self.conversation_store.load()
        state = inspect_resume_messages(self.conversation.messages)
        if state.action != "execute_pending_tool":
            return False
        started = await self._start_session(task=None, resumed=True)
        await self._resume_pending_tools(
            state.pending_tool_calls,
            parent_event_id=started.event_id,
        )
        await self._emit("session.completed", {"turns": 0, "pending_tools_only": True})
        await self.event_sink.flush()
        return True

    async def _run(
        self,
        *,
        task: str | None,
        resumed: bool,
        pending_tool_calls: tuple[PendingToolCall, ...],
    ) -> str:
        if self.operation_journal is not None:
            self.operation_journal.begin_operation(resumed=resumed)
        final_content = ""
        terminal_committed = False
        try:
            started = await self._start_session(task=task, resumed=resumed)
            if resumed and not pending_tool_calls:
                recovered_content = await self._finish_recovered_completion()
                if recovered_content is not None:
                    terminal_committed = True
                    await self.event_sink.flush()
                    return recovered_content
            await self._resume_pending_tools(
                pending_tool_calls,
                parent_event_id=started.event_id,
            )
            turn = 1
            turn_origin = (
                self.operation_journal.next_turn_id()
                if resumed and self.operation_journal is not None
                else 1
            )
            turn_limit = self.options.max_turns
            exhaustion_applied = False
            while turn_limit is None or turn <= turn_limit:
                final_content, should_stop = await self._complete_turn(turn_origin + turn - 1)
                if should_stop:
                    break
                turn += 1
            else:
                decision = await resolve_exhaustion_decision(
                    self._exhaustion_policy,
                    ExhaustionRequest(final_content, self.context),
                )
                extra = max(0, int(decision.additional_turns))
                if extra and not exhaustion_applied:
                    for message in decision.inject_messages:
                        self._append(message)
                        await self._emit(
                            "memory.appended",
                            {"role": message.role, "injected": True},
                        )
                    exhaustion_applied = True
                    turn_limit += extra
                    while turn <= turn_limit:
                        final_content, should_stop = await self._complete_turn(
                            turn_origin + turn - 1
                        )
                        if should_stop:
                            break
                        turn += 1
                    else:
                        await self._emit("runtime.warning", {"reason": "max_turns_reached"})
                else:
                    await self._emit("runtime.warning", {"reason": "max_turns_reached"})
                if decision.output is not None:
                    final_content = decision.output

            await self._emit("session.completed", {"turns": self.context.turn_id})
            if self.operation_journal is not None:
                self.operation_journal.commit_terminal(
                    "completed",
                    messages=self.conversation.to_openai(),
                    payload={"turns": self.context.turn_id},
                )
            terminal_committed = True
            await self.event_sink.flush()
            return final_content
        except BaseException as exc:
            if terminal_committed:
                raise
            await self.hooks.on_error(exc, self.context)
            event_type = (
                "session.cancelled" if isinstance(exc, asyncio.CancelledError) else "session.failed"
            )
            await self._emit(
                event_type,
                {"error_type": type(exc).__name__, "error": str(exc)},
            )
            if self.operation_journal is not None:
                phase = "cancelled" if isinstance(exc, asyncio.CancelledError) else "failed"
                self.operation_journal.commit_terminal(
                    phase,
                    messages=self.conversation.to_openai(),
                    payload={"error_type": type(exc).__name__, "error": str(exc)},
                )
            await self.event_sink.flush()
            raise

    async def aclose(self) -> None:
        await self.llm.aclose()
        await self.event_sink.aclose()
