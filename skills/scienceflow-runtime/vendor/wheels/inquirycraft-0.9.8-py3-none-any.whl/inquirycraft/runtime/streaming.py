from __future__ import annotations

from dataclasses import dataclass

from inquirycraft.llm.assembly import StreamAssembler  # noqa: F401


class RepetitionDetector:
    """Sliding-window repetition detector for streamed text."""

    def __init__(self, *, window_chars: int, ngram_len: int, max_repeats: int) -> None:
        self._window_chars = max(256, int(window_chars))
        self._ngram_len = max(32, int(ngram_len))
        self._max_repeats = max(2, int(max_repeats))
        self._buf = ""

    def feed(self, chunk: str) -> bool:
        if not chunk:
            return False
        self._buf += chunk
        if len(self._buf) > self._window_chars:
            self._buf = self._buf[-self._window_chars :]
        if len(self._buf) < self._ngram_len * 2:
            return False
        tail = self._buf[-self._ngram_len :]
        return self._buf.count(tail) >= self._max_repeats


@dataclass(frozen=True, slots=True)
class StreamGuardHit:
    reason: str
    channel: str
    chars: int
    detail: str


class StreamOutputGuard:
    """Track per-channel output limits and repeated streamed content."""

    def __init__(
        self,
        *,
        max_output_chars_soft: int = 0,
        repetition_detection: bool = False,
        repetition_window_chars: int = 4000,
        repetition_ngram_len: int = 150,
        repetition_max_repeats: int = 3,
    ) -> None:
        self._max_output_chars_soft = max(0, int(max_output_chars_soft))
        self._repetition_detection = bool(repetition_detection)
        self._repetition_window_chars = int(repetition_window_chars)
        self._repetition_ngram_len = int(repetition_ngram_len)
        self._repetition_max_repeats = int(repetition_max_repeats)
        self._channel_chars: dict[str, int] = {}
        self._detectors: dict[str, RepetitionDetector | None] = {}

    def reset(self) -> None:
        self._channel_chars.clear()
        self._detectors.clear()

    def _detector_for(self, channel: str) -> RepetitionDetector | None:
        if channel in self._detectors:
            return self._detectors[channel]
        detector: RepetitionDetector | None = None
        if (
            self._repetition_detection
            and self._repetition_ngram_len > 0
            and self._repetition_max_repeats > 1
        ):
            detector = RepetitionDetector(
                window_chars=self._repetition_window_chars,
                ngram_len=self._repetition_ngram_len,
                max_repeats=self._repetition_max_repeats,
            )
        self._detectors[channel] = detector
        return detector

    def feed(self, channel: str, chunk: str) -> StreamGuardHit | None:
        if not chunk:
            return None
        total_chars = self._channel_chars.get(channel, 0) + len(chunk)
        self._channel_chars[channel] = total_chars
        if self._max_output_chars_soft > 0 and total_chars > self._max_output_chars_soft:
            return StreamGuardHit(
                reason="output_soft_limit",
                channel=channel,
                chars=total_chars,
                detail=(f"channel={channel} chars={total_chars}>{self._max_output_chars_soft}"),
            )
        detector = self._detector_for(channel)
        if detector is not None and detector.feed(chunk):
            return StreamGuardHit(
                reason="repetition",
                channel=channel,
                chars=total_chars,
                detail=f"channel={channel} repeated_tail_ngram",
            )
        return None
