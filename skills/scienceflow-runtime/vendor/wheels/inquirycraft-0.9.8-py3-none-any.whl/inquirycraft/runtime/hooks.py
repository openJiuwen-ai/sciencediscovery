from __future__ import annotations

import asyncio
import inspect
import time
from collections.abc import Awaitable, Callable, Sequence
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Literal, Mapping

from inquirycraft.events import EventSink
from inquirycraft.memory import Message
from inquirycraft.tools.base import ToolResult
from inquirycraft.tools.execution.models import ToolPostprocessDecision, ToolPreflightDecision

from .cancellation import CancellationToken


@dataclass(slots=True)
class RuntimeContext:
    session_id: str
    run_id: str
    agent_id: str
    workspace: Path
    event_sink: EventSink
    cancellation: CancellationToken
    turn_id: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ContextLimitDecision:
    messages: tuple[Mapping[str, Any], ...] | None = None
    cancel: bool = False


@dataclass(frozen=True, slots=True)
class ToolCommitObservation:
    """Immutable evidence exposed after one factual tool result is committed."""

    call: Any
    invocation: Any
    raw_result: ToolResult
    result: ToolResult
    message: Message
    bundle_index: int
    bundle_mode: str
    recovering: bool = False
    replayed: bool = False
    journal_attempt: int = 0
    journal_sequence: int = 0
    settled_event_id: str = ""


@dataclass(frozen=True, slots=True)
class ToolCommitDecision:
    """Domain-independent host decision made from committed tool evidence."""

    action: Literal["continue", "terminate_session"] = "continue"
    inject_messages: tuple[Message, ...] = ()
    output: str | None = None
    reason: str = ""
    route: str = ""


class AgentHooks:
    """Ordered no-op extension points for host applications and domain runtimes."""

    async def _noop(self, *_: Any) -> None:
        return None

    before_round = before_llm = after_llm = before_tool = _noop
    on_tool_stream = after_tool = after_tool_commit = _noop
    on_context_limit = on_error = after_round = _noop

    async def should_continue(self, context: RuntimeContext) -> bool:
        return True

    async def stop_output(self, context: RuntimeContext) -> str | None:
        return None


class HookFailureMode(str, Enum):
    SOFT = "soft"
    HARD = "hard"


class HookIdempotencyScope(str, Enum):
    NONE = "none"
    TURN = "turn"
    SESSION = "session"


@dataclass(frozen=True, slots=True)
class AgentHookRegistration:
    hook: AgentHooks
    name: str = ""
    priority: int = 0
    timeout_sec: float | None = None
    failure_mode: HookFailureMode = HookFailureMode.HARD
    idempotency_scope: HookIdempotencyScope = HookIdempotencyScope.NONE


@dataclass(frozen=True, slots=True)
class AgentHookTrace:
    hook_name: str
    method: str
    outcome: str
    duration_sec: float
    error: str = ""


AgentHookTraceSink = Callable[[AgentHookTrace], None | Awaitable[None]]


class AgentHookDispatchError(RuntimeError):
    pass


class ManagedAgentHooks(AgentHooks):
    """Priority-ordered agent hooks with timeout, isolation and idempotency."""

    def __init__(
        self,
        hooks: Sequence[AgentHooks | AgentHookRegistration] = (),
        *,
        trace_sink: AgentHookTraceSink | None = None,
    ) -> None:
        rows = [
            item
            if isinstance(item, AgentHookRegistration)
            else AgentHookRegistration(item, name=type(item).__name__)
            for item in hooks
        ]
        self.registrations = tuple(
            row for _, row in sorted(enumerate(rows), key=lambda pair: (-pair[1].priority, pair[0]))
        )
        self.hooks = tuple(row.hook for row in self.registrations)
        self.trace_sink = trace_sink
        self.traces: list[AgentHookTrace] = []
        self._seen: set[tuple[str, ...]] = set()

    async def stop_output(self, context: RuntimeContext) -> str | None:
        output = None
        for row in self.registrations:
            candidate = await self._invoke(row, "stop_output", context)
            if candidate is not None:
                output = str(candidate)
        return output

    async def _invoke(self, row: AgentHookRegistration, method: str, *args: Any) -> Any:
        context = next(
            (value for value in reversed(args) if isinstance(value, RuntimeContext)), None
        )
        scope = row.idempotency_scope
        key = None
        if scope is HookIdempotencyScope.SESSION and context is not None:
            key = (method, row.name, context.session_id)
        elif scope is HookIdempotencyScope.TURN and context is not None:
            key = (method, row.name, context.session_id, str(context.turn_id))
        if key is not None and key in self._seen:
            await self._trace(row, method, "duplicate_skipped", 0.0)
            return None
        if key is not None:
            self._seen.add(key)
        started = time.monotonic()
        try:
            value = getattr(row.hook, method)(*args)
            if inspect.isawaitable(value):
                value = (
                    await value
                    if row.timeout_sec is None
                    else await asyncio.wait_for(value, timeout=max(0.0, row.timeout_sec))
                )
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
            outcome = "timed_out" if isinstance(exc, TimeoutError) else "failed"
            await self._trace(row, method, outcome, time.monotonic() - started, error)
            if row.failure_mode is HookFailureMode.HARD:
                raise AgentHookDispatchError(
                    f"hard hook {row.name or type(row.hook).__name__} failed: {error}"
                ) from exc
            return None
        await self._trace(row, method, "succeeded", time.monotonic() - started)
        return value

    async def _trace(
        self,
        row: AgentHookRegistration,
        method: str,
        outcome: str,
        duration: float,
        error: str = "",
    ) -> None:
        trace = AgentHookTrace(
            row.name or type(row.hook).__name__, method, outcome, duration, error
        )
        self.traces.append(trace)
        if self.trace_sink is not None:
            try:
                value = self.trace_sink(trace)
                if inspect.isawaitable(value):
                    await value
            except Exception:
                pass

    async def _each(self, method: str, *args: Any) -> None:
        for row in self.registrations:
            await self._invoke(row, method, *args)

    async def before_round(self, context: RuntimeContext) -> None:
        await self._each("before_round", context)

    async def before_llm(self, request: Any, context: RuntimeContext) -> None:
        await self._each("before_llm", request, context)

    async def after_llm(self, result: Any, context: RuntimeContext) -> None:
        await self._each("after_llm", result, context)

    async def before_tool(self, call: Any, context: RuntimeContext) -> ToolPreflightDecision | None:
        decision = None
        for row in self.registrations:
            candidate = await self._invoke(row, "before_tool", call, context)
            if candidate is not None:
                decision = candidate
            if candidate is not None and candidate.block:
                break
        return decision

    async def on_tool_stream(self, chunk: str, context: RuntimeContext) -> None:
        await self._each("on_tool_stream", chunk, context)

    async def after_tool(
        self, call: Any, result: Any, context: RuntimeContext
    ) -> ToolResult | ToolPostprocessDecision | None:
        current = result
        replaced = False
        terminate = False
        for row in self.registrations:
            candidate = await self._invoke(row, "after_tool", call, current, context)
            if isinstance(candidate, ToolPostprocessDecision):
                terminate = terminate or candidate.terminate
                if candidate.result is not None:
                    current = candidate.result
                    replaced = True
            elif candidate is not None:
                current = candidate
                replaced = True
        if terminate:
            return ToolPostprocessDecision(result=current if replaced else None, terminate=True)
        return current if replaced else None

    async def after_tool_commit(
        self,
        observation: ToolCommitObservation,
        context: RuntimeContext,
    ) -> ToolCommitDecision | None:
        action: Literal["continue", "terminate_session"] = "continue"
        injected: list[Message] = []
        output = None
        reason = ""
        route = ""
        decided = False
        for row in self.registrations:
            candidate = await self._invoke(row, "after_tool_commit", observation, context)
            if candidate is None:
                continue
            if not isinstance(candidate, ToolCommitDecision):
                raise TypeError("after_tool_commit must return ToolCommitDecision or None")
            decided = True
            if candidate.action == "terminate_session":
                action = "terminate_session"
            injected.extend(candidate.inject_messages)
            if candidate.output is not None:
                output = candidate.output
            reason = candidate.reason or reason
            route = candidate.route or route
        if not decided:
            return None
        return ToolCommitDecision(action, tuple(injected), output, reason, route)

    async def on_context_limit(self, context: RuntimeContext) -> ContextLimitDecision | None:
        decision = None
        for row in self.registrations:
            candidate = await self._invoke(row, "on_context_limit", context)
            if candidate is not None:
                decision = candidate
            if candidate is not None and candidate.cancel:
                break
        return decision

    async def on_error(self, error: BaseException, context: RuntimeContext) -> None:
        await self._each("on_error", error, context)

    async def should_continue(self, context: RuntimeContext) -> bool:
        for row in self.registrations:
            candidate = await self._invoke(row, "should_continue", context)
            if candidate is False:
                return False
        return True

    async def after_round(self, context: RuntimeContext) -> None:
        await self._each("after_round", context)


class CompositeAgentHooks(ManagedAgentHooks):
    """Backward-compatible hard-failure composition in declaration order."""
