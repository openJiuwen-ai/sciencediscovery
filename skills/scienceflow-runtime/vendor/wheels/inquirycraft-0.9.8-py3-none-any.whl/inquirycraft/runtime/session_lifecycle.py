from __future__ import annotations

from typing import Any

from inquirycraft.events import RuntimeEvent
from inquirycraft.memory import Message


class RuntimeSessionMixin:
    """Session initialization and pending-tool recovery shared by runtime hosts."""

    def _restore_journal_projection(self) -> None:
        journal = getattr(self, "operation_journal", None)
        if journal is None:
            return
        projection = journal.rebuild_projection()
        if not projection:
            return
        current = tuple(self.conversation.to_openai())
        if current == projection[: len(current)]:
            for row in projection[len(current) :]:
                message = Message.from_dict(row)
                self.conversation.append(message)
                if self.conversation_store is not None:
                    self.conversation_store.append(message)
            return
        if projection == current[: len(projection)]:
            return
        raise RuntimeError("Conversation store diverges from the operation journal projection")

    async def _finish_recovered_completion(self) -> str | None:
        journal = getattr(self, "operation_journal", None)
        if journal is None:
            return None
        message = journal.unprojected_llm_message()
        if message is None or message.get("tool_calls"):
            return None
        content = str(message.get("content") or "")
        await self._emit(
            "session.completed",
            {"turns": self.context.turn_id, "recovered": True},
        )
        journal.commit_terminal(
            "completed",
            messages=self.conversation.to_openai(),
            payload={"turns": self.context.turn_id, "recovered": True},
        )
        return content

    async def _start_session(self, *, task: str | None, resumed: bool) -> RuntimeEvent:
        self.options.workspace.mkdir(parents=True, exist_ok=True)
        payload: dict[str, Any] = {"model": self.options.model}
        if resumed:
            payload.update(
                {
                    "resumed": True,
                    "existing_message_count": len(self.conversation.messages),
                }
            )
        started = await self._emit("session.started", payload)
        if resumed:
            return started
        if not self.conversation.messages and self.options.system_prompt:
            self._append(Message("system", self.options.system_prompt))
        if task is None:
            raise ValueError("task is required for a fresh run")
        # Context queued before this run belongs before the new user request.
        # The user's latest instruction must remain the final message seen by
        # the provider, even when several background results arrived meanwhile.
        await self._drain_queue("next_run")
        self._append(Message("user", task))
        await self._emit(
            "memory.appended",
            {"role": "user"},
            parent_event_id=started.event_id,
        )
        return started

    async def _resume_pending_tools(
        self,
        pending_tool_calls: tuple[Any, ...],
        *,
        parent_event_id: str,
    ) -> None:
        if not pending_tool_calls:
            return
        pending_event = await self._emit(
            "resume.pending_tool.started",
            {
                "count": len(pending_tool_calls),
                "tool_call_id": pending_tool_calls[0].tool_call_id,
                "name": pending_tool_calls[0].tool_name,
            },
            parent_event_id=parent_event_id,
        )
        await self._tool_pipeline.execute(
            [pending.tool_call for pending in pending_tool_calls], recovering=True
        )
        await self._emit(
            "resume.pending_tool.completed",
            {"count": len(pending_tool_calls)},
            parent_event_id=pending_event.event_id,
        )
