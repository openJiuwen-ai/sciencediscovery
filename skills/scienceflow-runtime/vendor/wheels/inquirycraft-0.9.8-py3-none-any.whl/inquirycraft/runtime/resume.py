"""Domain-independent inspection of persisted conversation resume points."""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any, Iterable


@dataclass(frozen=True, slots=True)
class PendingToolCall:
    tool_call: Any
    assistant_message: Any
    tool_call_id: str
    tool_name: str
    arguments_json: str


@dataclass(frozen=True, slots=True)
class ResumeState:
    action: str
    reason: str
    message_count: int
    last_role: str
    pending_tool_calls: tuple[PendingToolCall, ...] = ()

    def to_event(self) -> dict[str, Any]:
        return {
            "action": self.action,
            "reason": self.reason,
            "message_count": self.message_count,
            "last_role": self.last_role,
            "pending_tool_calls": [
                {
                    "tool_call_id": pending.tool_call_id,
                    "tool_name": pending.tool_name,
                    "arguments_json": pending.arguments_json[:1000],
                }
                for pending in self.pending_tool_calls
            ],
        }


def next_logical_turn_id(
    rows: Sequence[Mapping[str, Any]],
    unsettled_steps: Sequence[str],
) -> int:
    """Continue an unsettled LLM turn, otherwise allocate the next turn."""
    turn_ids: list[int] = []
    for row in rows:
        payload = row.get("payload") or {}
        value = payload.get("turn_id")
        if isinstance(value, int) and value > 0:
            turn_ids.append(value)
        correlation = payload.get("correlation") or {}
        value = correlation.get("turn_id") if isinstance(correlation, Mapping) else None
        if isinstance(value, int) and value > 0:
            turn_ids.append(value)
        step_id = str(row.get("step_id") or "")
        if row.get("kind") == "llm" and step_id.startswith("llm:"):
            try:
                turn_ids.append(int(step_id.removeprefix("llm:")))
            except ValueError:
                pass
    latest = max(turn_ids, default=0)
    if latest and f"llm:{latest}" in unsettled_steps:
        return latest
    return latest + 1


def _record_message(record: Any) -> Any:
    try:
        return record.memory_record.message
    except Exception:
        pass
    if isinstance(record, dict):
        message = record.get("message")
        return message if isinstance(message, dict) else record
    return record


def _message_role(message: Any) -> str:
    if isinstance(message, dict):
        return str(message.get("role") or "").strip()
    return str(getattr(message, "role", "") or "").strip()


def _message_tool_calls(message: Any) -> list[Any]:
    if isinstance(message, dict):
        calls = message.get("tool_calls") or []
    else:
        calls = getattr(message, "tool_calls", None) or []
    return list(calls) if isinstance(calls, (list, tuple)) else []


def _tool_call_id(tool_call: Any) -> str:
    if isinstance(tool_call, dict):
        return str(tool_call.get("id") or "").strip()
    return str(getattr(tool_call, "id", "") or "").strip()


def _tool_call_function(tool_call: Any) -> Any:
    if isinstance(tool_call, dict):
        return tool_call.get("function") or {}
    return getattr(tool_call, "function", None)


def _tool_call_name(tool_call: Any) -> str:
    function = _tool_call_function(tool_call)
    if isinstance(function, dict):
        return str(function.get("name") or "").strip()
    return str(getattr(function, "name", "") or "").strip()


def _tool_call_arguments(tool_call: Any) -> str:
    function = _tool_call_function(tool_call)
    if isinstance(function, dict):
        arguments = function.get("arguments")
    else:
        arguments = getattr(function, "arguments", "")
    if isinstance(arguments, str):
        return arguments
    try:
        return json.dumps(arguments, ensure_ascii=False, sort_keys=True)
    except (TypeError, ValueError):
        return str(arguments or "")


def _pending_tool_calls_from_tail(messages: list[Any]) -> tuple[PendingToolCall, ...]:
    if not messages:
        return ()
    assistant = messages[-1]
    if _message_role(assistant) != "assistant":
        return ()
    calls = _message_tool_calls(assistant)
    if not calls:
        return ()
    pending: list[PendingToolCall] = []
    for call in calls:
        pending.append(
            PendingToolCall(
                tool_call=call,
                assistant_message=assistant,
                tool_call_id=_tool_call_id(call),
                tool_name=_tool_call_name(call),
                arguments_json=_tool_call_arguments(call),
            )
        )
    return tuple(pending)


def inspect_resume_messages(messages_in: Iterable[Any]) -> ResumeState:
    """Classify the safe continuation point for public or legacy message shapes."""

    messages = [_record_message(record) for record in messages_in]
    messages = [message for message in messages if message is not None]
    if not messages:
        return ResumeState(
            action="fresh_start",
            reason="empty_memory",
            message_count=0,
            last_role="",
        )

    last_role = _message_role(messages[-1])
    pending = _pending_tool_calls_from_tail(messages)
    if len(pending) == 1:
        return ResumeState(
            action="execute_pending_tool",
            reason="assistant_tool_call_without_tool_result",
            message_count=len(messages),
            last_role=last_role,
            pending_tool_calls=pending,
        )
    if len(pending) > 1:
        return ResumeState(
            action="pending_tool_bundle_unsupported",
            reason="assistant_multiple_tool_calls_without_tool_results",
            message_count=len(messages),
            last_role=last_role,
            pending_tool_calls=pending,
        )
    if last_role == "tool":
        reason = "last_tool_result_ready_for_next_llm_round"
    elif last_role == "user":
        reason = "last_user_request_waiting_for_llm"
    elif last_role == "assistant":
        reason = "last_assistant_message_complete"
    else:
        reason = "memory_tail_complete"
    return ResumeState(
        action="continue_llm",
        reason=reason,
        message_count=len(messages),
        last_role=last_role,
    )
