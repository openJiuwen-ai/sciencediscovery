from __future__ import annotations

from dataclasses import replace

from inquirycraft.memory import Message

from .context import ContextProjectionExit
from .policies import TurnDecision, TurnDecisionRequest, resolve_turn_decision
from .provider import prepare_call_correlation


class RuntimeTurnMixin:
    """Commit one provider turn, apply host decisions, and preserve loop ordering."""

    async def _complete_turn(self, turn: int) -> tuple[str, bool]:
        self.cancellation.raise_if_cancelled()
        self.context.turn_id = turn
        prepare_call_correlation(self.context)
        await self.hooks.before_round(self.context)
        turn_event = await self._emit("agent.turn.started", {"turn": turn})
        try:
            result = await self._request_completion(turn_event)
        except ContextProjectionExit as early:
            decision = TurnDecision("terminate", early.reason, route="context", output=early.output)
            await self._record_turn_decision(decision)
            await self.hooks.after_round(self.context)
            await self._emit("agent.turn.completed", {"turn": turn})
            return early.output, True
        if result.tool_calls:
            result = replace(
                result,
                tool_calls=await self._tool_pipeline.transform_calls(result.tool_calls),
            )
        decision = await resolve_turn_decision(
            self._turn_decision_policy,
            TurnDecisionRequest(result=result, context=self.context),
        )
        if not decision.suppress_assistant:
            self._append(
                Message(
                    "assistant",
                    result.content,
                    tool_calls=result.tool_calls,
                    reasoning_content=(
                        result.reasoning_content
                        if result.reasoning_content or self.options.preserve_empty_reasoning_content
                        else None
                    ),
                )
            )
            await self._emit("memory.appended", {"role": "assistant"})
        records = (
            await self._tool_pipeline.execute(result.tool_calls)
            if not decision.suppress_assistant
            else []
        )
        for message in decision.inject_messages:
            self._append(message)
            await self._emit("memory.appended", {"role": message.role, "injected": True})
        await self._record_turn_decision(decision)
        # The TUI owns detached shells. Leave queued steering for its next
        # chat round so a message typed during the foreground wait does not
        # become trapped behind another model request in this run.
        detached_shell = any(
            record.result is not None
            and (record.result.metadata.get("shell_execution") or {}).get("status") == "background"
            for record in records
        )
        steered = False if detached_shell else await self._drain_queue("steer")
        followed = False
        if not result.tool_calls and not steered:
            followed = await self._drain_queue("follow_up")
        await self.hooks.after_round(self.context)
        await self._emit("agent.turn.completed", {"turn": turn})
        stop_output = await self.hooks.stop_output(self.context)
        if stop_output is not None:
            return stop_output, True
        if decision.action == "terminate":
            return decision.output if decision.output is not None else result.content, True
        if decision.action == "continue" or decision.inject_messages:
            return result.content, False
        if not result.tool_calls:
            return result.content, not (steered or followed)
        commit_decision = next(
            (
                record.metadata.get("post_commit_decision")
                for record in records
                if record.metadata.get("post_commit_decision") is not None
                and record.metadata["post_commit_decision"].action == "terminate_session"
            ),
            None,
        )
        if commit_decision is not None:
            return (
                commit_decision.output if commit_decision.output is not None else result.content,
                True,
            )
        terminate = any(record.terminate for record in records)
        if detached_shell:
            return result.content, True
        return result.content, terminate or (
            not steered and not await self.hooks.should_continue(self.context)
        )

    async def _record_turn_decision(self, decision: TurnDecision) -> None:
        if decision.action == "default" and not any(
            (decision.reason, decision.inject_messages, decision.suppress_assistant, decision.route)
        ):
            return
        if decision.reason:
            key = "termination_reason" if decision.action == "terminate" else "turn_reason"
            self.context.metadata[key] = decision.reason
        if decision.route:
            self.context.metadata["route"] = decision.route
        await self._emit(
            "agent.turn.decision",
            {
                "action": decision.action,
                "reason": decision.reason,
                "route": decision.route,
                "suppress_assistant": decision.suppress_assistant,
                "injected_message_count": len(decision.inject_messages),
            },
        )
