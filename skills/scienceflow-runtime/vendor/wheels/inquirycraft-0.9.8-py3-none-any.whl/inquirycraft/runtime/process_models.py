from __future__ import annotations

from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Protocol


class ProcessStream(str, Enum):
    STDOUT = "stdout"
    STDERR = "stderr"


class ProcessStatus(str, Enum):
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    TIMED_OUT = "timed_out"
    CANCELLED = "cancelled"
    TERMINATED = "terminated"


class ProcessLifecycleState(str, Enum):
    CREATED = "created"
    STARTING = "starting"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    TIMED_OUT = "timed_out"
    CANCELLED = "cancelled"
    TERMINATED = "terminated"


@dataclass(slots=True)
class ProcessLifecycle:
    state: ProcessLifecycleState = ProcessLifecycleState.CREATED


@dataclass(frozen=True, slots=True)
class ProcessRequest:
    command: str = ""
    argv: tuple[str, ...] = ()
    cwd: Path = Path(".")
    environment: Mapping[str, str] = field(default_factory=dict)
    timeout_sec: float = 0.0
    stream_limit_bytes: int = 50 * 1024 * 1024
    session_id: str = ""
    raw_output_dir: Path | None = None

    @property
    def uses_shell(self) -> bool:
        return bool(self.command)


@dataclass(frozen=True, slots=True)
class ProcessStreamChunk:
    sequence: int
    stream: ProcessStream
    raw: bytes
    text: str


@dataclass(frozen=True, slots=True)
class ProcessObservation:
    sequence: int
    session_id: str
    kind: str
    process_group_id: int | None = None
    stream: ProcessStream | None = None
    chunk_sequence: int | None = None
    byte_count: int = 0
    returncode: int | None = None
    detail: str = ""


@dataclass(frozen=True, slots=True)
class ProcessOutput:
    stdout_bytes: bytes = b""
    stderr_bytes: bytes = b""

    @property
    def stdout(self) -> str:
        return self.stdout_bytes.decode(errors="replace")

    @property
    def stderr(self) -> str:
        return self.stderr_bytes.decode(errors="replace")


@dataclass(frozen=True, slots=True)
class RawOutputArtifactRef:
    stdout_path: Path
    stderr_path: Path
    manifest_path: Path
    stdout_sha256: str
    stderr_sha256: str


@dataclass(frozen=True, slots=True)
class ProcessOutcome:
    session_id: str
    status: ProcessStatus
    returncode: int | None
    process_group_id: int | None
    started_at: float
    finished_at: float
    elapsed_sec: float
    output: ProcessOutput
    raw_output_ref: RawOutputArtifactRef | None = None
    observer_failures: tuple[str, ...] = ()


ExecutionOutcome = ProcessOutcome
ProcessChunkConsumer = Callable[[ProcessStreamChunk], None | Awaitable[None]]
ProcessObserver = Callable[[ProcessObservation], None | Awaitable[None]]


class ProcessSpawnError(RuntimeError):
    def __init__(self, cause: BaseException) -> None:
        super().__init__(f"{type(cause).__name__}: {cause}")
        self.cause = cause


class ProcessAdapter(Protocol):
    async def spawn(self, request: ProcessRequest) -> Any: ...

    async def terminate(self, process: Any, **kwargs: Any) -> None: ...

    def unregister(self, process_group_id: int) -> None: ...

    def live_process_group_ids(self) -> tuple[int, ...]: ...
