from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from typing import Any

from inquirycraft.events import RuntimeEvent
from inquirycraft.memory import Message

from .queues import QueuedMessage, QueueName


class RuntimeControlMixin:
    """Event streaming, cancellation and queued-message controls for AgentRuntime."""

    _event_queue: asyncio.Queue[RuntimeEvent | None] | None
    _queues: Any
    operation_journal: Any
    cancellation: Any

    async def run(self, task: str) -> str:
        return await self._run_guarded(task=task, resumed=False, pending_tool_calls=())

    async def _run_guarded(
        self,
        *,
        task: str | None,
        resumed: bool,
        pending_tool_calls: tuple[Any, ...],
    ) -> str:
        if self._run_lock.locked():
            raise RuntimeError("AgentRuntime is already running; use steer() or follow_up()")
        async with self._run_lock:
            return await self._run(
                task=task,
                resumed=resumed,
                pending_tool_calls=pending_tool_calls,
            )

    async def run_stream(self, task: str) -> AsyncIterator[RuntimeEvent]:
        if self._event_queue is not None:
            raise RuntimeError("This runtime already has an active event stream")
        queue: asyncio.Queue[RuntimeEvent | None] = asyncio.Queue()
        self._event_queue = queue

        async def execute() -> str:
            try:
                return await self.run(task)
            finally:
                await queue.put(None)

        task_handle = asyncio.create_task(execute())
        try:
            while (event := await queue.get()) is not None:
                yield event
            await task_handle
        finally:
            self._event_queue = None
            if not task_handle.done():
                task_handle.cancel()
                await asyncio.gather(task_handle, return_exceptions=True)

    def set_llm_retry_policy(self, policy, adapter) -> None:
        """Configure bounded provider recovery while the runtime is idle."""
        if self._run_lock.locked():
            raise RuntimeError("Cannot change retry policy while AgentRuntime is running")
        self._llm_pipeline.retry_policy = policy
        self._llm_pipeline.retry_adapter = adapter

    async def cancel(self) -> None:
        if self.operation_journal is not None:
            self.operation_journal.request_cancellation()
        self.cancellation.cancel()

    def reset_cancellation(self) -> None:
        """Allow a host to reuse this runtime after a cancelled run has settled."""

        if self._run_lock.locked():
            raise RuntimeError("Cannot reset cancellation while AgentRuntime is running")
        self.cancellation.reset()

    async def steer(self, message: str) -> str:
        return await self._enqueue("steer", message)

    async def follow_up(self, message: str) -> str:
        return await self._enqueue("follow_up", message)

    async def next_run(self, message: str) -> str:
        return await self._enqueue("next_run", message)

    def pending_messages(self, queue: QueueName | None = None) -> tuple[QueuedMessage, ...]:
        return self._queues.pending(queue)

    async def cancel_message(self, message_id: str) -> bool:
        cancelled = self._queues.cancel(message_id)
        if cancelled:
            await self._emit("queue.cancelled", {"message_id": message_id})
            if self.operation_journal is not None:
                self.operation_journal.append("queue", "cancelled", step_id=message_id)
        return cancelled

    async def _enqueue(self, queue: QueueName, message: str) -> str:
        item = self._queues.put(queue, message)
        await self._emit("queue.enqueued", {"message_id": item.id, "queue": queue})
        if self.operation_journal is not None:
            self.operation_journal.append(
                "queue",
                "accepted",
                step_id=item.id,
                payload={"queue": queue, "content": message},
            )
        return item.id

    async def _drain_queue(self, queue: QueueName) -> bool:
        items = self._queues.drain(queue)
        for item in items:
            self._append(Message("user", item.content))
            await self._emit(
                "queue.consumed",
                {"message_id": item.id, "queue": queue},
            )
            if self.operation_journal is not None:
                self.operation_journal.append(
                    "queue",
                    "consumed",
                    step_id=item.id,
                    payload={
                        "queue": queue,
                        "message": {"role": "user", "content": item.content},
                    },
                )
        return bool(items)
