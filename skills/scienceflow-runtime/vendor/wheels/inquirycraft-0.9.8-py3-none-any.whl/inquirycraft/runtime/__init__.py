"""InquiryCraft's domain-independent agent execution runtime.

Exports are lazy so low-level tool contracts can depend on the cancellation token
without importing the execution engine and creating a package cycle.
"""

from importlib import import_module
from typing import Any

_EXPORT_ROWS = (
    "engine:AgentRuntime;options:RuntimeOptions;state:AgentState;cancellation:CancellationToken;hooks:AgentHooks AgentHookDispatchError AgentHookRegistration AgentHookTrace CompositeAgentHooks ContextLimitDecision HookFailureMode HookIdempotencyScope ManagedAgentHooks RuntimeContext ToolCommitDecision ToolCommitObservation;context:CompactionPolicy CompactionDecision ContextDecisionPolicy ContextPipeline ContextProjectionExit ContextTransformer ContextProjectionRequest ProviderContext ProtectedContextSegment ProviderUsageObservation TokenEstimate;policies:ExhaustionDecision ExhaustionPolicy ExhaustionRequest ToolChoice ToolChoicePolicy ToolChoiceRequest TurnAction TurnDecision TurnDecisionPolicy TurnDecisionRequest;"
    "process_session:InquiryCraftProcessAdapter LocalProcessAdapter ProcessExecutionSession ProcessLifecycleState ProcessObservation ProcessOutcome ProcessOutput ProcessRequest ProcessSpawnError ProcessStatus ProcessStream ProcessStreamChunk RawOutputArtifactRef render_process_output render_combined_output persist_raw_output;process_models:ExecutionOutcome;llm_retry:LLMRetryAdapter LLMRetryRequest default_same_round_retry_adapter;resume:PendingToolCall ResumeState inspect_resume_messages;operations:OperationState JsonlOperationJournal;provider:ProviderObservation ProviderObserver;tool_pipeline:ToolBundlePolicy ToolCallTransformer;subprocess:kill_all_live_pgids live_process_group_ids spawn_exec spawn_shell unregister_process_group terminate_process_tree=terminate_tree terminate_process_tree_recoverable=terminate_tree_recoverable;subprocess_sync:run_in_process_group terminate_process_tree_sync=terminate_tree_sync;queues:QueuedMessage RuntimeMessageQueues;streaming:RepetitionDetector StreamGuardHit StreamOutputGuard;telemetry:build_llm_call_record"
).split(";")
_EXPORTS: dict[str, tuple[str, str]] = {}
for _row in _EXPORT_ROWS:
    _module, _symbols = _row.split(":", 1)
    for _symbol in _symbols.split():
        _public, _, _attribute = _symbol.partition("=")
        _EXPORTS[_public] = (f"inquirycraft.runtime.{_module}", _attribute or _public)
__all__ = list(_EXPORTS)


def __getattr__(name: str) -> Any:
    if name not in _EXPORTS:
        raise AttributeError(name)
    module_name, attribute = _EXPORTS[name]
    value = getattr(import_module(module_name), attribute)
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    return sorted(set(globals()) | set(__all__))
