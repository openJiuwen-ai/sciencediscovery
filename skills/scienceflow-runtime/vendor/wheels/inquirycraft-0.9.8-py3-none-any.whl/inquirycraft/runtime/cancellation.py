from __future__ import annotations

import asyncio


class CancellationToken:
    """Cooperative cancellation shared by a runtime and its tools."""

    def __init__(self) -> None:
        self._event = asyncio.Event()

    @property
    def cancelled(self) -> bool:
        return self._event.is_set()

    def cancel(self) -> None:
        self._event.set()

    def reset(self) -> None:
        """Clear a completed cancellation before an explicit subsequent run."""

        self._event.clear()

    async def wait(self) -> None:
        await self._event.wait()

    def raise_if_cancelled(self) -> None:
        if self.cancelled:
            raise asyncio.CancelledError("InquiryCraft runtime cancelled")
