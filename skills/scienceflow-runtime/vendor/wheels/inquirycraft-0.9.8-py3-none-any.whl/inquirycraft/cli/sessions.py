"""Workspace-local CLI sessions; selection happens before writer locks are taken."""

from __future__ import annotations

import json
import shutil
import sys
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path
from uuid import uuid4

import click


@dataclass(frozen=True)
class SavedSession:
    id: str
    directory: Path
    updated_at: float
    title: str
    turns: int
    state: str = "history"

    @property
    def session_log(self) -> Path:
        return self.directory / "session.jsonl"


class SessionCatalog:
    def __init__(self, workspace: Path, namespace: str,
                 legacy_roots: Iterable[Path] = ()) -> None:
        self.workspace = workspace.expanduser().resolve()
        relative = Path(namespace)
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError("Session namespace must stay inside the workspace")
        self.root = self.workspace / relative / "sessions"
        self.legacy_roots = tuple(Path(root).expanduser() for root in legacy_roots)

    @staticmethod
    def _summarize(directory: Path) -> SavedSession | None:
        log = directory / "session.jsonl"
        companions = (directory / "operations.jsonl", directory / "events.jsonl",
                      Path(str(log) + ".usage.jsonl"))
        if not log.is_file() and not any(path.is_file() and path.stat().st_size for path in companions):
            return None
        turns = 0
        title = "Empty session"
        try:
            if log.is_file():
                with log.open(encoding="utf-8") as stream:
                    for line in stream:
                        if not line.strip():
                            continue
                        message = json.loads(line).get("message") or {}
                        if message.get("role") == "user":
                            turns += 1
                            if title == "Empty session":
                                title = " ".join(str(message.get("content") or "").split())[:64]
        except (OSError, ValueError, AttributeError):
            title = "Unreadable history"
        state = "history"
        operations = directory / "operations.jsonl"
        if operations.is_file():
            try:
                with operations.open(encoding="utf-8") as stream:
                    for line in stream:
                        if line.strip():
                            row = json.loads(line)
                            if row.get("kind") == "operation":
                                state = str(row.get("phase") or "history")
            except (OSError, ValueError, AttributeError):
                state = "unknown"
        try:
            updated = max(path.stat().st_mtime for path in (log, *companions) if path.is_file())
        except OSError:
            return None
        return SavedSession(directory.name, directory, updated, title, turns, state)

    def list(self) -> tuple[SavedSession, ...]:
        sessions = []
        for root in (self.root, *self.legacy_roots):
            if root.is_dir():
                sessions.extend(session for directory in root.iterdir() if directory.is_dir()
                                if (session := self._summarize(directory)) is not None)
        return tuple(sorted(sessions, key=lambda item: (-item.updated_at, item.id)))

    def create(self) -> SavedSession:
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        identifier = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ") + "-" + uuid4().hex[:8]
        directory = self.root / identifier
        directory.mkdir(mode=0o700)
        return SavedSession(identifier, directory, datetime.now(timezone.utc).timestamp(), "Empty session", 0)

    def import_legacy(self, source: Path, *, operation_log: Path | None = None,
                      event_log: Path | None = None) -> SavedSession:
        from inquirycraft.memory import JsonlConversationStore

        source = source.expanduser().resolve()
        if not source.is_file():
            raise click.ClickException(f"Conversation log does not exist: {source}")
        try:
            JsonlConversationStore(source).load()
        except ValueError as exc:
            raise click.ClickException(str(exc)) from exc
        for companion in (operation_log, event_log):
            if companion is not None and not Path(companion).expanduser().is_file():
                raise click.ClickException(f"Companion log does not exist: {companion}")
        chosen = self.create()
        chosen.session_log.touch(mode=0o600)
        for original, name in ((source, "session.jsonl"),
                               (operation_log, "operations.jsonl"),
                               (event_log, "events.jsonl")):
            if original is not None:
                shutil.copyfile(Path(original).expanduser().resolve(), chosen.directory / name)
        usage = Path(str(source) + ".usage.jsonl")
        if usage.is_file():
            shutil.copyfile(usage, Path(str(chosen.session_log) + ".usage.jsonl"))
        return chosen

    def select(self, identifier: str | None) -> SavedSession:
        choices = self.list()
        if not choices:
            raise click.ClickException("No saved session in this workspace. Start without --resume.")
        if identifier:
            matches = [item for item in choices if item.id == identifier]
            if not matches:
                matches = [item for item in choices if item.id.startswith(identifier)]
            if len(matches) != 1:
                detail = ", ".join(item.id for item in matches) or "none"
                raise click.ClickException(f"Session {identifier!r} matches {detail} in this workspace.")
            return matches[0]
        click.echo(f"Sessions in {self.workspace}:")
        for index, item in enumerate(choices, 1):
            updated = datetime.fromtimestamp(item.updated_at, timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
            click.echo(f"  {index}. {item.id} · {updated} · {item.title} ({item.turns} turns, {item.state})")
        if not sys.stdin.isatty():
            raise click.ClickException("Non-interactive resume requires --session ID.")
        number = click.prompt("Select session number", type=click.IntRange(1, len(choices)))
        return choices[number - 1]


def prepare_session(function, *, namespace: str,
                    legacy_roots: Callable[[Path], Iterable[Path]] | None = None):
    @wraps(function)
    def prepared(*args, **kwargs):
        resume = kwargs.pop("resume")
        identifier = kwargs.pop("session")
        if identifier and not resume:
            raise click.ClickException("--session requires --resume.")
        if not resume and click.get_current_context().command.name == "run" and not kwargs.get("task"):
            raise click.UsageError("Missing argument 'TASK'.")
        workspace = Path(kwargs["workspace"]).expanduser().resolve()
        catalog = SessionCatalog(workspace, namespace,
                                 legacy_roots(workspace) if legacy_roots else ())
        chosen = catalog.select(identifier) if resume else catalog.create()
        kwargs["workspace"] = workspace
        kwargs["session_log"] = chosen.session_log
        kwargs["operation_log"] = kwargs.get("operation_log") or chosen.directory / "operations.jsonl"
        kwargs["event_log"] = kwargs.get("event_log") or chosen.directory / "events.jsonl"
        kwargs["resumed_session"] = resume
        return function(*args, **kwargs)

    return prepared


def register_session_commands(app: click.Group, namespace: str,
                              legacy_roots: Callable[[Path], Iterable[Path]] | None) -> None:
    def catalog(workspace: Path) -> SessionCatalog:
        workspace = workspace.expanduser().resolve()
        return SessionCatalog(workspace, namespace,
                              legacy_roots(workspace) if legacy_roots else ())

    @app.group("sessions")
    def sessions_group() -> None:
        """List and import workspace-local chat sessions."""

    @sessions_group.command("list")
    @click.option("--workspace", type=click.Path(path_type=Path, file_okay=False), default=Path("."))
    def sessions_list(workspace: Path) -> None:
        for item in catalog(workspace).list():
            updated = datetime.fromtimestamp(item.updated_at, timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
            click.echo(f"{item.id} · {updated} · {item.title} ({item.turns} turns, {item.state})")

    @sessions_group.command("import")
    @click.argument("path", type=click.Path(path_type=Path, exists=True, dir_okay=False))
    @click.option("--workspace", type=click.Path(path_type=Path, file_okay=False), default=Path("."))
    @click.option("--operation-log", type=click.Path(path_type=Path, exists=True, dir_okay=False))
    @click.option("--event-log", type=click.Path(path_type=Path, exists=True, dir_okay=False))
    def sessions_import(path: Path, workspace: Path, operation_log: Path | None,
                        event_log: Path | None) -> None:
        try:
            imported = catalog(workspace).import_legacy(
                path, operation_log=operation_log, event_log=event_log)
        except OSError as exc:
            raise click.ClickException(f"Could not import session: {exc}") from exc
        click.echo(f"Imported session {imported.id} into {imported.directory}")
