"""Validate usage before mutation and format context token counts."""

import math

from .chat_profiles import PRESETS

_CAPACITY_LABELS = {tokens: label for label, tokens in PRESETS.items()}


def _token_count(value):
    if isinstance(value, bool) or not isinstance(value, (int, float, str)):
        raise ValueError("Invalid token count")
    try:
        result = int(value)
    except (ValueError, OverflowError) as exc:
        raise ValueError("Invalid token count") from exc
    if result < 0 or (isinstance(value, float) and value != result):
        raise ValueError("Invalid token count")
    return result


def validate_usage_record(row):
    """Return validated counts; never partially apply a malformed record."""
    if not isinstance(row, dict):
        raise ValueError("Invalid usage record")
    for field in ("id", "route", "model"):
        if not isinstance(row[field], str) or not row[field]:
            raise ValueError(f"Invalid usage {field}")
    incoming, output, cached = (_token_count(row[name]) for name in ("input", "output", "cached"))
    baseline = _token_count(row.get("context_baseline", 0))
    cost = row.get("cost")
    try:
        valid_cost = cost is None or (
            type(cost) in (int, float) and math.isfinite(cost) and cost >= 0
        )
    except OverflowError:
        valid_cost = False
    if not valid_cost or cached > incoming:
        raise ValueError("Invalid usage cost or cached count")
    return incoming, output, cached, baseline


def format_context_tokens(tokens, *, capacity=False, decimal=False):
    if capacity and tokens in _CAPACITY_LABELS:
        return _CAPACITY_LABELS[tokens]
    base = 1000 if decimal else 1024
    divisor, suffix = (base**2, "M") if tokens >= base**2 else (base, "K")
    number = f"{tokens / divisor:.1f}"
    if capacity:
        number = number.rstrip("0").rstrip(".")
    return number + suffix
