"""Read-only CLI commands for tool schemas and runtime events."""

from __future__ import annotations

import json
from pathlib import Path

import click

from inquirycraft.events import load_events
from inquirycraft.tools import default_tools


def register_tool_commands(app: click.Group) -> None:
    @app.group("tools")
    def tools_group() -> None:
        """Inspect built-in tools without initializing an LLM."""

    @tools_group.command("list")
    @click.option("--json-output", "json_output", is_flag=True)
    def tools_list(json_output: bool) -> None:
        tools = default_tools()
        if json_output:
            click.echo(json.dumps({"schema_version": "1.0", "tools": tools.names()}, indent=2))
        else:
            for tool_name in tools.names():
                click.echo(tool_name)

    @tools_group.command("schema")
    @click.argument("name", required=False)
    def tools_schema(name: str | None) -> None:
        tools = default_tools()
        schemas = tools.schemas()
        if name:
            schemas = tuple(row for row in schemas if row["function"]["name"] == name)
            if not schemas:
                raise click.ClickException(f"Unknown tool: {name}")
        click.echo(json.dumps({"schema_version": "1.0", "tools": schemas}, indent=2))


def register_event_commands(app: click.Group) -> None:
    @app.group("events")
    def events_group() -> None:
        """Inspect InquiryCraft runtime event JSONL."""

    @events_group.command("show")
    @click.argument("path", type=click.Path(path_type=Path, exists=True, dir_okay=False))
    @click.option("--type", "event_type", default=None)
    @click.option("--limit", type=click.IntRange(1), default=None)
    def events_show(path: Path, event_type: str | None, limit: int | None) -> None:
        events = load_events(path, event_type=event_type)
        if limit is not None:
            events = events[-limit:]
        for event in events:
            click.echo(json.dumps(event.to_dict(), ensure_ascii=False, sort_keys=True))
