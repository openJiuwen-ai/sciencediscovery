"""Default bounded context projection for interactive CLI runtimes."""

from inquirycraft.runtime import CompactionPolicy


def default_chat_compaction() -> CompactionPolicy:
    """Use a 256K window with output/safety reserves and an 80% input trigger.

    This is a configurable default, not model capability discovery.
    Embedding applications retain control over their own runtime policies.
    """
    from .chat_profiles import ChatProfile

    return ChatProfile().policy()
