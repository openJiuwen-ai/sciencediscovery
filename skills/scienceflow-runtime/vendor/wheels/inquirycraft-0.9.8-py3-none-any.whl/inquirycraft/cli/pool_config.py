"""Plural endpoint configuration with explicit scalar compatibility."""

from __future__ import annotations

import re


def split_values(value: str | None) -> tuple[str, ...]:
    return tuple(item for item in re.split(r"[,\s]+", str(value or "").strip()) if item)
