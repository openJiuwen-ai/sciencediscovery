from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol

import click

from inquirycraft.events import EventSink
from inquirycraft.runtime import AgentRuntime, RuntimeOptions


@dataclass(slots=True)
class CommandContext:
    runtime_factory: "RuntimeFactory"
    metadata: dict[str, Any]


class RuntimeFactory(Protocol):
    def create_runtime(
        self,
        options: RuntimeOptions,
        *,
        api_key: str,
        base_url: str | None,
        event_sink: EventSink,
    ) -> AgentRuntime: ...


class CliExtension(Protocol):
    name: str

    def register(self, registry: "CommandRegistry") -> None: ...


class CommandRegistry:
    """Small Click adapter that keeps extension registration provider-neutral."""

    def __init__(self, group: click.Group) -> None:
        self.group = group

    def add(self, command: click.Command, *, name: str | None = None) -> None:
        self.group.add_command(command, name=name)

    @property
    def commands(self) -> dict[str, click.Command]:
        return dict(self.group.commands)
