from __future__ import annotations

from pathlib import Path

import click


def register_config_commands(app: click.Group, model_config_path: Path) -> None:
    @app.group("config")
    def config_group() -> None:
        """Inspect or initialize the private model registry."""

    @config_group.command("path")
    def config_path() -> None:
        click.echo(model_config_path.expanduser())

    @config_group.command("init")
    def config_init() -> None:
        from inquirycraft.llm import write_model_registry_template

        try:
            path = write_model_registry_template(model_config_path)
        except FileExistsError:
            click.echo(f"Configuration already exists: {model_config_path.expanduser()}")
            return
        except OSError as exc:
            raise click.ClickException(
                f"Cannot create configuration at {model_config_path}: {exc.strerror}"
            ) from exc
        click.echo(f"Created {path}; edit its models and endpoints.")


__all__ = ["register_config_commands"]
