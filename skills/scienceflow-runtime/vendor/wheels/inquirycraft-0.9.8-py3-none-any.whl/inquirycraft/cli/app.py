from __future__ import annotations

import asyncio
from collections.abc import Callable, Iterable
from pathlib import Path
from typing import Any

import click

from inquirycraft.events import JsonlEventSink, NullEventSink
from inquirycraft.runtime import RuntimeOptions
from inquirycraft.tui.branding import TuiBranding
from inquirycraft.tui.contracts import TuiInterceptorFactory

from .config import register_config_commands
from .contracts import CliExtension, CommandRegistry, RuntimeFactory
from .factory import DefaultRuntimeFactory
from .inspection import register_event_commands, register_tool_commands
from .pool_config import split_values
from .session_guard import guard_session
from .sessions import prepare_session, register_session_commands

RuntimeOptionsDecorator = Callable[[Callable[..., Any]], Callable[..., Any]]


def _runtime_options(
    *,
    model_config_default: Path,
    stream_default: bool = False,
    session_namespace: str = ".inquirycraft",
    legacy_session_roots: Callable[[Path], Iterable[Path]] | None = None,
) -> RuntimeOptionsDecorator:
    def decorate(function):
        function = guard_session(function)
        function = prepare_session(function, namespace=session_namespace,
                                   legacy_roots=legacy_session_roots)
        options = [
            click.option("--resume", is_flag=True,
                         help="Choose a saved chat session in this workspace."),
            click.option("--session", default=None,
                         help="Saved session ID or unique prefix; requires --resume and skips the list."),
            click.option(
                "--models",
                "--model",
                "model",
                default=None,
                help=("Comma-separated aliases from models.json; defaults to the configured "
                      "group and uses its configured routing policy."),
            ),
            click.option(
                "--model-config",
                type=click.Path(path_type=Path, dir_okay=False),
                default=model_config_default,
                show_default=True,
                help="Structured model and endpoint configuration.",
            ),
            click.option(
                "--workspace",
                type=click.Path(path_type=Path, file_okay=False),
                default=Path("."),
                show_default=True,
            ),
            click.option("--system-prompt", default="You are a helpful agent.", show_default=True),
            click.option("--max-turns", type=click.IntRange(1), default=20, show_default=True),
            click.option("--max-tokens", type=click.IntRange(1), default=None),
            click.option(
                "--timeout",
                type=click.FloatRange(min=0.1),
                default=300.0,
                show_default=True,
                help="Provider request timeout in seconds; this does not limit shell commands.",
            ),
            click.option(
                "--event-log",
                type=click.Path(path_type=Path, dir_okay=False),
                default=None,
            ),
            click.option(
                "--operation-log",
                type=click.Path(path_type=Path, dir_okay=False),
                default=None,
                help="Persist intent/settlement records for conservative recovery.",
            ),
            click.option("--stream/--no-stream", "stream_llm", default=stream_default),
            click.option(
                "--tool-execution",
                type=click.Choice(("sequential", "parallel")),
                default="sequential",
                show_default=True,
            ),
        ]
        for option in reversed(options):
            function = option(function)
        return function

    return decorate


def _build_runtime(
    factory: RuntimeFactory,
    *,
    model: str | None,
    model_config: Path,
    model_default_key: str,
    workspace: Path,
    system_prompt: str,
    max_turns: int | None,
    max_tokens: int | None,
    timeout: float,
    event_log: Path | None,
    session_log: Path | None,
    operation_log: Path | None,
    stream_llm: bool,
    tool_execution: str,
):
    from inquirycraft.llm import ModelRegistry

    try:
        registry = ModelRegistry.from_json(model_config)
        aliases = split_values(model) or registry.default_aliases(model_default_key)
        resolved = registry.resolve(aliases, role=model_default_key)
    except ValueError as exc:
        raise click.ClickException(str(exc)) from exc
    sink = JsonlEventSink(event_log) if event_log else NullEventSink()
    options = RuntimeOptions(
        model=",".join(resolved.models),
        use_proxies=resolved.use_proxies,
        workspace=workspace,
        system_prompt=system_prompt,
        max_turns=max_turns,
        max_tokens=max_tokens,
        timeout=timeout,
        session_id=session_log.parent.name if session_log else "",
        session_log=session_log,
        operation_log=operation_log,
        stream_llm=stream_llm,
        tool_execution=tool_execution,  # type: ignore[arg-type]
        model_routing=(
            "sticky"
            if registry.defaults.get("selection") == "fixed"
            else "sticky_failover"
        ),
    )
    runtime = factory.create_runtime(
        options,
        api_key=",".join(resolved.api_keys),
        base_url=",".join(resolved.base_urls),
        event_sink=sink,
    )
    monitor = getattr(runtime, "chat_monitor", None)
    configure_registry = getattr(monitor, "configure_model_registry", None)
    if callable(configure_registry):
        configure_registry(registry, aliases, registry.defaults.get("selection", "auto"))
    return runtime


def _register_run_command(
    app: click.Group,
    factory: RuntimeFactory,
    options: RuntimeOptionsDecorator,
    model_default_key: str,
) -> None:
    @app.command("run")
    @click.argument("task", required=False)
    @options
    def run_command(task: str | None, **kwargs) -> None:
        """Run one task with the configured model pool and built-in tools.

        The built-in shell runs as the current user without an OS sandbox or a
        default command timeout.
        """
        resumed = kwargs.pop("resumed_session")
        if task is None:
            if resumed:
                parent = click.get_current_context().parent
                command = "scienceflow agent" if parent and parent.info_name == "agent" else "inquirycraft"
                click.echo(
                    f"Selected chat session {kwargs['session_log'].parent.name}; no TASK was given, "
                    "so no turn ran and this command will not enter interactive chat. "
                    f"Use '{command} repl --resume --session ID' to chat, "
                    "or provide TASK to run one turn."
                )
                return
            raise click.UsageError("Missing argument 'TASK'.")
        runtime = _build_runtime(factory, model_default_key=model_default_key, **kwargs)

        async def execute() -> None:
            try:
                result = await runtime.run(task)
                click.echo(result)
            finally:
                await runtime.aclose()

        asyncio.run(execute())


def _register_repl_command(
    app: click.Group,
    factory: RuntimeFactory,
    options: RuntimeOptionsDecorator,
    model_default_key: str,
    prompt: str,
) -> None:
    @app.command("repl")
    @options
    def repl_command(**kwargs) -> None:
        """Start a persistent session with the configured model pool.

        The built-in shell runs as the current user without an OS sandbox or a
        default command timeout.
        """
        kwargs.pop("resumed_session")
        runtime = _build_runtime(factory, model_default_key=model_default_key, **kwargs)

        async def execute() -> None:
            try:
                while True:
                    line = (await asyncio.to_thread(input, prompt)).strip()
                    if line.lower() in {"exit", "quit", "q"}:
                        break
                    if line:
                        click.echo(await runtime.run(line))
            except (EOFError, KeyboardInterrupt):
                pass
            finally:
                await runtime.aclose()

        asyncio.run(execute())


def _register_tui_command(
    app: click.Group,
    factory: RuntimeFactory,
    options: RuntimeOptionsDecorator,
    model_default_key: str,
    interceptor_factory: TuiInterceptorFactory | None = None,
    branding: TuiBranding | None = None,
) -> None:
    @app.command("tui", help=f"Start the full-screen {(branding or TuiBranding()).name} terminal interface.")
    @options
    @click.option("--markdown/--no-markdown", default=True,
                  envvar="INQUIRYCRAFT_TUI_MARKDOWN", show_default=True,
                  help="Render assistant responses as Markdown.")
    def tui_command(**kwargs) -> None:
        """Start the full-screen InquiryCraft terminal interface."""

        kwargs.pop("resumed_session")
        markdown = kwargs.pop("markdown")
        runtime = _build_runtime(factory, model_default_key=model_default_key, **kwargs)
        from .tui_recovery import configure_tui_recovery

        configure_tui_recovery(runtime)
        try:
            from inquirycraft.tui import InquiryCraftTui
        except ModuleNotFoundError as exc:
            if exc.name == "textual":
                raise click.ClickException(
                    "TUI support is not installed; install inquirycraft[tui]"
                ) from exc
            raise

        interceptor_options = {}
        if not markdown:
            interceptor_options["markdown"] = False
        if branding is not None:
            interceptor_options["branding"] = branding
        if interceptor_factory is not None:
            interceptor = interceptor_factory(Path(kwargs["workspace"]).resolve())
            configure_models = getattr(interceptor, "configure_model_registry", None)
            if callable(configure_models):
                configure_models(Path(kwargs["model_config"]), split_values(kwargs["model"]))
            interceptor_options["interceptor"] = interceptor
        application = InquiryCraftTui(
            runtime,
            model=str(kwargs["model"] or "auto"),
            workspace=Path(kwargs["workspace"]),
            **interceptor_options,
        )

        async def execute() -> None:
            try:
                await application.run_async()
            finally:
                await application.shutdown_runtime()

        asyncio.run(execute())

    for parameter in tui_command.params:
        if parameter.name == "max_turns":
            parameter.default = None
            parameter.help = "Optional per-message turn limit; TUI chat is unlimited by default."


def create_cli(
    *,
    name: str = "inquirycraft",
    runtime_factory: RuntimeFactory | None = None,
    extensions: Iterable[CliExtension] = (),
    model_config_default: Path | None = None,
    model_default_key: str = "code_models",
    include_tui: bool = True,
    tui_interceptor_factory: TuiInterceptorFactory | None = None,
    tui_branding: TuiBranding | None = None,
    model_envvar: str | None = None,
    base_url_envvar: str | None = None,
    api_key_env_default: str | None = None,
    session_namespace: str = ".inquirycraft",
    legacy_session_roots: Callable[[Path], Iterable[Path]] | None = None,
    repl_prompt: str | None = None,
) -> click.Group:
    # Retain the pre-registry embedding signature. Environment-backed provider
    # settings are intentionally no longer read by the built-in commands.
    del model_envvar, base_url_envvar, api_key_env_default
    factory = runtime_factory or DefaultRuntimeFactory()

    @click.group(name=name)
    def app() -> None:
        """Run and inspect lightweight InquiryCraft agents."""

    if model_config_default is None:
        from inquirycraft.llm import default_model_registry_path

        config_path = default_model_registry_path()
    else:
        config_path = model_config_default
    options = _runtime_options(model_config_default=config_path,
                               session_namespace=session_namespace,
                               legacy_session_roots=legacy_session_roots)
    _register_run_command(app, factory, options, model_default_key)
    _register_repl_command(app, factory, options, model_default_key, repl_prompt or f"{name}> ")
    if include_tui:
        tui_options = _runtime_options(model_config_default=config_path, stream_default=True,
                                       session_namespace=session_namespace,
                                       legacy_session_roots=legacy_session_roots)
        _register_tui_command(
            app, factory, tui_options, model_default_key,
            tui_interceptor_factory, tui_branding,
        )
    register_tool_commands(app)
    register_event_commands(app)
    register_session_commands(app, session_namespace, legacy_session_roots)
    register_config_commands(app, config_path)

    registry = CommandRegistry(app)
    for extension in extensions:
        extension.register(registry)
    return app


main = create_cli()
