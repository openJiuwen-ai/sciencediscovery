"""Optional endpoint/model preferences; no API credentials are persisted."""

import json
import os
from dataclasses import asdict, dataclass, fields
from hashlib import sha256
from pathlib import Path
from tempfile import NamedTemporaryFile

from inquirycraft.runtime import CompactionPolicy

PRESETS = {'32K': 32_768, '64K': 65_536, '128K': 131_072,
           '256K': 262_144, '1M': 1_000_000}
DEFAULT_WINDOW = PRESETS['256K']
_LEGACY_PRICE_FIELDS = {'input_price', 'cached_price', 'output_price'}


@dataclass(frozen=True)
class ChatProfile:
    window: int | None = DEFAULT_WINDOW
    output_reserve: int = 32768
    safety: int = 2048
    trigger: float = .8

    def validate(self):
        for value in (self.output_reserve, self.safety, *(() if self.window is None else (self.window,))):
            if isinstance(value, bool) or not isinstance(value, int):
                raise ValueError("Token capacities and reserves must be integers.")
        if self.window is not None and (isinstance(self.window, bool) or self.window <= self.output_reserve + self.safety):
            raise ValueError(
                f'Window must exceed output reserve plus safety margin '
                f'({self.output_reserve:,} + {self.safety:,} tokens). '
                'Open /context and lower output reserve or choose a larger window; '
                'existing limits were not changed.'
            )
        if self.output_reserve < 1 or self.safety < 0 or not 0 < self.trigger < 1:
            raise ValueError('Reserve must be positive and trigger must be between 0 and 1.')
        return self

    def policy(self):
        self.validate()
        if self.window is None:
            from .context_config import default_chat_compaction
            return default_chat_compaction()
        limit = int((self.window - self.output_reserve - self.safety) * self.trigger)
        return CompactionPolicy(enabled=True, max_context_tokens=max(1, limit), reserve_tokens=0,
                                keep_recent_tokens=max(1, min(32_000, limit // 2)))


def profile_key(endpoint, model):
    return sha256((str(endpoint).rstrip('/') + '\n' + model).encode()).hexdigest()


class ProfileStore:
    def __init__(self, path=None, *, fallback_path=None):
        base = Path(os.environ.get('XDG_CONFIG_HOME') or Path.home() / '.config')
        self.path = Path(path) if path else base / 'inquirycraft' / 'chat_profiles.json'
        self.fallback_path = Path(fallback_path) if fallback_path else None

    def _read(self, path=None):
        path = self.path if path is None else path
        if not path.exists():
            return {}
        data = json.loads(path.read_text())
        if not isinstance(data, dict):
            raise ValueError('Chat profile file must be a JSON object.')
        for values in data.values():
            if isinstance(values, dict):
                for name in _LEGACY_PRICE_FIELDS:
                    values.pop(name, None)
        return data

    def load(self, key):
        data = self._read()
        if key not in data and self.fallback_path is not None:
            data = self._read(self.fallback_path)
        values = dict(data.get(key, {}))
        allowed = {field.name for field in fields(ChatProfile)}
        values = {name: value for name, value in values.items() if name in allowed}
        if values.get('window') is None:
            values['window'] = DEFAULT_WINDOW
        return ChatProfile(**values).validate()

    def save(self, key, profile):
        profile.validate()
        data = self._read()
        data[key] = asdict(profile)
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        with NamedTemporaryFile(mode='w', dir=self.path.parent, delete=False) as stream:
            json.dump(data, stream, indent=2)
            temporary = Path(stream.name)
        try:
            temporary.replace(self.path)
        finally:
            temporary.unlink(missing_ok=True)
