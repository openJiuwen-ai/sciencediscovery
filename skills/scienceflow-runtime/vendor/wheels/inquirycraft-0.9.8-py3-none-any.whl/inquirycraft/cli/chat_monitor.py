"""Chat-only configuration and accounting via the public provider observer."""

import json
from copy import copy
from dataclasses import replace
from pathlib import Path

from .chat_profiles import PRESETS, ProfileStore, profile_key
from .usage_records import format_context_tokens, validate_usage_record


class ChatMonitor:
    def __init__(self, options, backend, endpoints, models, pool_size, store=None, *, fallback_pricing=None, pricing_label="Host benchmark", backend_builder=None):
        # Kept as ignored keyword arguments for source compatibility with 0.8 hosts.
        del fallback_pricing, pricing_label
        self.backend = backend
        self.backend_builder = backend_builder
        self.store = store or ProfileStore()
        self.routes = [(endpoints[i % len(endpoints)] if endpoints else '', models[i % len(models)])
                       for i in range(pool_size)]
        self.route_prices = [None] * len(self.routes)
        self.registry_prices = {}
        self.keys = [profile_key(*route) for route in self.routes]
        self.profiles = [self.store.load(key) for key in self.keys]
        self._apply_output_reserves(reset=True)
        self.context_baseline = 0
        self.active = 0
        self.totals = {}
        self._unpriced = {}
        self.seen = set()
        self.last_input = 0
        self.last_context = 0
        self.context_estimate = None
        self.runtime = None
        self.warning = ''
        self.model_registry = None
        self.model_aliases = ()
        self.model_selection = 'auto'
        self._configured_max_tokens = int(options.max_tokens or 32768)
        self._usage_needs_newline = False
        self.path = Path(str(options.session_log) + '.usage.jsonl') if options.session_log else None
        if self.path and self.path.exists():
            with self.path.open(encoding='utf-8', errors='replace') as stream:
                for line in stream:
                    self._usage_needs_newline = not line.endswith('\n')
                    try:
                        self._accept(json.loads(line))
                    except (ValueError, TypeError, KeyError):
                        self.warning = 'Invalid usage records skipped; totals may be incomplete.'

    def configure_model_registry(self, registry, aliases, selection='auto'):
        """Attach the source registry used for safe idle-time model switching."""

        resolved = registry.resolve(aliases, role='code')
        self.model_registry = registry
        self.model_aliases = tuple(aliases)
        self.model_selection = str(selection or 'auto')
        self.route_prices = list(resolved.pricing)
        self.registry_prices = dict(registry.price_table())
        self._reprice_totals()

    async def select_models(self, aliases, selection):
        """Replace the chat provider pool without disturbing conversation state."""

        if self.runtime is None or self.model_registry is None:
            raise ValueError('This runtime has no model registry attached.')
        resolved = self.model_registry.resolve(aliases, role='code')
        selection = str(selection or 'auto').strip().lower()
        routing = {
            'auto': 'sticky_failover',
            'spread': 'round_robin',
            'fixed': 'sticky',
        }.get(selection)
        if routing is None:
            raise ValueError('Model policy must be auto, spread, or fixed.')

        from inquirycraft.llm import LLMFactoryConfig, build_llm

        adapter = self.runtime.llm
        if not hasattr(adapter, 'backend'):
            raise ValueError('The active provider cannot be switched in place.')
        candidate = copy(self)
        candidate.routes = list(zip(resolved.base_urls, resolved.models))
        candidate.keys = [profile_key(*route) for route in candidate.routes]
        candidate.profiles = [self.store.load(key) for key in candidate.keys]
        policy = candidate.policy()
        candidate.route_prices = list(resolved.pricing)
        candidate.registry_prices = dict(self.model_registry.price_table())
        candidate.backend = (
            self.backend_builder(resolved, routing, self._configured_max_tokens)
            if self.backend_builder is not None
            else build_llm(LLMFactoryConfig(
                models=resolved.models, api_keys=resolved.api_keys, base_urls=resolved.base_urls,
                max_tokens=self._configured_max_tokens, routing_mode=routing,
                endpoint_client_kwargs=tuple(
                    {"use_proxy": flag} if flag is not None else {}
                    for flag in resolved.use_proxies
                ),
            ))
        )
        try:
            candidate._apply_output_reserves(reset=True)
            options = replace(self.runtime.options, model=resolved.models[0],
                              model_routing=routing, max_tokens=candidate.output_limit,
                              use_proxies=resolved.use_proxies)
            self.runtime.set_compaction_policy(policy)
        except BaseException:
            await self._close_backend(candidate.backend, 'Previous model retained; new connection cleanup failed.')
            raise
        previous = adapter.backend
        candidate.active = candidate.last_input = candidate.last_context = 0
        candidate.context_estimate = None
        candidate.model_aliases, candidate.model_selection = tuple(aliases), selection
        self.__dict__.update(candidate.__dict__)
        adapter.backend = self.backend
        self.runtime.options = options
        self._reprice_totals()
        await self._close_backend(previous, 'Model switched; previous connection cleanup failed.')
        return resolved

    async def _close_backend(self, backend, warning):
        from inquirycraft.adapters import AskLLMAdapter

        try:
            await AskLLMAdapter(backend).aclose()
        except Exception:
            self.warning = warning

    def policy(self):
        # Failover is chosen after projection, so fit every possible route.
        return min((profile.policy() for profile in self.profiles),
                   key=lambda p: p.max_context_tokens - p.reserve_tokens)

    def bind(self, runtime):
        self.runtime = runtime
        runtime.options = replace(runtime.options, max_tokens=self.output_limit)
        runtime.chat_monitor = self
        return runtime

    def set_profile(self, index, profile):
        self.store.save(self.keys[index], profile)
        self.profiles = [self.store.load(key) for key in self.keys]
        self._apply_output_reserves()
        self.runtime.set_compaction_policy(self.policy())
        self.runtime.options = replace(self.runtime.options, max_tokens=self.output_limit)

    @property
    def output_limit(self):
        """Conservative effective limit across the active routes."""
        return min(self.effective_output_limits)

    def _apply_output_reserves(self, *, reset=False):
        instances = getattr(self.backend, '_instances', [self.backend])
        if reset:
            self._output_limits = [int(getattr(instance, 'max_tokens', 0) or 0) for instance in instances]
        self.effective_output_limits = []
        for i, instance in enumerate(instances):
            profile = self.profiles[i % len(self.profiles)]
            configured = self._output_limits[i] or profile.output_reserve
            effective = min(configured, profile.output_reserve) if profile.window else configured
            self.effective_output_limits.append(effective)
            if hasattr(instance, "max_tokens"):
                instance.max_tokens = effective

    def _accept(self, row):
        incoming, output, cached, baseline = validate_usage_record(row)
        identity = row['id']
        if identity in self.seen:
            return
        self.seen.add(identity)
        total = self.totals.setdefault(row['route'], {'input': 0, 'output': 0, 'cached': 0,
                                                     'cost': 0., 'unknown': 0, 'model': row['model']})
        for name, value in [('input', incoming), ('output', output), ('cached', cached)]:
            total[name] += value
        if row.get('cost') is None:
            total['unknown'] += 1
            if incoming + output > 0:
                unpriced = self._unpriced.setdefault(row['route'], [0, 0, 0, 0])
                for index, value in enumerate((incoming, cached, output, 1)):
                    unpriced[index] += value
        else:
            total['cost'] += row['cost']
        self.active = self.keys.index(row["route"]) if row["route"] in self.keys else -1
        self.last_input = incoming
        self.context_baseline = baseline
        self.context_estimate = None

    def _reprice_totals(self):
        """Backfill unpriced usage without changing historically priced calls."""

        for route, total in self.totals.items():
            price = self.registry_prices.get(total['model'])
            if price is None or route not in self._unpriced:
                continue
            unpriced = self._unpriced.pop(route)
            total['cost'] += price.estimate(*unpriced[:3])
            total['unknown'] -= unpriced[3]

    def __call__(self, observation, context):
        if observation.phase not in {'completed', 'failed'}:
            return
        usage = observation.usage
        if observation.phase == 'failed' and not (usage.input_tokens or usage.output_tokens):
            return
        index = (getattr(observation, 'metadata', None) or {}).get('pool_index')
        if index is None:
            index = getattr(self.backend, '_last_call_pool_index', 0)
        if not isinstance(index, int) or not 0 <= index < len(self.routes):
            index = 0 if len(self.routes) == 1 else -1
        self.active = index
        incoming, output = max(0, usage.input_tokens), max(0, usage.output_tokens)
        cached = min(incoming, max(0, usage.cached_input_tokens))
        windows = [profile.window for profile in self.profiles]
        if windows and all(window is not None for window in windows) and incoming > min(windows):
            self.warning = 'Actual provider input exceeded the configured context window.'
        elif self.warning == 'Actual provider input exceeded the configured context window.':
            self.warning = ''
        price = self.route_prices[index] if index >= 0 else None
        cost = (
            price.estimate(incoming, cached, output)
            if price is not None and incoming + output > 0
            else None
        )
        pricing_source = 'models.json' if price is not None else 'unconfigured'
        row = {'id': (getattr(observation, 'metadata', None) or {}).get('request_id')
                     or f'{context.run_id}:{context.turn_id}:{observation.attempt}',
               'route': self.keys[index] if index >= 0 else 'unknown',
               'model': self.routes[index][1] if index >= 0 else 'unknown route',
               'input': incoming, 'output': output, 'cached': cached, 'cost': cost, 'pricing_source': pricing_source,
               'context_source': 'provider_usage'}
        if row['id'] in self.seen:
            return
        self._accept(row)
        if self.path:
            try:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                with self.path.open('a', encoding='utf-8') as stream:
                    if self._usage_needs_newline:
                        stream.write('\n')
                    self._usage_needs_newline = True
                    stream.write(json.dumps(row) + '\n')
                self._usage_needs_newline = False
            except OSError:
                self.warning = 'Usage persistence failed; totals may not survive restart.'

    def context_compacted(self, estimated_tokens):
        """Display committed projection size without changing usage totals."""
        if type(estimated_tokens) is int and estimated_tokens >= 0:
            self.context_estimate = estimated_tokens

    def stats(self):
        incoming = sum(row['input'] for row in self.totals.values())
        cached = sum(row['cached'] for row in self.totals.values())
        cache = f'{cached / incoming:.0%}' if incoming else '—'
        unknown = any(row['unknown'] for row in self.totals.values())
        cost = '—' if unknown else f"~${sum(row['cost'] for row in self.totals.values()):.4f}"
        windows = [p.window for p in self.profiles]
        window = min(windows) if all(w is not None for w in windows) else None
        decimal = window == PRESETS['1M']
        self.last_context = self.last_input if self.context_estimate is None else self.context_estimate
        actual = format_context_tokens(self.last_context, decimal=decimal) if self.last_input else '—'
        if self.context_estimate is not None:
            actual = '≈' + format_context_tokens(self.context_estimate, decimal=decimal)
        capacity = format_context_tokens(window, capacity=True) if window else 'unset'
        return f'Context {actual}/{capacity}', f'Cache {cache}', f'Cost {cost}'

    def details(self):
        lines = ['Chat session · ' + ' · '.join(self.stats()),
                 'Cache is token-weighted; cost is estimated USD, not a provider bill.',
                 'Context is the latest provider input; ≈ marks the compacted conversation estimate (excluding tools). Cost is session-wide.',
                 'Pool context uses the smallest configured budget for safe failover.']
        lines.append(f"Effective output limit: {self.output_limit:,} tokens (request limit capped by profile reserve).")
        lines.append(f"Chat profiles: {self.store.path}")
        for key, total in self.totals.items():
            lines.append(f"{total['model']} [{key[:8]}] · input {total['input']} · cached {total['cached']} · output {total['output']} · cost "
                         + ('—' if total['unknown'] else f"${total['cost']:.4f}"))
        lines.append('Pricing: models.json; models without all three rates show unknown cost.')
        if self.warning:
            lines.append(self.warning)
        return '\n'.join(lines)
