"""Opt-in, bounded provider recovery for interactive TUI chat only."""

from inquirycraft.llm import SameRoundRetryPolicy
from inquirycraft.runtime.llm_retry import default_same_round_retry_adapter


def tui_retry_adapter(retry):
    if not isinstance(retry.error, Exception):
        return None
    replacement = default_same_round_retry_adapter(retry)
    if replacement is not None:
        return replacement
    # Provider requests have not committed tool calls at this point. Never replay
    # tools here, or retry arbitrary application errors/cancellation.
    try:
        import httpx
    except ImportError:
        pass
    else:
        if isinstance(retry.error, httpx.TimeoutException):
            return retry.request
    try:
        from openai import APIConnectionError, APIStatusError
    except ImportError:
        return None
    if isinstance(retry.error, APIConnectionError):
        return retry.request
    if isinstance(retry.error, APIStatusError) and (
        retry.error.status_code in {408, 409, 429} or 500 <= retry.error.status_code < 600
    ):
        return retry.request
    return None


def configure_tui_recovery(runtime):
    configure = getattr(runtime, "set_llm_retry_policy", None)
    if callable(configure):
        configure(SameRoundRetryPolicy(3, 1.0, 4.0), tui_retry_adapter)
