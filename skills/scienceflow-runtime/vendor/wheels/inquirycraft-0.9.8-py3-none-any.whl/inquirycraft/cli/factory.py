from __future__ import annotations

from dataclasses import replace

import click

from inquirycraft.events import EventSink
from inquirycraft.llm import SameRoundRetryPolicy
from inquirycraft.memory import Conversation, JsonlConversationStore
from inquirycraft.runtime import AgentRuntime, RuntimeOptions
from inquirycraft.tools import default_tools

from .chat_monitor import ChatMonitor


class DefaultRuntimeFactory:
    def create_runtime(
        self,
        options: RuntimeOptions,
        *,
        api_key: str,
        base_url: str | None,
        event_sink: EventSink,
    ) -> AgentRuntime:
        # Provider dependencies stay optional until a model command is invoked.
        from inquirycraft.adapters import AskLLMAdapter
        from inquirycraft.llm import LLMFactoryConfig, build_llm

        from .pool_config import split_values

        models = split_values(options.model)
        keys = split_values(api_key)
        if not models or not keys:
            raise click.ClickException("models and api_keys must each contain at least one value")
        try:
            client = AskLLMAdapter(
                build_llm(
                    LLMFactoryConfig(
                        models=models,
                        api_keys=keys,
                        base_urls=split_values(base_url),
                        max_tokens=options.max_tokens or 32768,
                        routing_mode=options.model_routing,
                        endpoint_client_kwargs=tuple(
                            {"use_proxy": flag} if flag is not None else {}
                            for flag in options.use_proxies
                        ),
                    )
                )
            )
        except ValueError as exc:
            raise click.ClickException(str(exc)) from exc
        conversation_store = (
            JsonlConversationStore(options.session_log) if options.session_log is not None else None
        )
        conversation = (
            conversation_store.load() if conversation_store is not None else Conversation()
        )
        monitor = ChatMonitor(options, client.backend, split_values(base_url), models, len(keys))
        return monitor.bind(AgentRuntime(
            llm=client,
            llm_retry_policy=SameRoundRetryPolicy(3, 1.0, 4.0),
            compaction_policy=monitor.policy(),
            provider_observer=monitor,
            options=replace(options, model=models[0]),
            tools=default_tools(),
            event_sink=event_sink,
            conversation=conversation,
            conversation_store=conversation_store,
        ))
