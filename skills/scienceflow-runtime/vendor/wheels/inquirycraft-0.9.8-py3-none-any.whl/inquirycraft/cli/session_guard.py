"""Keep all selected session logs exclusive for an entire CLI invocation."""

from contextlib import ExitStack
from functools import wraps
from pathlib import Path

import click

from inquirycraft.memory.file_lock import FileInUseError, exclusive_file_lock


def guard_session(function):
    @wraps(function)
    def guarded(*args, **kwargs):
        paths = sorted({Path(value).expanduser().resolve()
                        for name in ('session_log', 'operation_log', 'event_log')
                        if (value := kwargs.get(name))})
        with ExitStack() as locks:
            try:
                for path in paths:
                    locks.enter_context(exclusive_file_lock(path.with_name(path.name + '.writer.lock')))
            except FileInUseError as exc:
                raise click.ClickException(
                    f'Log file is already in use: {path}. '
                    'Close the other writer or use a different log path.'
                ) from exc
            return function(*args, **kwargs)

    return guarded
