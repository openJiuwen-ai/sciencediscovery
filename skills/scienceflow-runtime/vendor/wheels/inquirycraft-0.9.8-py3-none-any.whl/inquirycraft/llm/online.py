"""OpenAI-compatible online LLM runtime.

The public ``OnlineLLM`` entry point is intentionally small. Request policy,
provider transports, and tool streaming live in focused modules so each can
evolve and be tested independently without changing host call sites.
"""

from __future__ import annotations

import os
from typing import Any

import httpx
from openai import AsyncAzureOpenAI, AsyncOpenAI
from pydantic import ConfigDict, Field, model_validator

from .base import BaseLLM
from .online_support import RequestPolicyMixin, cached_input_tokens
from .public_requests import ProviderTransportMixin, PublicRequestMixin
from .tool_args import WriteToolArgStreamDecoder as WriteToolArgStreamDecoder
from .tool_args import _WriteToolArgStreamDecoder as _WriteToolArgStreamDecoder
from .tool_args import chunked_guard_put, chunked_put
from .tool_requests import ToolRequestMixin


def _proxy_from_environment(base_url: str | None) -> httpx.Proxy:
    scheme = httpx.URL(base_url or "https://api.openai.com/v1").scheme
    names = (
        ("HTTP_PROXY", "http_proxy", "ALL_PROXY", "all_proxy", "HTTPS_PROXY", "https_proxy")
        if scheme == "http"
        else ("HTTPS_PROXY", "https_proxy", "ALL_PROXY", "all_proxy", "HTTP_PROXY", "http_proxy")
    )
    proxy_url = next((value.strip() for name in names if (value := os.environ.get(name))), "")
    if not proxy_url:
        raise ValueError("use_proxy=true requires an HTTP(S) or ALL_PROXY environment variable")
    user, password = os.environ.get("USER_NAME", ""), os.environ.get("USER_PWD", "")
    try:
        return httpx.Proxy(proxy_url, auth=(user, password) if user and password else None)
    except ValueError as exc:
        raise ValueError("Invalid proxy URL configuration") from exc


class OnlineLLM(
    PublicRequestMixin,
    ToolRequestMixin,
    ProviderTransportMixin,
    RequestPolicyMixin,
    BaseLLM,
):
    """Online provider implementation retaining the historical API surface."""

    client: Any = Field(default=None, exclude=True)
    model_config = ConfigDict(arbitrary_types_allowed=True, extra="allow")

    @model_validator(mode="after")
    def init_onlinellm(self) -> "OnlineLLM":
        if self.http_asyncclient is None and self.use_proxy is not None:
            # Explicit model routing ignores NO_PROXY, while retaining custom CA trust.
            client_kwargs: dict[str, Any] = {"verify": httpx.create_ssl_context(trust_env=True)}
            if self.use_proxy:
                client_kwargs["proxy"] = _proxy_from_environment(self.base_url)
            self.http_asyncclient = httpx.AsyncClient(
                trust_env=False,
                timeout=httpx.Timeout(600.0, connect=5.0),
                limits=httpx.Limits(max_connections=1000, max_keepalive_connections=100),
                follow_redirects=True,
                **client_kwargs,
            )
        if self.api_type == "azure":
            self.client = AsyncAzureOpenAI(
                base_url=self.base_url,
                api_key=self.api_key,
                default_headers=self.headers,
                api_version=self.api_version,
                http_client=self.http_asyncclient,
            )
        else:
            self.client = AsyncOpenAI(
                api_key=self.api_key,
                base_url=self.base_url,
                default_headers=self.headers,
                http_client=self.http_asyncclient,
            )
        return self


# Private aliases are preserved because historical tests and integrations import them.
_extract_cached_input_tokens = cached_input_tokens
_chunked_put = chunked_put
_chunked_guard_put = chunked_guard_put
