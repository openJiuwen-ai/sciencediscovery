from __future__ import annotations


class IncompleteStreamError(ValueError):
    """An unfinished provider stream; safe to retry before executing tools."""

    def __init__(self, message: str, *, phase: str = "stream_decode") -> None:
        self.phase = phase
        self.finish_reason = "unknown"
        self.usage = None
        self.usage_known = False
        super().__init__(message)


class UnusableResponseError(ValueError):
    """A completed response needs request adaptation, not an identical retry."""

    def __init__(self, message: str, *, finish_reason: str | None = None) -> None:
        self.finish_reason = finish_reason or "unknown"
        super().__init__(f"{message}; finish_reason={self.finish_reason}")


class TruncatedResponseError(UnusableResponseError):
    """The output budget ended before a usable answer or tool call was produced."""


def validate_final_response(
    *,
    content: str | None,
    reasoning: str | None,
    finish_reason: str | None,
    empty_message: str,
    has_tool_calls: bool = False,
    interrupted: bool = False,
) -> None:
    """Reject missing answers without ever promoting reasoning to an answer.

    Partial answers retain their historical behavior and finish metadata. A
    caller's interruption (including first-tool early stop) is not a provider
    failure. Truly empty responses retain the existing transient retry policy.
    """
    if interrupted or has_tool_calls or (content or "").strip():
        return
    if finish_reason == "length":
        raise TruncatedResponseError(
            "LLM output was truncated before an answer or tool call; increase max_tokens",
            finish_reason=finish_reason,
        )
    if finish_reason == "content_filter":
        raise UnusableResponseError("LLM output was filtered", finish_reason=finish_reason)
    if (reasoning or "").strip():
        raise UnusableResponseError(
            "LLM returned reasoning without an answer or tool call",
            finish_reason=finish_reason,
        )
    raise ValueError(empty_message)




def is_missing_reasoning_replay_error(exc: BaseException) -> bool:
    """Return whether a provider requires assistant reasoning metadata replay."""

    text = str(exc).lower()
    return all(pattern in text for pattern in ("reasoning_content", "thinking mode"))
