from __future__ import annotations

import asyncio
import contextvars
from dataclasses import dataclass, field


@dataclass
class GuardStreamChunk:
    """Non-answer stream text retained for guards and typed consumers."""

    text: str
    channel: str


class ChannelStreamChunk(str):
    """String-compatible preview tagged with its semantic output channel."""

    channel: str

    def __new__(cls, text: str, *, channel: str) -> "ChannelStreamChunk":
        value = super().__new__(cls, text)
        value.channel = channel
        return value


@dataclass
class StreamHandle:
    """Per-call queue and interruption signal for one streaming completion."""

    queue: asyncio.Queue = field(default_factory=asyncio.Queue)
    _event: asyncio.Event = field(default_factory=asyncio.Event)
    _eos_sent: bool = field(default=False, repr=False)

    @property
    def interrupted(self) -> bool:
        return self._event.is_set()

    def interrupt(self) -> None:
        """Stop the stream, discard queued chunks and enqueue one EOS marker."""
        if self._event.is_set():
            return
        self._event.set()
        while not self.queue.empty():
            try:
                self.queue.get_nowait()
            except asyncio.QueueEmpty:
                break
        self._send_eos()

    def stop(self) -> None:
        """Stop new chunks but preserve queued previews before the EOS marker."""
        if self._event.is_set():
            return
        self._event.set()
        self._send_eos()

    async def put(self, chunk: str | None, *, channel: str = "content") -> None:
        if not self._event.is_set():
            value = chunk
            if chunk is not None and channel != "content":
                value = ChannelStreamChunk(chunk, channel=channel)
            await self.queue.put(value)

    async def put_guard(self, chunk: str, *, channel: str) -> None:
        if chunk and not self._event.is_set():
            await self.queue.put(GuardStreamChunk(text=chunk, channel=channel))

    def finish(self) -> None:
        if not self._event.is_set():
            self._send_eos()

    def _send_eos(self) -> None:
        if self._eos_sent:
            return
        self._eos_sent = True
        self.queue.put_nowait(None)


@dataclass
class CallStats:
    """Per-call provider statistics."""

    input_tokens: int = 0
    output_tokens: int = 0
    ttft: float = 0.0
    tpot: float = 0.0
    finish_reason: str = "unknown"
    input_cached_tokens: int = 0


_CALL_STATS: contextvars.ContextVar[dict[int, CallStats]] = contextvars.ContextVar(
    "_inquirycraft_llm_call_stats"
)


class CallStatsMixin:
    def _save_call_stats(self, stats: CallStats) -> None:
        try:
            store = dict(_CALL_STATS.get())
        except LookupError:
            store = {}
        store[id(self)] = stats
        _CALL_STATS.set(store)

    def _get_call_stats(self) -> CallStats:
        try:
            return _CALL_STATS.get().get(id(self), CallStats())
        except LookupError:
            return CallStats()

    @property
    def _last_call_input_tokens(self) -> int:
        return self._get_call_stats().input_tokens

    @property
    def _last_call_output_tokens(self) -> int:
        return self._get_call_stats().output_tokens

    @property
    def _last_call_ttft(self) -> float:
        return self._get_call_stats().ttft

    @property
    def _last_call_tpot(self) -> float:
        return self._get_call_stats().tpot

    @property
    def _last_call_input_cached_tokens(self) -> int:
        return self._get_call_stats().input_cached_tokens

    @property
    def _last_finish_reason(self) -> str:
        return self._get_call_stats().finish_reason
