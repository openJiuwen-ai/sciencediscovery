from __future__ import annotations

from typing import Any, Literal, Protocol

ROLE_VALUES = ("system", "user", "assistant", "tool")
TOOL_CHOICE_TYPE = Literal["none", "auto", "required"]


class MessageLike(Protocol):
    """Structural message input accepted by the provider boundary."""

    def to_dict(self) -> dict[str, Any]: ...


class MessageFormattingMixin:
    def estimate_tokens(self, text: str) -> int:
        from .utils import estimate_tokens

        return estimate_tokens(
            text,
            model=self.model,
            encoding_name=self.tiktoken_encoding,
            use_tiktoken=self.use_tiktoken_for_estimation,
            fallback_chinese_ratio=self.chinese_token_ratio,
            fallback_english_ratio=self.english_token_ratio,
            fallback_symbol_ratio=self.symbol_token_ratio,
        )

    @staticmethod
    def format_messages(messages: list[dict | MessageLike]) -> list[dict]:
        formatted: list[dict] = []
        for message in messages:
            if not isinstance(message, dict) and hasattr(message, "to_dict"):
                message = message.to_dict()
            if not isinstance(message, dict):
                raise TypeError(f"Unsupported message type: {type(message)}")
            if "role" not in message:
                raise ValueError("Message dict must contain 'role' field")
            if (
                "content" in message
                or "tool_calls" in message
                or message.get("reasoning_content") is not None
            ):
                formatted.append(message)
        for message in formatted:
            if message["role"] not in ROLE_VALUES:
                raise ValueError(f"Invalid role: {message['role']}")
        return formatted

    def _format_request_messages(
        self,
        messages: list[dict | MessageLike],
        system_msgs: list[dict | MessageLike] | None = None,
    ) -> list[dict]:
        formatted_messages = self.format_messages(messages)
        if not system_msgs:
            return formatted_messages
        formatted_system = self.format_messages(system_msgs)
        if self.coalesce_system_messages and len(formatted_system) > 1:
            formatted_system = [self._coalesce_system_prefix(formatted_system)]
        return formatted_system + formatted_messages

    @staticmethod
    def _coalesce_system_prefix(messages: list[dict]) -> dict:
        if any(message.get("role") != "system" for message in messages):
            raise ValueError(
                "coalesce_system_messages requires every system_msgs entry to have role='system'"
            )
        contents = [message.get("content") for message in messages]
        if any(content is not None and not isinstance(content, str) for content in contents):
            raise TypeError(
                "coalesce_system_messages currently supports string system-message content only"
            )
        merged = dict(messages[0])
        merged["content"] = "\n\n".join(
            content for content in contents if isinstance(content, str) and content
        )
        return merged
