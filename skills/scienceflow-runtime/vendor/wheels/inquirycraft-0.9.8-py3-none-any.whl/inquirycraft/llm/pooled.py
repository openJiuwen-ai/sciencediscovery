from __future__ import annotations

import asyncio
import contextvars
import logging
import os
import time
from collections.abc import Mapping, Sequence
from typing import Any

from openai import RateLimitError

from inquirycraft.llm import (
    KeyPool,
    retry_after_seconds,
    stable_endpoint_index,
)
from inquirycraft.llm.online import OnlineLLM
from inquirycraft.llm.pool_retry import PoolRetryMixin


class PooledLLM(PoolRetryMixin):
    """Domain-independent failover pool for ``OnlineLLM`` clients."""

    runtime_logger = logging.getLogger("inquirycraft")
    rate_limit_max_wait_env = "INQUIRYCRAFT_POOL_RL_MAX_WAIT_SEC"
    default_rate_limit_max_wait_sec = 300.0
    default_soft_retry_delay_sec = 0.5
    default_endpoint_attempts = 3
    default_transient_retry_passes = 3
    default_transient_retry_base_delay_sec = 1.0
    default_transient_retry_max_delay_sec = 4.0

    def __init__(
        self,
        instances: list[OnlineLLM],
        *,
        routing_mode: str = "round_robin",
        sticky_id: str = "",
        sticky_primary_index: int | None = None,
        rate_limit_cooldown_sec: float = 60.0,
        connection_cooldown_sec: float = 15.0,
    ) -> None:
        if not instances:
            raise ValueError("PooledLLM requires at least one OnlineLLM instance")
        self._instances = instances
        self._pool = self._create_key_pool(
            [(str(inst.base_url or ""), str(inst.api_key or "")) for inst in instances]
        )
        self._last_idx = 0
        self._stats_index = contextvars.ContextVar(f"pool_stats_{id(self)}", default=None)
        self._routing_mode = str(routing_mode or "round_robin").strip().lower()
        self._sticky_id = str(sticky_id or "")
        self._sticky_enabled = self._routing_mode in {
            "sticky",
            "task_sticky",
            "sticky_failover",
            "task_sticky_failover",
        }
        if sticky_primary_index is None:
            self._primary_idx = stable_endpoint_index(self._sticky_id, self._pool.size)
        else:
            self._primary_idx = max(0, min(int(sticky_primary_index), self._pool.size - 1))
        self._rate_limit_cooldown_sec = max(0.0, float(rate_limit_cooldown_sec))
        self._connection_cooldown_sec = max(0.0, float(connection_cooldown_sec))
        self._last_pool_index: int | None = None
        self._last_call_routing_mode = self._routing_mode
        self._last_failover_count = 0

    @classmethod
    def _create_online_llm(cls, **kwargs: Any) -> OnlineLLM:
        return OnlineLLM(**kwargs)

    def _create_key_pool(self, endpoints: list[tuple[str, str]]) -> KeyPool:
        return KeyPool(endpoints, logger=self.runtime_logger)

    def _soft_retry_delay_sec(self) -> float:
        return self.default_soft_retry_delay_sec

    async def _sleep(self, delay: float) -> None:
        await asyncio.sleep(delay)

    @classmethod
    def from_endpoints(
        cls,
        endpoints: list[tuple[str, str]],
        *,
        endpoint_models: list[str] | None = None,
        endpoint_client_kwargs: Sequence[Mapping[str, Any]] = (),
        **llm_kwargs: Any,
    ) -> PooledLLM:
        pool_kwargs = {
            name: llm_kwargs.pop(name)
            for name in (
                "routing_mode",
                "sticky_id",
                "sticky_primary_index",
                "rate_limit_cooldown_sec",
                "connection_cooldown_sec",
            )
            if name in llm_kwargs
        }
        models = [str(item).strip() for item in (endpoint_models or []) if str(item).strip()]
        if models and len(models) != len(endpoints):
            raise ValueError(
                f"endpoint_models length {len(models)} must match endpoints length {len(endpoints)}"
            )
        if endpoint_client_kwargs and len(endpoint_client_kwargs) != len(endpoints):
            raise ValueError("endpoint_client_kwargs must match endpoints length")
        instances: list[OnlineLLM] = []
        for idx, (url, key) in enumerate(endpoints):
            endpoint_kwargs = dict(llm_kwargs)
            if endpoint_client_kwargs:
                endpoint_kwargs.update(endpoint_client_kwargs[idx])
            if models:
                endpoint_kwargs["model"] = models[idx]
            instances.append(cls._create_online_llm(base_url=url, api_key=key, **endpoint_kwargs))
        return cls(instances, **pool_kwargs)

    @classmethod
    def from_single(cls, llm: OnlineLLM) -> PooledLLM:
        return cls([llm])

    def _next(
        self,
        *,
        tried: set[int] | None = None,
        allowed: set[int] | None = None,
    ) -> tuple[int, OnlineLLM]:
        tried = tried or set()
        if (
            self._sticky_enabled
            and (allowed is None or self._primary_idx in allowed)
            and self._primary_idx not in tried
            and self._pool.is_available(self._primary_idx)
        ):
            idx = self._primary_idx
        else:
            idx, _, _ = self._pool.pick(exclude=tried, include=allowed)
        self._last_idx = idx
        return idx, self._instances[idx]

    def _select_model_group(self) -> tuple[set[int], int | None]:
        """Choose one model for this call and return only its endpoint slots."""

        if self._sticky_enabled:
            initial_idx = self._primary_idx
        else:
            initial_idx, _ = self._next()
        selected_model = str(self._instances[initial_idx].model)
        allowed = {
            idx
            for idx, instance in enumerate(self._instances)
            if str(instance.model) == selected_model
        }
        return allowed, initial_idx if not self._sticky_enabled else None

    def _record_success(self, idx: int, failover_count: int) -> None:
        self._pool.reset_cooldown(idx)
        self._record_attempt(idx, failover_count)

    def _record_attempt(self, idx: int, failover_count: int) -> None:
        self._stats_index.set((idx, failover_count))
        self._last_pool_index = idx
        self._last_call_routing_mode = self._routing_mode
        self._last_failover_count = failover_count

    @property
    def _last_call_pool_index(self) -> int | None:
        route = self._stats_index.get()
        return route[0] if route is not None else self._last_pool_index

    @property
    def _last_call_failover_count(self) -> int:
        route = self._stats_index.get()
        return route[1] if route is not None else self._last_failover_count

    def _record_rate_limit(self, idx: int, exc: RateLimitError, *, soft_retry: bool) -> None:
        cooldown = retry_after_seconds(exc, self._rate_limit_cooldown_sec)
        self._pool.cooldown(idx, cooldown)
        if not soft_retry and "function call turn" in str(exc).lower():
            self.runtime_logger.warning(
                "[PooledLLM] RateLimitError mentions chat-turn wording — "
                "treating as rate limit (upstream may wrap quota errors)."
            )
        message = (
            "[PooledLLM] Key #%d soft-retry hit rate limit, trying next..."
            if soft_retry
            else "[PooledLLM] Key #%d rate-limited, trying next..."
        )
        self.runtime_logger.warning(message, idx)

    async def _call_with_failover(self, method: str, *args: Any, **kwargs: Any) -> Any:
        configured_max_wait = os.getenv(self.rate_limit_max_wait_env)
        max_wait = float(configured_max_wait or self.default_rate_limit_max_wait_sec)
        deadline = time.monotonic() + max(0.0, max_wait)
        last_err: Exception | None = None
        failover_count = 0
        transient_retries = 0
        allowed, initial_idx = self._select_model_group()

        while time.monotonic() < deadline:
            last_err = None
            tried: set[int] = set()
            for _ in range(len(allowed)):
                if initial_idx is not None and initial_idx not in tried:
                    idx = initial_idx
                    llm = self._instances[idx]
                    self._last_idx = idx
                    initial_idx = None
                else:
                    idx, llm = self._next(tried=tried, allowed=allowed)
                if idx in tried:
                    continue
                tried.add(idx)
                is_failover = self._sticky_enabled and idx != self._primary_idx
                if is_failover:
                    failover_count += 1
                self._record_attempt(idx, failover_count)
                succeeded, result, last_err = await self._attempt_endpoint(
                    method,
                    llm,
                    idx=idx,
                    failover_count=failover_count,
                    args=args,
                    kwargs=kwargs,
                )
                if succeeded:
                    return result

            if last_err is None:
                raise RuntimeError("PooledLLM: no keys available")
            if await self._wait_for_rate_limit(
                last_err,
                deadline=deadline,
                max_wait=max_wait,
                allowed=allowed,
            ):
                continue
            if transient_retries < self.default_transient_retry_passes:
                transient_retries += 1
                if await self._wait_for_transient_retry(
                    last_err,
                    deadline=deadline,
                    retry_number=transient_retries,
                    allowed=allowed,
                ):
                    continue
            raise last_err

        if last_err is not None:
            raise last_err
        raise RuntimeError("PooledLLM: retry budget expired without an endpoint result")

    async def ask(self, *args: Any, **kwargs: Any) -> str:
        return await self._call_with_failover("ask", *args, **kwargs)

    async def ask_tool(self, *args: Any, **kwargs: Any) -> Any:
        return await self._call_with_failover("ask_tool", *args, **kwargs)

    async def ask_tool_stream(self, *args: Any, **kwargs: Any) -> Any:
        return await self._call_with_failover("ask_tool_stream", *args, **kwargs)

    async def ask_logits(self, *args: Any, **kwargs: Any) -> Any:
        return await self._call_with_failover("ask_logits", *args, **kwargs)

    async def ask_vllm_logits(self, *args: Any, **kwargs: Any) -> Any:
        return await self._call_with_failover("ask_vllm_logits", *args, **kwargs)

    async def ask_embedding(self, *args: Any, **kwargs: Any) -> Any:
        return await self._call_with_failover("ask_embedding", *args, **kwargs)

    async def interrupt(self) -> None:
        for instance in self._instances:
            await instance.interrupt()

    _STATS_FIELDS = frozenset(
        {
            "_last_call_input_tokens",
            "_last_call_output_tokens",
            "_last_call_input_cached_tokens",
            "_last_call_ttft",
            "_last_call_tpot",
            "_last_finish_reason",
        }
    )

    def __getattr__(self, name: str) -> Any:
        if name in self._STATS_FIELDS:
            route = self._stats_index.get()
            idx = route[0] if route is not None else self._last_idx
            return getattr(self._instances[idx], name)
        return getattr(self._instances[self._last_idx], name)

    def __repr__(self) -> str:
        models = {str(instance.model) for instance in self._instances}
        return f"PooledLLM(keys={self._pool.size}, models={models})"
