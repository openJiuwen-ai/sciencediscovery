from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Protocol, runtime_checkable

from .models import CompletionRequest, CompletionResult, StreamChunk


@runtime_checkable
class LLMClient(Protocol):
    async def complete(self, request: CompletionRequest) -> CompletionResult: ...

    def stream(self, request: CompletionRequest) -> AsyncIterator[StreamChunk]: ...

    async def aclose(self) -> None: ...
