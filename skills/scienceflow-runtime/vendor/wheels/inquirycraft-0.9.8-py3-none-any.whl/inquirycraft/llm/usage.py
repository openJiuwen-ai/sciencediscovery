# SPDX-License-Identifier: MIT

"""Historical token usage tracker retained by the compatibility adapter."""

from pydantic import model_validator


class TokenUsageTracker:
    """Tracks token usage"""

    total_input_tokens: int = 0
    total_output_tokens: int = 0
    usage_history: list = []

    @model_validator(mode="after")
    def initialize(self) -> "TokenUsageTracker":
        """Initialize the TokenUsageTracker instance.
        Returns:
            TokenUsageTracker: The initialized TokenUsageTracker instance.
        """
        self.usage_history = []
        self.total_input_tokens = 0
        self.total_output_tokens = 0
        return self

    def add_usage(self, model, input_tokens, output_tokens):
        """Add token usage for a specific API call"""
        usage_record = {
            "model": model,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": input_tokens + output_tokens,
        }

        self.total_input_tokens += input_tokens
        self.total_output_tokens += output_tokens
        self.usage_history.append(usage_record)

        return usage_record

    def get_summary(self):
        """Get a summary of token usage and costs"""
        return {
            "total_input_tokens": self.total_input_tokens,
            "total_output_tokens": self.total_output_tokens,
            "total_tokens": self.total_input_tokens + self.total_output_tokens,
            "call_count": len(self.usage_history),
            "history": self.usage_history,
        }

    def reset(self):
        """Clear the usage history"""
        self.usage_history = []
        self.total_input_tokens = 0
        self.total_output_tokens = 0
