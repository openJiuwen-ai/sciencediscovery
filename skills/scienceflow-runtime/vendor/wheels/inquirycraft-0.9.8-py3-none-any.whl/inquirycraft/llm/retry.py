from __future__ import annotations

from dataclasses import dataclass

from .errors import IncompleteStreamError, UnusableResponseError

_RETRYABLE_TOOL_STREAM_MESSAGES = (
    "Empty response from streaming tool LLM",
    "Incomplete streaming tool call",
)


@dataclass(frozen=True, slots=True)
class SameRoundRetryPolicy:
    """Provider-neutral attempt and exponential-backoff policy.

    ``attempt`` is zero-based and identifies the attempt that just failed. The
    policy performs no sleeping or logging so an embedding runtime retains control
    of cancellation, stream cleanup, and externally visible logs.
    """

    max_attempts: int
    base_delay_sec: float
    max_delay_sec: float

    def can_retry(self, attempt: int) -> bool:
        return attempt + 1 < self.max_attempts

    def delay_after(self, attempt: int) -> float:
        return min(self.base_delay_sec * (2**attempt), self.max_delay_sec)


def is_retryable_empty_tool_stream_error(exc: BaseException) -> bool:
    """Return whether retrying the same tool-stream round is safe."""

    if isinstance(exc, IncompleteStreamError):
        return True
    if isinstance(exc, UnusableResponseError):
        return False
    if isinstance(exc, ValueError):
        message = str(exc)
        return any(marker in message for marker in _RETRYABLE_TOOL_STREAM_MESSAGES)

    # HTTP support belongs to the ``openai`` extra. Importing the minimal package
    # must not require httpx.
    try:
        import httpx
    except ImportError:
        return False
    return isinstance(exc, httpx.TransportError) and not isinstance(
        exc,
        httpx.TimeoutException,
    )
