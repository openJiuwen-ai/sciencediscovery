"""Incremental rendering for streamed tool-call arguments."""

from __future__ import annotations

import asyncio
import json
import re
from typing import Any

from .stream_types import StreamHandle

_CONTENT_KEY_RE = re.compile(r'"content"\s*:\s*"')
_PATH_RE = re.compile(r'"path"\s*:\s*"((?:[^"\\]|\\.)*)"')
_CHUNK_CHARS = 128
_ESCAPES = {
    "n": "\n",
    "r": "\r",
    "t": "\t",
    '"': '"',
    "\\": "\\",
    "/": "/",
    "b": "\b",
    "f": "\f",
}


async def chunked_put(
    handle: StreamHandle,
    text: str,
    *,
    channel: str = "content",
) -> None:
    """Enqueue text in bounded chunks so terminal consumers can render promptly."""
    for start in range(0, len(text), _CHUNK_CHARS):
        await handle.put(text[start : start + _CHUNK_CHARS], channel=channel)
        await asyncio.sleep(0)


async def chunked_guard_put(handle: StreamHandle, text: str, *, channel: str) -> None:
    """Feed hidden output to guards without displaying it."""
    for start in range(0, len(text), _CHUNK_CHARS):
        if handle.interrupted:
            break
        await handle.put_guard(text[start : start + _CHUNK_CHARS], channel=channel)
        await asyncio.sleep(0)


class WriteToolArgStreamDecoder:
    """Incrementally decode the JSON ``content`` value of a write tool call."""

    @staticmethod
    def ensure_state(slot: dict[str, Any]) -> dict[str, Any]:
        return slot.setdefault(
            "_write_stream_decode",
            {"phase": "find", "i": 0, "escape": False, "unicode_buf": "", "header": False},
        )

    @staticmethod
    def _unescape(fragment: str) -> str:
        try:
            return json.loads(f'"{fragment}"') if fragment else ""
        except json.JSONDecodeError:
            return fragment.replace("\\/", "/")

    @staticmethod
    def _flush(output: list[str], chunks: list[str]) -> None:
        if output:
            chunks.append("".join(output))
            output.clear()

    @classmethod
    def _decode_available(cls, args: str, state: dict[str, Any]) -> list[str]:
        chunks: list[str] = []
        output: list[str] = []
        index = int(state["i"])
        escaped = bool(state["escape"])
        unicode_buf = str(state["unicode_buf"])
        while index < len(args):
            char = args[index]
            if unicode_buf:
                if char in "0123456789abcdefABCDEF" and len(unicode_buf) < 5:
                    unicode_buf += char
                    index += 1
                    if len(unicode_buf) == 5:
                        output.append(chr(int(unicode_buf[1:], 16)))
                        unicode_buf = ""
                    if len(output) >= _CHUNK_CHARS:
                        cls._flush(output, chunks)
                    continue
                output.extend(unicode_buf)
                unicode_buf = ""
                escaped = False
                continue
            if escaped:
                if char == "u":
                    unicode_buf = "u"
                else:
                    output.append(_ESCAPES.get(char, char))
                escaped = False
                index += 1
            elif char == "\\":
                escaped = True
                index += 1
            elif char == '"':
                state.update(phase="done", i=index + 1, escape=False, unicode_buf="")
                cls._flush(output, chunks)
                return chunks
            else:
                output.append(char)
                index += 1
            if len(output) >= _CHUNK_CHARS:
                cls._flush(output, chunks)
        state.update(i=index, escape=escaped, unicode_buf=unicode_buf)
        cls._flush(output, chunks)
        return chunks

    @classmethod
    async def feed(cls, slot: dict[str, Any], handle: StreamHandle) -> None:
        args = str(slot.get("arguments") or "")
        state = cls.ensure_state(slot)
        if state["phase"] == "done":
            return
        if state["phase"] == "find":
            match = _CONTENT_KEY_RE.search(args)
            if not match:
                return
            state.update(phase="body", i=match.end())
            if not state["header"]:
                state["header"] = True
                path_match = _PATH_RE.search(args[: match.end()])
                path = cls._unescape(path_match.group(1)) if path_match else "?"
                await handle.put(f"\n[write -> {path}]\n", channel="tool_preview")
                await asyncio.sleep(0)
        for chunk in cls._decode_available(args, state):
            await chunked_put(handle, chunk, channel="tool_preview")


# Historical private name remains import-compatible while the implementation is owned here.
_WriteToolArgStreamDecoder = WriteToolArgStreamDecoder
