"""Public online LLM request methods and their historical retry policy."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from openai import APIError, AuthenticationError, OpenAIError, RateLimitError
from tenacity import (
    retry,
    retry_if_exception_type,
    retry_if_not_exception_type,
    stop_after_attempt,
    wait_random_exponential,
)

from .errors import IncompleteStreamError, UnusableResponseError
from .logprob_stream import logprob_request
from .message_format import MessageLike
from .stream_types import StreamHandle
from .text_stream import stream_request

logger = logging.getLogger(__name__)


class PublicRequestMixin:
    @retry(
        wait=wait_random_exponential(min=2, max=120),
        stop=stop_after_attempt(10),
        retry=retry_if_exception_type() & retry_if_not_exception_type((UnusableResponseError, IncompleteStreamError)),
    )
    async def ask(
        self,
        messages: list[dict | MessageLike],
        system_msgs: list[dict | MessageLike] | None = None,
        stream: bool = True,
        temperature: float | None = None,
        *,
        stream_handle: StreamHandle | None = None,
        timeout: float | None = None,
        **kwargs: Any,
    ) -> str:
        try:
            formatted = self._format_request_messages(messages, system_msgs)
            try:
                return await self._stream_request(
                    formatted, stream, temperature, handle=stream_handle, timeout=timeout
                )
            except ValueError as error:
                if "Empty response from streaming LLM" not in str(error) or not stream:
                    raise
                logger.warning("[ask] Empty streaming response; using non-stream fallback")
                await asyncio.sleep(2)
                return await self._stream_request(
                    formatted, False, temperature, handle=None, timeout=timeout
                )
        except Exception as error:
            logger.error("Unexpected error in ask: %s", error)
            raise

    @retry(wait=wait_random_exponential(min=1, max=60), stop=stop_after_attempt(6))
    async def ask_logits(
        self,
        messages: list[dict | MessageLike],
        system_msgs: list[dict | MessageLike] | None = None,
        stream: bool = True,
        temperature: float | None = None,
        **kwargs: Any,
    ) -> tuple[str, dict[str, list[float]]]:
        formatted = self._format_request_messages(messages, system_msgs)
        return await self._stream_request_logits(formatted, temperature, stream)

    @retry(wait=wait_random_exponential(min=1, max=60), stop=stop_after_attempt(6))
    async def ask_vllm_logits(
        self,
        messages: list[dict | MessageLike],
        system_msgs: list[dict | MessageLike] | None = None,
        stream: bool = True,
        temperature: float | None = None,
        **kwargs: Any,
    ) -> tuple[str, dict[str, list[float]]]:
        formatted = self._format_request_messages(messages, system_msgs)
        return await self._stream_request_vllm_logits(formatted, temperature, stream)

    @retry(wait=wait_random_exponential(min=1, max=60), stop=stop_after_attempt(6))
    async def ask_embedding(self, input: str, encoding_format: str = "float") -> list:
        try:
            response = await self.client.embeddings.create(
                input=input,
                model=self.model,
                encoding_format=encoding_format,
            )
            return response.data[0].embedding
        except OpenAIError as error:
            if isinstance(error, AuthenticationError):
                logger.error("Authentication failed. Check API key.")
            elif isinstance(error, RateLimitError):
                logger.error("Rate limit exceeded. Consider increasing retry attempts.")
            elif isinstance(error, APIError):
                logger.error("API error: %s", error)
            raise


class ProviderTransportMixin:
    async def _stream_request(
        self,
        messages: list[dict[str, Any]],
        stream: bool,
        temperature: float | None,
        handle: StreamHandle | None = None,
        timeout: float | None = None,
    ) -> str:
        return await stream_request(
            self, messages, stream, temperature, handle=handle, timeout=timeout
        )

    async def _stream_request_logits(
        self,
        messages: list[dict[str, Any]],
        temperature: float | None,
        stream: bool = False,
        handle: StreamHandle | None = None,
    ) -> Any:
        return await logprob_request(self, messages, temperature, stream, handle=handle, vllm=False)

    async def _stream_request_vllm_logits(
        self,
        messages: list[dict[str, Any]],
        temperature: float | None = 0,
        stream: bool = False,
        handle: StreamHandle | None = None,
    ) -> Any:
        return await logprob_request(self, messages, temperature, stream, handle=handle, vllm=True)
