from __future__ import annotations

import email.utils
import hashlib
import logging
import re
import time
from typing import Any


class KeyPool:
    """Round-robin endpoint selector with monotonic cooldowns."""

    def __init__(
        self,
        endpoints: list[tuple[str, str]],
        *,
        logger: Any | None = None,
    ) -> None:
        if not endpoints:
            raise ValueError("KeyPool requires at least one endpoint")
        self._endpoints = list(endpoints)
        self._size = len(self._endpoints)
        self._index = 0
        self._cooldowns: dict[int, float] = {}
        self._logger = logger or logging.getLogger("inquirycraft")

    @property
    def size(self) -> int:
        return self._size

    def is_available(self, idx: int) -> bool:
        return time.monotonic() >= self._cooldowns.get(idx, 0)

    def pick(
        self,
        *,
        exclude: set[int] | None = None,
        include: set[int] | None = None,
    ) -> tuple[int, str, str]:
        exclude = exclude or set()
        candidates = set(range(self._size)) if include is None else set(include)
        candidates.difference_update(exclude)
        if not candidates:
            raise RuntimeError("KeyPool: all slots excluded")
        now = time.monotonic()
        for _ in range(self._size):
            idx = self._index % self._size
            self._index += 1
            if idx not in candidates:
                continue
            if now >= self._cooldowns.get(idx, 0):
                return idx, self._endpoints[idx][0], self._endpoints[idx][1]
        idx = min(candidates, key=lambda item: self._cooldowns.get(item, 0))
        return idx, self._endpoints[idx][0], self._endpoints[idx][1]

    def cooldown(self, idx: int, seconds: float) -> None:
        self._cooldowns[idx] = time.monotonic() + seconds
        url_preview = self._endpoints[idx][0][:50]
        self._logger.warning(
            "[KeyPool] Slot #%d (%s) cooled down for %.0fs",
            idx,
            url_preview,
            seconds,
        )

    def reset_cooldown(self, idx: int) -> None:
        self._cooldowns.pop(idx, None)

    def seconds_until_earliest_unlock(self, *, include: set[int] | None = None) -> float:
        cooldowns = self._cooldowns
        if include is not None:
            cooldowns = {idx: value for idx, value in cooldowns.items() if idx in include}
        if not cooldowns:
            return 0.0
        now = time.monotonic()
        return max(0.0, min(cooldowns.values()) - now)


def stable_endpoint_index(seed: str, size: int) -> int:
    if size <= 0 or not seed:
        return 0
    digest = hashlib.sha256(seed.encode("utf-8", errors="ignore")).hexdigest()
    return int(digest[:16], 16) % size


def retry_after_seconds(exc: BaseException, default: float) -> float:
    """Return Retry-After seconds when present; otherwise ``default``."""

    response = getattr(exc, "response", None)
    headers = getattr(response, "headers", None) if response is not None else None
    if headers is None:
        headers = getattr(exc, "headers", None)
    value = None
    if headers is not None:
        try:
            value = headers.get("retry-after") or headers.get("Retry-After")
        except AttributeError:
            value = None
    if value is None:
        return default
    raw = str(value).strip()
    if not raw:
        return default
    try:
        return max(0.0, float(raw))
    except ValueError:
        try:
            parsed = email.utils.parsedate_to_datetime(raw)
            return max(0.0, parsed.timestamp() - time.time())
        except (TypeError, ValueError, OverflowError):
            return default


def parse_key_env(
    api_keys_csv: str | None = None,
    base_urls_csv: str | None = None,
    fallback_key: str = "",
    fallback_url: str = "",
) -> list[tuple[str, str]]:
    """Parse key/url lists, broadcasting one URL across multiple keys."""

    def split(value: str) -> list[str]:
        return [item.strip() for item in re.split(r"[,\s]+", value.strip()) if item.strip()]

    keys = split(api_keys_csv) if api_keys_csv else ([fallback_key] if fallback_key else [])
    urls = split(base_urls_csv) if base_urls_csv else ([fallback_url] if fallback_url else [])
    if not keys:
        raise ValueError("No API keys provided")
    if not urls:
        urls = [""] * len(keys)
    elif len(urls) == 1 and len(keys) > 1:
        urls = urls * len(keys)
    elif len(urls) != len(keys):
        raise ValueError(
            f"Mismatch: {len(keys)} API keys but {len(urls)} base URLs. "
            "Provide 1 URL (broadcast) or the same count as keys."
        )
    return list(zip(urls, keys))
