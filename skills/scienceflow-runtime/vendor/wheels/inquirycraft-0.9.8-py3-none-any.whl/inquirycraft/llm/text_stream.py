"""Plain text completion transport for :class:`OnlineLLM`."""

from __future__ import annotations

import logging
import time
from typing import Any

from .errors import validate_final_response
from .online_support import cached_input_tokens, save_nonstream_stats, usage_value
from .stream_decode import decoded_chunks
from .stream_types import CallStats, StreamHandle
from .tool_args import chunked_put
from .utils import get_text_from_content

logger = logging.getLogger(__name__)


def _request_kwargs(
    llm: Any,
    messages: list[dict[str, Any]],
    stream: bool,
    temperature: float | None,
    timeout: float | None,
) -> dict[str, Any]:
    kwargs: dict[str, Any] = {
        "model": llm.model,
        "messages": messages,
        "max_tokens": llm.max_tokens,
        "temperature": temperature or llm.temperature,
        "stream": stream and llm.stream,
    }
    llm._add_explicit_top_p(kwargs)
    llm._add_explicit_request_seed(kwargs)
    if llm.frequency_penalty is not None:
        kwargs["frequency_penalty"] = float(llm.frequency_penalty)
    if llm.reasoning_effort and "gemini" in (llm.model or "").lower():
        kwargs["reasoning_effort"] = llm.reasoning_effort
    if stream and llm.stream:
        kwargs["stream_options"] = {"include_usage": True}
    if timeout is not None:
        kwargs["timeout"] = float(timeout)
    return kwargs


def _delta_text(delta: Any, reasoning: bool) -> tuple[str, bool]:
    text = ""
    reasoning_content = getattr(delta, "reasoning_content", None)
    content = getattr(delta, "content", None)
    if reasoning_content:
        prefix = "<think>" if not reasoning else ""
        text = prefix + reasoning_content
        reasoning = True
    if content:
        prefix = "</think>" if reasoning else ""
        text += prefix + content
        reasoning = False
    return text, reasoning


def _estimate_inputs(llm: Any, messages: list[dict[str, Any]]) -> int:
    total = 0
    for message in messages:
        count = llm.estimate_tokens(get_text_from_content(message.get("content") or ""))
        total += count
        llm.token_tracker(count, 0)
    return total


async def _close_response(response: Any) -> None:
    if hasattr(response, "close"):
        try:
            await response.close()
        except Exception:
            pass


async def _consume_text_stream(
    llm: Any,
    response: Any,
    messages: list[dict[str, Any]],
    handle: StreamHandle,
    started: float,
) -> str:
    parts: list[str] = []
    first_at: float | None = None
    last_at = started
    chunk_count = 0
    output_tokens = 0
    input_tokens = _estimate_inputs(llm, messages)
    finish_reason = "unknown"
    api_usage = None
    reasoning = False
    answer_parts: list[str] = []
    reasoning_parts: list[str] = []
    try:
        async for chunk in decoded_chunks(response):
            if handle.interrupted:
                logger.info("Generation interrupted via StreamHandle")
                break
            if getattr(chunk, "usage", None):
                api_usage = chunk.usage
            if not chunk.choices:
                continue
            choice = chunk.choices[0]
            finish_reason = getattr(choice, "finish_reason", None) or finish_reason
            answer_parts.append(getattr(choice.delta, "content", None) or "")
            reasoning_parts.append(getattr(choice.delta, "reasoning_content", None) or "")
            text, reasoning = _delta_text(choice.delta, reasoning)
            if text:
                now = time.time()
                first_at = first_at or now
                last_at = now
                chunk_count += 1
            parts.append(text)
            count = llm.estimate_tokens(text)
            output_tokens += count
            llm.token_tracker(0, count)
            await chunked_put(handle, text)
    finally:
        await _close_response(response)
        handle.finish()
    result = "".join(parts)
    input_tokens = usage_value(api_usage, "prompt_tokens", input_tokens)
    output_tokens = usage_value(api_usage, "completion_tokens", output_tokens)
    llm._save_call_stats(
        CallStats(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            ttft=(first_at - started) if first_at else 0.0,
            tpot=(last_at - first_at) / (chunk_count - 1) * 1000
            if first_at is not None and chunk_count > 1
            else 0.0,
            finish_reason=finish_reason,
            input_cached_tokens=cached_input_tokens(api_usage),
        )
    )
    validate_final_response(
        content="".join(answer_parts),
        reasoning="".join(reasoning_parts),
        finish_reason=finish_reason,
        interrupted=handle.interrupted,
        empty_message="Empty response from streaming LLM",
    )
    return result


async def stream_request(
    llm: Any,
    messages: list[dict[str, Any]],
    stream: bool,
    temperature: float | None,
    handle: StreamHandle | None = None,
    timeout: float | None = None,
) -> str:
    active_handle = handle or StreamHandle()
    llm._save_call_stats(CallStats())
    started = time.time()
    kwargs = _request_kwargs(llm, messages, stream, temperature, timeout)
    response = await llm.client.chat.completions.create(**kwargs)
    if not (llm.stream and stream):
        save_nonstream_stats(llm, response, time.time() - started)
        if not response.choices or not response.choices[0].message:
            raise ValueError("Empty or invalid response from LLM")
        choice = response.choices[0]
        validate_final_response(
            content=choice.message.content,
            reasoning=getattr(choice.message, "reasoning_content", None),
            finish_reason=choice.finish_reason,
            empty_message="Empty or invalid response from LLM",
        )
        return choice.message.content
    return await _consume_text_stream(llm, response, messages, active_handle, started)
