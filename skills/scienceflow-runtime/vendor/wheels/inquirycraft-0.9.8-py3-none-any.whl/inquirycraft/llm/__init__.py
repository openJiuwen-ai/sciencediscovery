from .errors import (
    IncompleteStreamError,
    TruncatedResponseError,
    UnusableResponseError,
    is_missing_reasoning_replay_error,
)
from .model_registry import (
    ModelEndpoint,
    ModelPricing,
    ModelRegistry,
    RegisteredModel,
    ResolvedModelEndpoints,
    default_model_registry_path,
    write_model_registry_template,
)
from .models import (
    REASONING_REPLAY_PLACEHOLDER,
    CompletionRequest,
    CompletionResult,
    ReasoningReplayPolicy,
    StreamChunk,
    Usage,
    normalize_reasoning_replay,
    project_reasoning_messages,
)
from .pool import KeyPool, parse_key_env, retry_after_seconds, stable_endpoint_index
from .protocol import LLMClient
from .retry import SameRoundRetryPolicy, is_retryable_empty_tool_stream_error
from .stream_types import GuardStreamChunk, StreamHandle

__all__ = [
    "IncompleteStreamError",
    "CompletionRequest",
    "CompletionResult",
    "TruncatedResponseError",
    "UnusableResponseError",
    "LLMClient",
    "LLMFactoryConfig",
    "KeyPool",
    "PooledLLM",
    "OnlineLLM",
    "ModelEndpoint",
    "ModelPricing",
    "ModelRegistry",
    "RegisteredModel",
    "ResolvedModelEndpoints",
    "SameRoundRetryPolicy",
    "GuardStreamChunk",
    "StreamHandle",
    "build_llm",
    "StreamChunk",
    "Usage",
    "ReasoningReplayPolicy",
    "REASONING_REPLAY_PLACEHOLDER",
    "normalize_reasoning_replay",
    "project_reasoning_messages",
    "is_retryable_empty_tool_stream_error",
    "is_missing_reasoning_replay_error",
    "parse_key_env",
    "retry_after_seconds",
    "stable_endpoint_index",
    "default_model_registry_path",
    "write_model_registry_template",
]


def __getattr__(name: str):
    if name in {"LLMFactoryConfig", "build_llm"}:
        from .factory import LLMFactoryConfig, build_llm

        return {
            "LLMFactoryConfig": LLMFactoryConfig,
            "build_llm": build_llm,
        }[name]
    if name == "PooledLLM":
        from .pooled import PooledLLM

        return PooledLLM
    if name in {"OnlineLLM", "OpenAICompatibleClient"}:
        from .online import OnlineLLM
        from .openai_adapter import OpenAICompatibleClient

        return {"OnlineLLM": OnlineLLM, "OpenAICompatibleClient": OpenAICompatibleClient}[name]
    raise AttributeError(name)
