"""Accounting and result construction for streamed tool completions."""

from __future__ import annotations

import time
from types import SimpleNamespace
from typing import Any

from .errors import (
    IncompleteStreamError,
    TruncatedResponseError,
    UnusableResponseError,
    validate_final_response,
)
from .online_support import cached_input_tokens, usage_value
from .stream_decode import annotate_stream_error
from .stream_types import CallStats
from .tool_stream_state import ToolStreamState, tool_slot_ready


def save_tool_stream_stats(llm: Any, state: ToolStreamState, started: float) -> None:
    elapsed = time.time() - started
    input_tokens = usage_value(state.usage, "prompt_tokens", state.input_tokens)
    output_tokens = usage_value(state.usage, "completion_tokens", state.output_tokens)
    llm._save_call_stats(
        CallStats(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            ttft=elapsed,
            tpot=elapsed / output_tokens * 1000 if llm.tracker and output_tokens > 1 else 0.0,
            finish_reason=state.finish_reason,
            input_cached_tokens=cached_input_tokens(state.usage),
        )
    )


def _tool_call(llm: Any, messages: list[Any], index: int, slot: dict[str, Any]) -> Any:
    arguments = (slot.get("arguments") or "").strip()
    name = slot["name"]
    stable_id = llm._stable_tool_call_id(messages, index, str(name or ""), arguments)
    return SimpleNamespace(
        id=stable_id or slot["id"],
        function=SimpleNamespace(name=name, arguments=arguments),
    )


def validate_tool_stream_state(state, collect_all=True, interrupted=False):
    slots = {i: slot for i, slot in state.slots.items() if collect_all or i == 0}
    ready = {i: slot for i, slot in slots.items() if tool_slot_ready(slot)}
    if not interrupted:
        if state.finish_reason == "content_filter":
            raise UnusableResponseError("LLM output was filtered", finish_reason="content_filter")
        if len(ready) != len(slots):
            if state.finish_reason == "length":
                raise TruncatedResponseError(
                    "Incomplete tool call(s); increase max_tokens", finish_reason="length"
                )
            error = IncompleteStreamError(
                "Incomplete streaming tool call(s)", phase="tool_arguments"
            )
            annotate_stream_error(error, state.usage, state.finish_reason)
            raise error
    content, reasoning = "".join(state.content), "".join(state.reasoning)
    validate_final_response(
        content=content,
        reasoning=reasoning,
        has_tool_calls=bool(ready),
        finish_reason=state.finish_reason,
        interrupted=interrupted,
        empty_message="Empty response from streaming tool LLM",
    )
    return content, reasoning if reasoning.strip() else None, ready


def build_tool_stream_result(
    llm: Any,
    state: ToolStreamState,
    messages: list[Any],
    collect_all: bool,
    interrupted: bool,
) -> Any:
    content, reasoning, ready = validate_tool_stream_state(state, collect_all, interrupted)
    tool_calls = [_tool_call(llm, messages, index, ready[index]) for index in sorted(ready)]
    return SimpleNamespace(
        content=content,
        reasoning_content=reasoning,
        tool_calls=tool_calls or None,
    )
