"""Non-streaming and streaming tool-call requests for online providers."""

from __future__ import annotations

import logging
import time
from typing import Any

from openai import APIError, AuthenticationError, OpenAIError, RateLimitError
from tenacity import (
    retry,
    retry_if_exception_type,
    retry_if_not_exception_type,
    stop_after_attempt,
    wait_random_exponential,
)

from .errors import TruncatedResponseError, UnusableResponseError, validate_final_response
from .message_format import MessageLike
from .online_support import save_nonstream_stats
from .stream_types import CallStats, StreamHandle
from .tool_stream_result import build_tool_stream_result, save_tool_stream_stats
from .tool_stream_state import (
    consume_tool_stream,
    tool_preview_cap,
    tool_progress_chunks,
    tool_slot_ready,
)

logger = logging.getLogger(__name__)


def _validate_tools(tools: list[dict[str, Any]] | None) -> None:
    for tool in tools or []:
        if not isinstance(tool, dict) or "type" not in tool:
            raise ValueError("Each tool must be a dict with 'type' field")


def _tool_kwargs(
    llm: Any,
    messages: list[dict[str, Any]],
    timeout: int,
    tools: list[dict[str, Any]] | None,
    tool_choice: Any,
    temperature: float | None,
    parallel_tool_calls: bool | None,
    extra: dict[str, Any],
    *,
    stream: bool,
) -> dict[str, Any]:
    kwargs: dict[str, Any] = {
        "model": llm.model,
        "messages": messages,
        "temperature": temperature or llm.temperature,
        "max_tokens": llm.max_tokens,
        "timeout": timeout,
    }
    if tools:
        kwargs["tools"] = tools
        if tool_choice is not None:
            kwargs["tool_choice"] = tool_choice
        if parallel_tool_calls is not None:
            kwargs["parallel_tool_calls"] = parallel_tool_calls
    if stream:
        kwargs.update(stream=True, stream_options={"include_usage": True})
    if llm.frequency_penalty is not None:
        kwargs["frequency_penalty"] = float(llm.frequency_penalty)
    kwargs.update(extra)
    llm._add_explicit_request_seed(kwargs)
    return kwargs


def _log_openai_error(error: OpenAIError) -> None:
    if isinstance(error, AuthenticationError):
        logger.error("Authentication failed. Check API key.")
    elif isinstance(error, RateLimitError):
        logger.error("Rate limit exceeded. Consider increasing retry attempts.")
    elif isinstance(error, APIError):
        logger.error("API error: %s", error)


class ToolRequestMixin:
    @staticmethod
    def _tool_call_slot_ready(slot: dict[str, Any]) -> bool:
        return tool_slot_ready(slot)

    @staticmethod
    def _tool_arg_stream_preview_cap(slot: dict[str, Any]) -> int:
        return tool_preview_cap(slot)

    @staticmethod
    def _tool_arg_stream_progress_chunks(
        slot: dict[str, Any], cap: int, total_len: int, step: int = 6144
    ) -> list[str]:
        return tool_progress_chunks(slot, cap, total_len, step)

    @retry(
        wait=wait_random_exponential(min=1, max=60),
        stop=stop_after_attempt(6),
        retry=retry_if_exception_type() & retry_if_not_exception_type(UnusableResponseError),
    )
    async def ask_tool(
        self,
        messages: list[dict | MessageLike],
        system_msgs: list[dict | MessageLike] | None = None,
        timeout: int = 60,
        tools: list[dict] | None = None,
        tool_choice: Any = "auto",
        temperature: float | None = None,
        parallel_tool_calls: bool | None = None,
        **kwargs: Any,
    ) -> Any:
        try:
            self._save_call_stats(CallStats())
            formatted = self._format_request_messages(messages, system_msgs)
            _validate_tools(tools)
            started = time.time()
            request = _tool_kwargs(
                self,
                formatted,
                timeout,
                tools,
                tool_choice,
                temperature,
                parallel_tool_calls,
                kwargs,
                stream=False,
            )
            response = await self.client.chat.completions.create(**request)
            save_nonstream_stats(self, response, time.time() - started)
            if not response.choices or not response.choices[0].message:
                raise ValueError("Invalid or empty response from LLM")
            message = response.choices[0].message
            tool_calls = getattr(message, "tool_calls", None) or []
            if response.choices[0].finish_reason == "length" and any(
                not tool_slot_ready(
                    {
                        "id": call.id,
                        "name": call.function.name,
                        "arguments": call.function.arguments,
                    }
                )
                for call in tool_calls
            ):
                raise TruncatedResponseError(
                    "Incomplete tool call(s) from LLM; increase max_tokens",
                    finish_reason="length",
                )
            validate_final_response(
                content=message.content,
                reasoning=getattr(message, "reasoning_content", None),
                has_tool_calls=bool(tool_calls),
                finish_reason=response.choices[0].finish_reason,
                empty_message="Invalid or empty response from LLM",
            )
            for index, tool_call in enumerate(tool_calls):
                function = getattr(tool_call, "function", None)
                stable_id = self._stable_tool_call_id(
                    formatted,
                    index,
                    str(getattr(function, "name", "") or ""),
                    str(getattr(function, "arguments", "") or ""),
                )
                if stable_id is not None:
                    tool_call.id = stable_id
            return message
        except OpenAIError as error:
            _log_openai_error(error)
            raise
        except Exception as error:
            logger.error("Unexpected error in ask_tool: %s", error)
            raise

    async def ask_tool_stream(
        self,
        messages: list[dict | MessageLike],
        system_msgs: list[dict | MessageLike] | None = None,
        timeout: int = 300,
        tools: list[dict] | None = None,
        tool_choice: Any = "auto",
        temperature: float | None = None,
        parallel_tool_calls: bool | None = None,
        *,
        handle: StreamHandle,
        collect_all_tool_calls: bool = False,
        **kwargs: Any,
    ) -> Any:
        extra = dict(kwargs)
        extra.pop("stream", None)
        extra.pop("stream_handle", None)
        try:
            self._save_call_stats(CallStats())
            formatted = self._format_request_messages(messages, system_msgs)
            _validate_tools(tools)
            request = _tool_kwargs(
                self,
                formatted,
                timeout,
                tools,
                tool_choice,
                temperature,
                parallel_tool_calls,
                extra,
                stream=True,
            )
            started = time.time()
            response = await self.client.chat.completions.create(**request)
            state = await consume_tool_stream(
                self, response, formatted, handle, collect_all_tool_calls
            )
            save_tool_stream_stats(self, state, started)
            return build_tool_stream_result(
                self, state, formatted, collect_all_tool_calls, handle.interrupted
            )
        except OpenAIError as error:
            _log_openai_error(error)
            raise
        except Exception as error:
            logger.error("Unexpected error in ask_tool_stream: %s: %r", type(error).__name__, error)
            raise
        finally:
            handle.finish()
