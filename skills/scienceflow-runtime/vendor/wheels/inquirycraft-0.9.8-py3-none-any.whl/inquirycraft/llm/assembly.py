"""Provider-neutral stream assembly shared by transports and the runtime."""

from typing import Any, Mapping

from .models import CompletionResult, Usage


class StreamAssembler:
    """Assemble provider-neutral chunks into one canonical completion result."""

    def __init__(self) -> None:
        self.content: list[str] = []
        self.reasoning: list[str] = []
        self.calls: dict[int, dict[str, Any]] = {}
        self.finish_reason = "unknown"
        self.usage = Usage()
        self.pool_index: int | None = None

    def add(self, chunk: Any) -> None:
        self.content.append(str(chunk.content or ""))
        self.reasoning.append(str(chunk.reasoning_content or ""))
        if chunk.tool_call_delta:
            self._add_tool_call(chunk.tool_call_delta)
        if chunk.finish_reason:
            self.finish_reason = str(chunk.finish_reason)
        if chunk.usage is not None:
            self.usage = chunk.usage
        if getattr(chunk, "pool_index", None) is not None:
            self.pool_index = chunk.pool_index

    def _add_tool_call(self, delta: Mapping[str, Any]) -> None:
        index = int(delta.get("index", 0) or 0)
        state = self.calls.setdefault(
            index,
            {"id": "", "type": "function", "function": {"name": "", "arguments": ""}},
        )
        if delta.get("id"):
            state["id"] += str(delta["id"])
        if delta.get("type"):
            state["type"] = str(delta["type"])
        function = delta.get("function") or {}
        if isinstance(function, Mapping):
            if function.get("name"):
                state["function"]["name"] += str(function["name"])
            if function.get("arguments") is not None:
                state["function"]["arguments"] += str(function["arguments"])

    def result(self) -> CompletionResult:
        return CompletionResult(
            content="".join(self.content),
            reasoning_content="".join(self.reasoning),
            tool_calls=tuple(self.calls[index] for index in sorted(self.calls)),
            finish_reason=self.finish_reason,
            usage=self.usage,
            pool_index=self.pool_index,
        )
