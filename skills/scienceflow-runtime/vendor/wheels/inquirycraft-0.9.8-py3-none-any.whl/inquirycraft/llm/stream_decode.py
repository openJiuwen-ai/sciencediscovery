"""Classify decoding failures only while reading provider stream chunks."""

from __future__ import annotations

import json

from .errors import IncompleteStreamError
from .online_support import provider_usage


def annotate_stream_error(error, usage, finish_reason):
    error.finish_reason = finish_reason
    error.usage_known = usage is not None
    if usage is not None:
        error.usage = provider_usage(usage)


async def decoded_chunks(response):
    iterator = response.__aiter__()
    usage, finish = None, "unknown"
    try:
        while True:
            try:
                chunk = await anext(iterator)
            except StopAsyncIteration:
                if finish == "unknown":
                    raise IncompleteStreamError(
                        "Provider stream ended without a finish reason", phase="stream_end",
                    ) from None
                return
            except json.JSONDecodeError as exc:
                raise IncompleteStreamError("Provider stream contained invalid JSON") from exc
            usage = getattr(chunk, "usage", None) or usage
            choices = getattr(chunk, "choices", None)
            if choices:
                finish = getattr(choices[0], "finish_reason", None) or finish
            yield chunk
    except IncompleteStreamError as error:
        annotate_stream_error(error, usage, finish)
        raise
