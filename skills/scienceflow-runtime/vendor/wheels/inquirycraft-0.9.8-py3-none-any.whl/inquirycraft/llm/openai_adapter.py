from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any

from .assembly import StreamAssembler
from .errors import IncompleteStreamError, UnusableResponseError
from .models import CompletionRequest, CompletionResult, StreamChunk
from .online_support import provider_usage as _usage
from .stream_decode import annotate_stream_error, decoded_chunks
from .tool_stream_result import validate_tool_stream_state
from .tool_stream_state import ToolStreamState


class OpenAICompatibleClient:
    """Optional OpenAI-compatible adapter; importing InquiryCraft does not import OpenAI."""

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str | None = None,
        default_headers: dict[str, str] | None = None,
    ) -> None:
        try:
            from openai import AsyncOpenAI
        except ImportError as exc:  # pragma: no cover - depends on minimal install
            raise RuntimeError(
                "Install inquirycraft[openai] to use OpenAICompatibleClient"
            ) from exc
        self._client = AsyncOpenAI(
            api_key=api_key,
            base_url=base_url,
            default_headers=default_headers,
        )

    @staticmethod
    def _kwargs(request: CompletionRequest) -> dict[str, Any]:
        kwargs: dict[str, Any] = {
            "model": request.model,
            "messages": [dict(message) for message in request.messages],
        }
        if request.tools:
            kwargs["tools"] = [dict(tool) for tool in request.tools]
            if request.tool_choice is not None:
                kwargs["tool_choice"] = request.tool_choice
        for name in ("temperature", "max_tokens", "timeout"):
            if (value := getattr(request, name)) is not None:
                kwargs[name] = value
        return kwargs

    async def complete(self, request: CompletionRequest) -> CompletionResult:
        response = await self._client.chat.completions.create(**self._kwargs(request))
        if not response.choices:
            raise ValueError("LLM returned no choices")
        choice = response.choices[0]
        message = choice.message
        result = CompletionResult(
            content=str(message.content or ""),
            reasoning_content=str(getattr(message, "reasoning_content", "") or ""),
            tool_calls=tuple(call.model_dump() for call in (message.tool_calls or ())),
            finish_reason=str(choice.finish_reason or "unknown"),
            usage=_usage(getattr(response, "usage", None)),
            raw=response,
        )
        self._validate(result, getattr(response, "usage", None))
        return result

    async def stream(self, request: CompletionRequest) -> AsyncIterator[StreamChunk]:
        kwargs = self._kwargs(request)
        kwargs.update(stream=True, stream_options={"include_usage": True})
        response = await self._client.chat.completions.create(**kwargs)
        assembler, usage = StreamAssembler(), None
        try:
            async for chunk in decoded_chunks(response):
                usage = getattr(chunk, "usage", None) or usage
                choice = chunk.choices[0] if chunk.choices else None
                delta = choice.delta if choice is not None else None
                calls = getattr(delta, "tool_calls", None) or [None]
                for index, call in enumerate(calls):
                    terminal = index == len(calls) - 1
                    text = {
                        name: str(getattr(delta, name, "") or "") if index == 0 else ""
                        for name in ("content", "reasoning_content")
                    }
                    item = StreamChunk(
                        **text,
                        tool_call_delta=call.model_dump() if call else None,
                        finish_reason=choice.finish_reason if terminal and choice else None,
                        usage=_usage(chunk.usage) if terminal and chunk.usage else None,
                    )
                    assembler.add(item)
                    yield item
            self._validate(assembler.result(), usage)
        finally:
            await response.close()

    @staticmethod
    def _validate(result, usage):
        state = ToolStreamState(
            content=[result.content],
            reasoning=[result.reasoning_content],
            finish_reason=result.finish_reason,
            usage=usage,
            slots={
                i: {"id": call.get("id"), **call.get("function", {})}
                for i, call in enumerate(result.tool_calls)
            },
        )
        try:
            validate_tool_stream_state(state)
        except (IncompleteStreamError, UnusableResponseError) as error:
            annotate_stream_error(error, usage, result.finish_reason)
            raise

    async def aclose(self) -> None:
        await self._client.close()
