from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

from inquirycraft.llm import parse_key_env
from inquirycraft.llm.model_registry import ModelRegistry
from inquirycraft.llm.online import OnlineLLM

from .pooled import PooledLLM


@dataclass(frozen=True, slots=True)
class LLMFactoryConfig:
    # Scalar fields are compatibility inputs; new callers use endpoint lists.
    model: str = ""
    max_tokens: int = 32768
    frequency_penalty: float | None = None
    coalesce_system_messages: bool = False
    base_url: str = ""
    api_key: str = ""
    api_keys: Sequence[str] = ()
    base_urls: Sequence[str] = ()
    models: Sequence[str] = ()
    model_registry: ModelRegistry | None = None
    model_aliases: Sequence[str] = ()
    model_role: str = ""
    routing_mode: str = "round_robin"
    sticky_id: str = ""
    sticky_primary_index: int | None = None
    rate_limit_cooldown_sec: float = 60.0
    connection_cooldown_sec: float = 15.0
    request_seed: int | None = None
    extra_client_kwargs: Mapping[str, Any] = field(default_factory=dict)
    endpoint_client_kwargs: Sequence[Mapping[str, Any]] = ()


def build_llm(
    config: LLMFactoryConfig,
    *,
    online_llm_factory: Callable[..., Any] = OnlineLLM,
    pooled_llm_type: type[PooledLLM] = PooledLLM,
    logger: Any | None = None,
) -> Any:
    """Build one client or a failover pool from domain-neutral options."""

    api_keys = tuple(config.api_keys)
    base_urls = tuple(config.base_urls)
    models = [str(item).strip() for item in config.models if str(item).strip()]
    endpoint_client_kwargs = tuple(config.endpoint_client_kwargs)
    if config.model_registry is not None:
        resolved = config.model_registry.resolve(
            config.model_aliases,
            role=config.model_role or None,
        )
        models = list(resolved.models)
        api_keys = resolved.api_keys
        base_urls = resolved.base_urls
        endpoint_client_kwargs = tuple(
            {"use_proxy": flag} if flag is not None else {} for flag in resolved.use_proxies
        )
    model = config.model or (models[0] if models else "")
    if not model:
        raise ValueError("models must contain at least one model")
    shared: dict[str, Any] = {
        "model": model,
        "max_tokens": config.max_tokens,
        "frequency_penalty": config.frequency_penalty,
        "coalesce_system_messages": config.coalesce_system_messages,
        "stream": True,
        "tracker": True,
        **dict(config.extra_client_kwargs),
    }
    if config.request_seed is not None:
        shared["request_seed"] = int(config.request_seed)

    if api_keys or base_urls or models:
        endpoints = parse_key_env(
            api_keys_csv=",".join(api_keys) or config.api_key,
            base_urls_csv=",".join(base_urls) if base_urls else None,
            fallback_url=config.base_url,
        )
        endpoint_models = models or [model]
        if len(endpoint_models) == 1:
            endpoint_models = endpoint_models * len(endpoints)
        elif len(endpoint_models) != len(endpoints):
            if not config.model:
                raise ValueError("models must contain one value or one per api_keys entry")
            # Preserve legacy host contracts that supply an explicit scalar fallback.
            endpoint_models = (endpoint_models * len(endpoints))[: len(endpoints)]
        if logger is not None:
            logger.info(
                f"[LLM] {model}: PooledLLM with {len(endpoints)} keys"
                + (f", {len(set(endpoint_models))} model(s)" if endpoint_models else "")
            )
        if endpoint_client_kwargs and len(endpoint_client_kwargs) != len(endpoints):
            raise ValueError("endpoint_client_kwargs must match the endpoint count")
        pool_kwargs = (
            {"endpoint_client_kwargs": endpoint_client_kwargs} if endpoint_client_kwargs else {}
        )
        return pooled_llm_type.from_endpoints(
            endpoints=endpoints,
            endpoint_models=endpoint_models or None,
            routing_mode=config.routing_mode,
            sticky_id=config.sticky_id,
            sticky_primary_index=config.sticky_primary_index,
            rate_limit_cooldown_sec=config.rate_limit_cooldown_sec,
            connection_cooldown_sec=config.connection_cooldown_sec,
            **pool_kwargs,
            **shared,
        )

    return online_llm_factory(base_url=config.base_url, api_key=config.api_key, **shared)
