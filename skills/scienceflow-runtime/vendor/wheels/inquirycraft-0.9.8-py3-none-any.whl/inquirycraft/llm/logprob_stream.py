"""Log-probability completion transport for online providers and vLLM."""

from __future__ import annotations

import logging
import time
from typing import Any

from .online_support import save_nonstream_stats
from .stream_types import CallStats, StreamHandle
from .text_stream import _close_response, _delta_text
from .tool_args import chunked_put

logger = logging.getLogger(__name__)


def _request_kwargs(
    llm: Any,
    messages: list[dict[str, Any]],
    temperature: float | None,
    stream: bool,
    *,
    vllm: bool,
) -> dict[str, Any]:
    kwargs: dict[str, Any] = {
        "model": llm.model,
        "messages": messages,
        "max_tokens": llm.max_tokens,
        "stream": stream and llm.stream,
        "temperature": 0 if vllm else (temperature or llm.temperature),
        "logprobs": True,
        "top_logprobs": 5,
    }
    if not vllm:
        llm._add_explicit_top_p(kwargs)
    llm._add_explicit_request_seed(kwargs)
    if llm.frequency_penalty is not None:
        kwargs["frequency_penalty"] = float(llm.frequency_penalty)
    return kwargs


def _value(item: Any, name: str, default: Any = None) -> Any:
    if isinstance(item, dict):
        return item.get(name, default)
    return getattr(item, name, default)


def _token_probabilities(items: Any, *, after_fence: bool) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    started = not after_fence
    for item in items or []:
        token = _value(item, "token", "")
        if token == "```":
            started = True
        if not started:
            continue
        top = _value(item, "top_logprobs", []) or []
        output.append(
            {
                "token": token,
                "top_logprobs": [float(_value(candidate, "logprob", 0.0)) for candidate in top],
            }
        )
    return output


def _choice_logprobs(choice: Any, *, vllm: bool) -> Any:
    if vllm:
        container = getattr(choice, "logprobs", None)
    else:
        container = getattr(getattr(choice, "delta", None), "logprobs", None)
    return _value(container, "content", []) if container else []


async def _consume_logprob_stream(
    llm: Any,
    response: Any,
    handle: StreamHandle,
    started: float,
    message_count: int,
    *,
    vllm: bool,
) -> tuple[str, list[dict[str, Any]]]:
    parts: list[str] = []
    probabilities: list[dict[str, Any]] = []
    first_at: float | None = None
    last_at = started
    chunks = 0
    output_tokens = 0
    reasoning = False
    fence_started = False
    llm.token_tracker(message_count, 0)
    try:
        async for chunk in response:
            if handle.interrupted:
                logger.info("Generation interrupted via StreamHandle (logits)")
                break
            if not chunk.choices:
                continue
            choice = chunk.choices[0]
            text, reasoning = _delta_text(choice.delta, reasoning)
            token_items = _choice_logprobs(choice, vllm=vllm)
            new_probs = _token_probabilities(token_items, after_fence=not fence_started)
            if any(_value(item, "token", "") == "```" for item in token_items or []):
                fence_started = True
            if fence_started:
                probabilities.extend(new_probs)
            if text:
                now = time.time()
                first_at = first_at or now
                last_at = now
                chunks += 1
            parts.append(text)
            count = llm.estimate_tokens(text)
            output_tokens += count
            llm.token_tracker(0, count)
            await chunked_put(handle, text)
    finally:
        await _close_response(response)
        handle.finish()
    result = "".join(parts).strip()
    if not result and not handle.interrupted:
        raise ValueError("Empty response from streaming LLM")
    llm._save_call_stats(
        CallStats(
            output_tokens=output_tokens,
            ttft=(first_at - started) if first_at else 0.0,
            tpot=(last_at - first_at) / (chunks - 1) * 1000
            if first_at is not None and chunks > 1
            else 0.0,
        )
    )
    return result, probabilities


async def logprob_request(
    llm: Any,
    messages: list[dict[str, Any]],
    temperature: float | None,
    stream: bool = False,
    handle: StreamHandle | None = None,
    *,
    vllm: bool = False,
) -> tuple[str, list[dict[str, Any]]]:
    active_handle = handle or StreamHandle()
    started = time.time()
    response = await llm.client.chat.completions.create(
        **_request_kwargs(llm, messages, temperature, stream, vllm=vllm)
    )
    if llm.stream and stream:
        return await _consume_logprob_stream(
            llm, response, active_handle, started, len(messages), vllm=vllm
        )
    if not response.choices or not response.choices[0].message.content:
        raise ValueError("Empty or invalid response from LLM")
    choice = response.choices[0]
    items = _value(choice.logprobs, "content", [])
    probabilities = _token_probabilities(items, after_fence=vllm)
    save_nonstream_stats(llm, response, time.time() - started)
    return choice.message.content, probabilities
