"""Structured model and endpoint configuration.

The registry deliberately separates a model alias from its provider endpoints.
Callers choose aliases; the LLM factory receives an aligned list of concrete
model, URL and key triples.
"""

from __future__ import annotations

import json
import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .model_registry_template import default_model_registry_path, write_model_registry_template
from .models import ReasoningReplayPolicy, choose_reasoning_replay, normalize_reasoning_replay


@dataclass(frozen=True, slots=True)
class ModelEndpoint:
    url: str
    key: str


@dataclass(frozen=True, slots=True)
class ModelPricing:
    """USD rates per one million input, cached-input and output tokens."""

    input_usd_per_1m: float
    cached_input_usd_per_1m: float
    output_usd_per_1m: float

    def estimate(self, input_tokens: int, cached_tokens: int, output_tokens: int) -> float:
        cached = min(max(0, cached_tokens), max(0, input_tokens))
        uncached = max(0, input_tokens - cached)
        return (
            uncached * self.input_usd_per_1m
            + cached * self.cached_input_usd_per_1m
            + max(0, output_tokens) * self.output_usd_per_1m
        ) / 1_000_000


@dataclass(frozen=True, slots=True)
class RegisteredModel:
    alias: str
    model: str
    endpoints: tuple[ModelEndpoint, ...]
    role_endpoints: Mapping[str, tuple[ModelEndpoint, ...]]
    pricing: ModelPricing | None = None
    reasoning_replay: ReasoningReplayPolicy = "preserve"
    use_proxy: bool = False

    def endpoints_for(self, role: str | None = None) -> tuple[ModelEndpoint, ...]:
        """Return role-specific routes, falling back to shared legacy routes."""

        normalized = str(role or "").removesuffix("_models").strip().casefold()
        if normalized and normalized in self.role_endpoints:
            return self.role_endpoints[normalized]
        if "default" in self.role_endpoints:
            return self.role_endpoints["default"]
        if normalized == "chat" and "code" in self.role_endpoints:
            return self.role_endpoints["code"]
        return self.endpoints


@dataclass(frozen=True, slots=True)
class ResolvedModelEndpoints:
    aliases: tuple[str, ...]
    models: tuple[str, ...]
    base_urls: tuple[str, ...]
    api_keys: tuple[str, ...]
    pricing: tuple[ModelPricing | None, ...]
    reasoning_replay: ReasoningReplayPolicy = "preserve"
    use_proxies: tuple[bool, ...] = ()


@dataclass(frozen=True, slots=True)
class ModelRegistry:
    version: int
    models: Mapping[str, RegisteredModel]
    defaults: Mapping[str, Any]
    source: Path | None = None

    @classmethod
    def from_json(cls, path: str | Path) -> "ModelRegistry":
        source = Path(path).expanduser().resolve(strict=False)
        try:
            payload = json.loads(source.read_text(encoding="utf-8"))
        except FileNotFoundError as exc:
            raise ValueError(f"Model configuration does not exist: {source}") from exc
        except json.JSONDecodeError as exc:
            raise ValueError(
                f"Invalid model configuration JSON at {source}:{exc.lineno}:{exc.colno}"
            ) from exc
        return cls.from_mapping(payload, source=source)

    @classmethod
    def from_mapping(
        cls,
        payload: Mapping[str, Any],
        *,
        source: Path | None = None,
    ) -> "ModelRegistry":
        if not isinstance(payload, Mapping):
            raise ValueError("Model configuration must be a JSON object")
        version = payload.get("version", 1)
        if version != 1:
            raise ValueError(f"Unsupported model configuration version: {version!r}")
        raw_models = payload.get("models")
        if not isinstance(raw_models, Mapping) or not raw_models:
            raise ValueError("Model configuration must define a non-empty 'models' object")

        models: dict[str, RegisteredModel] = {}
        for raw_alias, raw_spec in raw_models.items():
            alias = str(raw_alias or "").strip()
            if not alias:
                raise ValueError("Model aliases must be non-empty strings")
            if not isinstance(raw_spec, Mapping):
                raise ValueError(f"models.{alias} must be an object")
            model = str(raw_spec.get("model") or "").strip()
            if not model:
                raise ValueError(f"models.{alias}.model must be a non-empty string")
            raw_endpoints = raw_spec.get("endpoints")
            role_endpoints: dict[str, tuple[ModelEndpoint, ...]] = {}
            if isinstance(raw_endpoints, Mapping):
                if not raw_endpoints:
                    raise ValueError(f"models.{alias}.endpoints must not be empty")
                flattened: list[ModelEndpoint] = []
                for raw_role, role_rows in raw_endpoints.items():
                    role = str(raw_role or "").strip().casefold()
                    if not role:
                        raise ValueError(f"models.{alias}.endpoints role must not be empty")
                    parsed = _parse_endpoints(role_rows, label=f"models.{alias}.endpoints.{role}")
                    role_endpoints[role] = parsed
                    flattened.extend(parsed)
                endpoints = tuple(dict.fromkeys(flattened))
            else:
                endpoints = _parse_endpoints(raw_endpoints, label=f"models.{alias}.endpoints")
            pricing = _parse_pricing(
                raw_spec.get("pricing"),
                label=f"models.{alias}.pricing",
            )
            reasoning_replay = normalize_reasoning_replay(raw_spec.get("reasoning_replay"))
            use_proxy = raw_spec.get("use_proxy", False)
            if not isinstance(use_proxy, bool):
                raise ValueError(f"models.{alias}.use_proxy must be a boolean")
            models[alias] = RegisteredModel(
                alias,
                model,
                endpoints,
                role_endpoints,
                pricing,
                reasoning_replay,
                use_proxy,
            )

        concrete_pricing: dict[str, ModelPricing] = {}
        for spec in models.values():
            if spec.pricing is None:
                continue
            previous = concrete_pricing.setdefault(spec.model, spec.pricing)
            if previous != spec.pricing:
                raise ValueError(f"Model {spec.model!r} has conflicting pricing across aliases")

        raw_defaults = payload.get("defaults", {})
        if not isinstance(raw_defaults, Mapping):
            raise ValueError("Model configuration 'defaults' must be an object")
        defaults = dict(raw_defaults)
        for name, value in defaults.items():
            if not name.endswith("_models"):
                continue
            aliases = _string_list(value, label=f"defaults.{name}")
            unknown = [alias for alias in aliases if alias not in models]
            if unknown:
                raise ValueError(
                    f"defaults.{name} references unknown model alias(es): {', '.join(unknown)}"
                )
        selection = str(defaults.get("selection") or "auto").strip().lower()
        if selection not in {"auto", "spread", "fixed"}:
            raise ValueError("defaults.selection must be one of: auto, spread, fixed")
        defaults["selection"] = selection
        return cls(version=1, models=models, defaults=defaults, source=source)

    def default_aliases(self, name: str) -> tuple[str, ...]:
        return tuple(_string_list(self.defaults.get(name, ()), label=f"defaults.{name}"))

    def resolve(
        self,
        aliases: Sequence[str],
        *,
        role: str | None = None,
        reasoning_replay: str | None = None,
    ) -> ResolvedModelEndpoints:
        selected = tuple(str(alias).strip() for alias in aliases if str(alias).strip())
        if not selected:
            raise ValueError("At least one model alias must be selected")
        if len(selected) != len(set(selected)):
            raise ValueError("Model aliases must not contain duplicates")
        unknown = [alias for alias in selected if alias not in self.models]
        if unknown:
            raise ValueError(f"Unknown model alias(es): {', '.join(unknown)}")
        replay_policy = choose_reasoning_replay(
            {alias: self.models[alias].reasoning_replay for alias in selected},
            reasoning_replay,
        )
        models: list[str] = []
        base_urls: list[str] = []
        api_keys: list[str] = []
        pricing: list[ModelPricing | None] = []
        use_proxies: list[bool] = []
        for alias in selected:
            spec = self.models[alias]
            endpoints = spec.endpoints_for(role)
            if not endpoints:
                raise ValueError(f"Model alias {alias!r} has no endpoint for role {role!r}")
            for endpoint in endpoints:
                models.append(spec.model)
                base_urls.append(endpoint.url)
                api_keys.append(endpoint.key)
                pricing.append(spec.pricing)
                use_proxies.append(spec.use_proxy)
        return ResolvedModelEndpoints(
            aliases=selected,
            models=tuple(models),
            base_urls=tuple(base_urls),
            api_keys=tuple(api_keys),
            pricing=tuple(pricing),
            reasoning_replay=replay_policy,
            use_proxies=tuple(use_proxies),
        )

    def price_table(self) -> Mapping[str, ModelPricing]:
        """Return prices keyed by concrete provider model name."""

        return {
            spec.model: spec.pricing for spec in self.models.values() if spec.pricing is not None
        }


def _string_list(value: Any, *, label: str) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        values = [item.strip() for item in value.split(",")]
    elif isinstance(value, (list, tuple)):
        values = [str(item).strip() for item in value]
    else:
        raise ValueError(f"{label} must be a string or array of strings")
    return [item for item in values if item]


def _parse_endpoints(value: Any, *, label: str) -> tuple[ModelEndpoint, ...]:
    if not isinstance(value, list) or not value:
        raise ValueError(f"{label} must be a non-empty array")
    endpoints = []
    seen = set()
    for index, raw_endpoint in enumerate(value):
        if not isinstance(raw_endpoint, Mapping):
            raise ValueError(f"{label}[{index}] must be an object")
        url = str(raw_endpoint.get("url") or "").strip().rstrip("/")
        key = str(raw_endpoint.get("key") or "").strip()
        if not key:
            raise ValueError(f"{label}[{index}].key is required")
        identity = (url, key)
        if identity in seen:
            raise ValueError(f"{label} contains a duplicate endpoint")
        seen.add(identity)
        endpoints.append(ModelEndpoint(url=url, key=key))
    return tuple(endpoints)


def _parse_pricing(value: Any, *, label: str) -> ModelPricing | None:
    if value is None:
        return None
    if not isinstance(value, Mapping):
        raise ValueError(f"{label} must be an object")
    names = (
        "input_usd_per_1m",
        "cached_input_usd_per_1m",
        "output_usd_per_1m",
    )
    raw_values = tuple(value.get(name) for name in names)
    if all(item is None for item in raw_values):
        return None
    if any(item is None for item in raw_values):
        raise ValueError(f"{label} must define {', '.join(names)}")
    if any(isinstance(item, bool) for item in raw_values):
        raise ValueError(f"{label} values must be non-negative finite numbers")
    try:
        rates = tuple(float(item) for item in raw_values)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} values must be non-negative finite numbers") from exc
    if any(not math.isfinite(rate) or rate < 0 for rate in rates):
        raise ValueError(f"{label} values must be non-negative finite numbers")
    return ModelPricing(*rates)


__all__ = [
    "ModelEndpoint",
    "ModelPricing",
    "ModelRegistry",
    "RegisteredModel",
    "ResolvedModelEndpoints",
    "default_model_registry_path",
    "write_model_registry_template",
]
