"""State machine for streamed online tool completions."""

from __future__ import annotations

import asyncio
import json
import re
from dataclasses import dataclass, field
from typing import Any

from .stream_decode import decoded_chunks
from .stream_types import StreamHandle
from .text_stream import _close_response
from .tool_args import WriteToolArgStreamDecoder, chunked_guard_put, chunked_put
from .utils import get_text_from_content

_THINK_TAG_RE = re.compile(r"</?think>", re.IGNORECASE)


@dataclass
class ToolStreamState:
    content: list[str] = field(default_factory=list)
    reasoning: list[str] = field(default_factory=list)
    slots: dict[int, dict[str, Any]] = field(default_factory=dict)
    finish_reason: str = "unknown"
    usage: Any = None
    input_tokens: int = 0
    output_tokens: int = 0


def tool_slot_ready(slot: dict[str, Any]) -> bool:
    if not slot.get("name") or not slot.get("id"):
        return False
    try:
        raw = (slot.get("arguments") or "").strip()
        if not raw:
            return False
        json.loads(raw)
    except json.JSONDecodeError:
        return False
    return True


def tool_preview_cap(slot: dict[str, Any]) -> int:
    return {"write": 1200, "edit": 2500}.get(str(slot.get("name") or ""), 4000)


def tool_progress_chunks(
    slot: dict[str, Any], cap: int, total_len: int, step: int = 6144
) -> list[str]:
    if slot.get("name") not in ("write", "edit") or total_len <= cap:
        return []
    output: list[str] = []
    milestone = int(slot.get("_arg_stream_next_milestone") or cap + step)
    while total_len >= milestone:
        output.append(f"\n[streaming tool arguments: {total_len} chars received…]\n")
        milestone += step
    slot["_arg_stream_next_milestone"] = milestone
    return output


def estimate_tool_inputs(llm: Any, messages: list[dict[str, Any]], state: ToolStreamState) -> None:
    for message in messages:
        count = llm.estimate_tokens(get_text_from_content(message.get("content") or ""))
        state.input_tokens += count
        llm.token_tracker(count, 0)


def _slot_for_delta(state: ToolStreamState, tool_call: Any) -> tuple[int, dict[str, Any]]:
    index = getattr(tool_call, "index", None)
    if index is None:
        index = max(state.slots.keys(), default=-1) + 1
    slot = state.slots.setdefault(
        index,
        {
            "id": None,
            "name": None,
            "arguments": "",
            "_name_streamed": False,
            "_arg_streamed_len": 0,
        },
    )
    if getattr(tool_call, "id", None):
        slot["id"] = tool_call.id
    return index, slot


async def _render_argument_fragment(
    slot: dict[str, Any], fragment: str, handle: StreamHandle
) -> None:
    if slot.get("name") == "write":
        await WriteToolArgStreamDecoder.feed(slot, handle)
        return
    cap = tool_preview_cap(slot)
    streamed = int(slot.get("_arg_streamed_len", 0))
    if streamed < cap:
        await chunked_put(handle, fragment[: cap - streamed], channel="tool_preview")
    slot["_arg_streamed_len"] = streamed + len(fragment)
    if streamed + len(fragment) > cap and not slot.get("_arg_trunc_notice"):
        slot["_arg_trunc_notice"] = True
        await chunked_put(
            handle,
            "\n… [tool args preview truncated here; full JSON in panel below]\n",
            channel="tool_preview",
        )
    for progress in tool_progress_chunks(slot, cap, len(slot["arguments"])):
        await chunked_put(handle, progress, channel="tool_preview")


async def _consume_tool_calls(
    state: ToolStreamState,
    tool_calls: list[Any],
    handle: StreamHandle,
    collect_all: bool,
) -> None:
    for tool_call in tool_calls:
        index, slot = _slot_for_delta(state, tool_call)
        function = getattr(tool_call, "function", None)
        name = getattr(function, "name", None) if function is not None else None
        if name:
            slot["name"] = name
            if (collect_all or index == 0) and not slot["_name_streamed"]:
                slot["_name_streamed"] = True
                await handle.put(f"\n→ {name}\n", channel="tool_preview")
                await asyncio.sleep(0)
        fragment = getattr(function, "arguments", None) if function is not None else None
        if fragment:
            slot["arguments"] += fragment
            if collect_all or index == 0:
                await _render_argument_fragment(slot, fragment, handle)
        if not collect_all and index == 0 and tool_slot_ready(slot):
            handle.stop()
            break


async def _consume_delta(
    llm: Any,
    state: ToolStreamState,
    delta: Any,
    handle: StreamHandle,
    collect_all: bool,
) -> None:
    reasoning = getattr(delta, "reasoning_content", None)
    if reasoning:
        state.reasoning.append(reasoning)
        await chunked_guard_put(handle, reasoning, channel="reasoning")
        count = llm.estimate_tokens(reasoning)
        state.output_tokens += count
        llm.token_tracker(0, count)
    content = _THINK_TAG_RE.sub("", getattr(delta, "content", None) or "")
    if content:
        state.content.append(content)
        await chunked_put(handle, content)
        count = llm.estimate_tokens(content)
        state.output_tokens += count
        llm.token_tracker(0, count)
    await _consume_tool_calls(state, getattr(delta, "tool_calls", None) or [], handle, collect_all)


async def consume_tool_stream(
    llm: Any,
    response: Any,
    messages: list[dict[str, Any]],
    handle: StreamHandle,
    collect_all: bool,
) -> ToolStreamState:
    state = ToolStreamState()
    estimate_tool_inputs(llm, messages, state)
    try:
        async for chunk in decoded_chunks(response):
            if handle.interrupted:
                state.finish_reason = "interrupted_by_client"
                break
            if getattr(chunk, "usage", None):
                state.usage = chunk.usage
            if not chunk.choices:
                continue
            choice = chunk.choices[0]
            state.finish_reason = getattr(choice, "finish_reason", None) or state.finish_reason
            if choice.delta is not None:
                await _consume_delta(llm, state, choice.delta, handle, collect_all)
            if handle.interrupted:
                state.finish_reason = "interrupted_by_client"
                break
    finally:
        await _close_response(response)
        if not handle.interrupted:
            handle.finish()
    return state
