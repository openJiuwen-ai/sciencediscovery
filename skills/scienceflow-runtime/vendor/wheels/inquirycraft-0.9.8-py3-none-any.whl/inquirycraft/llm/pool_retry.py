"""Retry policy shared by pooled provider clients."""

from __future__ import annotations

import time
from typing import Any

import httpx
from openai import APIError, APITimeoutError, RateLimitError

from inquirycraft.llm.errors import is_missing_reasoning_replay_error
from inquirycraft.llm.online import OnlineLLM

_TRANSIENT_ERRORS = (
    APIError,
    ConnectionError,
    OSError,
    TimeoutError,
    httpx.ReadTimeout,
)


class PoolRetryMixin:
    """Implement endpoint-local retries and whole-pool cooldown waits."""

    async def _soft_retry(
        self,
        method: str,
        llm: OnlineLLM,
        *,
        idx: int,
        failover_count: int,
        initial_error: Exception,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> tuple[Any, Exception | None]:
        error = initial_error
        retries = max(0, self.default_endpoint_attempts - 1)
        for retry_number in range(1, retries + 1):
            delay = self._soft_retry_delay_sec() * retry_number
            self.runtime_logger.warning(
                "[PooledLLM] Key #%d transient error (%s); same-key retry in %.1fs (%d/%d)",
                idx,
                type(error).__name__,
                delay,
                retry_number,
                retries,
            )
            try:
                await self._sleep(delay)
                result = await getattr(llm, method)(*args, **kwargs)
            except RateLimitError as exc:
                self._record_rate_limit(idx, exc, soft_retry=True)
                return None, exc
            except _TRANSIENT_ERRORS as exc:
                error = exc
                continue
            self._record_success(idx, failover_count)
            self.runtime_logger.info("[PooledLLM] Key #%d same-key retry succeeded", idx)
            return result, None
        self._pool.cooldown(idx, self._connection_cooldown_sec)
        self.runtime_logger.warning(
            "[PooledLLM] Key #%d unavailable after %d attempts (%s), trying next...",
            idx,
            self.default_endpoint_attempts,
            type(error).__name__,
        )
        return None, error

    async def _wait_for_rate_limit(
        self,
        error: Exception,
        *,
        deadline: float,
        max_wait: float,
        allowed: set[int],
    ) -> bool:
        if not isinstance(error, RateLimitError):
            return False
        wait = self._pool.seconds_until_earliest_unlock(include=allowed)
        now = time.monotonic()
        slip = min(wait + 0.25, max(0.0, deadline - now))
        if slip <= 0.05 or now + slip > deadline:
            return False
        self.runtime_logger.info(
            "[PooledLLM] All keys rate-limited this pass; waiting %.1fs "
            "for cooldown (budget %.0fs)",
            slip,
            max_wait,
        )
        await self._sleep(slip)
        return True

    @staticmethod
    def _is_retryable_after_pool(error: Exception) -> bool:
        """Return whether a full endpoint pass may recover after cooldown."""
        if isinstance(error, RateLimitError):
            return False
        if isinstance(error, APITimeoutError):
            return True
        status = getattr(error, "status_code", None)
        if isinstance(status, int):
            return status in {408, 409, 425} or status >= 500
        if isinstance(error, (ConnectionError, OSError, TimeoutError, httpx.TimeoutException)):
            return True
        message = str(error).casefold()
        return isinstance(error, APIError) and any(
            marker in message
            for marker in (
                "overload",
                "temporarily unavailable",
                "try again later",
                "retry later",
                "concurrency limit exceeded",
            )
        )

    async def _wait_for_transient_retry(
        self,
        error: Exception,
        *,
        deadline: float,
        retry_number: int,
        allowed: set[int],
    ) -> bool:
        if not self._is_retryable_after_pool(error):
            return False
        now = time.monotonic()
        cooldown_wait = self._pool.seconds_until_earliest_unlock(include=allowed)
        backoff = min(
            self.default_transient_retry_base_delay_sec * (2 ** (retry_number - 1)),
            self.default_transient_retry_max_delay_sec,
        )
        slip = max(cooldown_wait + (0.25 if cooldown_wait else 0.0), backoff)
        remaining = max(0.0, deadline - now)
        if slip > remaining:
            return False
        self.runtime_logger.info(
            "[PooledLLM] All endpoints transiently unavailable; retrying pool in %.1fs (%d/%d)",
            slip,
            retry_number,
            self.default_transient_retry_passes,
        )
        if slip:
            await self._sleep(slip)
        return True

    async def _attempt_endpoint(
        self,
        method: str,
        llm: OnlineLLM,
        *,
        idx: int,
        failover_count: int,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> tuple[bool, Any, Exception | None]:
        try:
            result = await getattr(llm, method)(*args, **kwargs)
        except RateLimitError as exc:
            self._record_rate_limit(idx, exc, soft_retry=False)
            return False, None, exc
        except _TRANSIENT_ERRORS as exc:
            if is_missing_reasoning_replay_error(exc):
                self.runtime_logger.warning(
                    "[PooledLLM] Key #%d returned deterministic reasoning_content "
                    "replay error; deferring to caller for request adaptation",
                    idx,
                )
                raise
            if not self._is_retryable_after_pool(exc):
                return False, None, exc
            result, error = await self._soft_retry(
                method,
                llm,
                idx=idx,
                failover_count=failover_count,
                initial_error=exc,
                args=args,
                kwargs=kwargs,
            )
            return error is None, result, error
        self._record_success(idx, failover_count)
        return True, result, None
