"""Private model registry template and default path for CLI configuration."""

from __future__ import annotations

import json
import os
from pathlib import Path


def write_model_registry_template(path: str | Path) -> Path:
    """Create a private starter registry without overwriting an existing file."""

    target = Path(path).expanduser().resolve(strict=False)
    target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    payload = {
        "version": 1,
        "models": {
            "model-name": {
                "model": "replace-with-model-name",
                "reasoning_replay": "preserve",
                "use_proxy": False,
                "pricing": {
                    "input_usd_per_1m": None,
                    "cached_input_usd_per_1m": None,
                    "output_usd_per_1m": None,
                },
                "endpoints": {
                    "code": [
                        {"url": "https://api.example.com/v1", "key": "replace-with-code-api-key"}
                    ],
                    "feedback": [
                        {
                            "url": "https://api.example.com/v1",
                            "key": "replace-with-feedback-api-key",
                        }
                    ],
                },
            }
        },
        "defaults": {
            "code_models": ["model-name"],
            "feedback_models": ["model-name"],
            "selection": "auto",
        },
    }
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    fd = os.open(target, flags, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, indent=2, ensure_ascii=False)
        stream.write("\n")
    return target


def default_model_registry_path(app_name: str = "inquirycraft") -> Path:
    """Return the XDG-compatible per-user registry path."""

    config_home = Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config")
    return config_home.expanduser() / app_name / "models.json"
