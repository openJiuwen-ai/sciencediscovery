# SPDX-License-Identifier: MIT

"""Text extraction and token-estimation helpers for provider requests."""

from typing import Optional, Union


def count_chars(text: str) -> dict:
    """
    Count the number of Chinese and English characters in a string.

    Args:
        text (str): The input string.

    Returns:
        dict: A dictionary with counts for 'chinese', 'english' & 'symbol' characters.
    """
    chinese_count = sum("\u4e00" <= char <= "\u9fff" for char in text)
    english_count = sum(
        ("a" <= char <= "z") or ("A" <= char <= "Z") for char in text
    )
    symbol_count = len(text) - chinese_count - english_count
    return {"chinese": chinese_count, "english": english_count, "symbol": symbol_count}


def get_text_from_content(content: Union[str, list]) -> str:
    """
    Extract plain text from message content for token estimation.
    Handles OpenAI-style content: str or list of dicts (e.g. {"type": "text", "text": "..."}).

    Args:
        content: Message content (string or list of content parts).

    Returns:
        Concatenated text string.
    """
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for part in content:
            if isinstance(part, dict) and part.get("type") == "text":
                parts.append(part.get("text") or "")
            elif isinstance(part, str):
                parts.append(part)
        return "".join(parts)
    return ""


def estimate_tokens(
    text: str,
    model: Optional[str] = None,
    encoding_name: Optional[str] = None,
    use_tiktoken: bool = True,
    fallback_chinese_ratio: float = 0.6,
    fallback_english_ratio: float = 0.25,
    fallback_symbol_ratio: float = 0.33,
) -> int:
    """
    Estimate token count for a string. Prefers tiktoken when available and model/encoding
    is set (accurate for OpenAI-compatible APIs); otherwise uses an improved heuristic.

    Why heuristic is inaccurate:
    - Different tokenizers (OpenAI/Claude/Gemini/DeepSeek) tokenize differently.
    - English is tokenized by subwords, not by character (e.g. "tokenization" can be 2–3 tokens).
    - Symbols/numbers often merge with adjacent tokens; 1 token per symbol overcounts.

    Args:
        text: Input string to count.
        model: Model name for tiktoken (e.g. "gpt-4", "gpt-3.5-turbo"). Used when encoding_name is None.
        encoding_name: tiktoken encoding name (e.g. "cl100k_base"). Overrides model when set.
        use_tiktoken: If True, use tiktoken when available; else always use heuristic.
        fallback_chinese_ratio: Tokens per Chinese character in fallback (default from DeepSeek doc).
        fallback_english_ratio: Tokens per English character in fallback (~4 chars/token).
        fallback_symbol_ratio: Tokens per symbol in fallback (symbols often merge).

    Returns:
        Estimated token count (int).
    """
    if use_tiktoken and (model or encoding_name):
        try:
            import tiktoken

            if encoding_name:
                enc = tiktoken.get_encoding(encoding_name)
            elif model:
                enc = tiktoken.encoding_for_model(model)
            else:
                enc = None
            if enc is not None:
                return len(enc.encode(text))
        except Exception:
            pass  # fall through to heuristic

    num = count_chars(text)
    return int(
        num["chinese"] * fallback_chinese_ratio
        + num["english"] * fallback_english_ratio
        + num["symbol"] * fallback_symbol_ratio
    )
