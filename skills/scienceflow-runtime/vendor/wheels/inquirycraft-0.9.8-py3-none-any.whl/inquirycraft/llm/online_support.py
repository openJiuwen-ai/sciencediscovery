"""Shared request policy and accounting helpers for online LLM providers."""

from __future__ import annotations

import hashlib
import json
from typing import Any

from .models import Usage
from .stream_types import CallStats


def cached_input_tokens(usage: Any) -> int:
    """Read OpenAI or DeepSeek prefix-cache token fields, tolerating mappings."""
    if usage is None:
        return 0
    try:
        details = getattr(usage, "prompt_tokens_details", None)
        if details is None and isinstance(usage, dict):
            details = usage.get("prompt_tokens_details")
        value = getattr(details, "cached_tokens", None)
        if value is None and isinstance(details, dict):
            value = details.get("cached_tokens")
        if value is None:
            value = getattr(usage, "prompt_cache_hit_tokens", None)
        if value is None and isinstance(usage, dict):
            value = usage.get("prompt_cache_hit_tokens")
        return int(value) if value is not None else 0
    except (TypeError, ValueError):
        return 0


def usage_value(usage: Any, name: str, fallback: int = 0) -> int:
    value = getattr(usage, name, None) if usage is not None else None
    if value is None and isinstance(usage, dict):
        value = usage.get(name)
    return int(value or fallback)


def provider_usage(value: Any) -> Usage:
    """Normalize provider accounting for successful and failed streams."""
    return Usage(
        input_tokens=usage_value(value, "prompt_tokens"),
        output_tokens=usage_value(value, "completion_tokens"),
        cached_input_tokens=cached_input_tokens(value),
    )


def save_nonstream_stats(
    llm: Any,
    response: Any,
    elapsed: float,
    *,
    finish_reason: str | None = None,
) -> None:
    usage = getattr(response, "usage", None)
    input_tokens = usage_value(usage, "prompt_tokens")
    output_tokens = usage_value(usage, "completion_tokens")
    if usage:
        llm.token_tracker(input_tokens, output_tokens)
    choices = getattr(response, "choices", None) or []
    provider_finish = getattr(choices[0], "finish_reason", None) if choices else None
    llm._save_call_stats(
        CallStats(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            ttft=elapsed,
            tpot=elapsed / output_tokens * 1000 if output_tokens > 1 else 0.0,
            finish_reason=finish_reason or provider_finish or "unknown",
            input_cached_tokens=cached_input_tokens(usage),
        )
    )


class RequestPolicyMixin:
    """Provider request fields whose omission is part of the frozen contract."""

    def _add_explicit_top_p(self, create_kwargs: dict[str, Any]) -> None:
        fields_set = getattr(self, "model_fields_set", set())
        if "top_p" in fields_set and self.top_p is not None:
            create_kwargs["top_p"] = self.top_p

    def _add_explicit_request_seed(self, create_kwargs: dict[str, Any]) -> None:
        if self.request_seed is not None and "seed" not in create_kwargs:
            create_kwargs["seed"] = int(self.request_seed)

    def _stable_tool_call_id(
        self,
        messages: list[Any],
        index: int,
        name: str,
        arguments: str,
    ) -> str | None:
        if self.request_seed is None:
            return None
        payload = json.dumps(
            {
                "seed": int(self.request_seed),
                "messages": messages,
                "index": int(index),
                "name": str(name or ""),
                "arguments": str(arguments or ""),
            },
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            default=str,
        ).encode("utf-8")
        return f"gate-tool-{hashlib.sha256(payload).hexdigest()[:24]}"
