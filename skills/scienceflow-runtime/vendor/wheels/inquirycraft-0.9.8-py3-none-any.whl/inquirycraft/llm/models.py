from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, Mapping, Sequence, cast

ReasoningReplayPolicy = Literal["preserve", "required", "omit"]
REASONING_REPLAY_POLICIES = frozenset({"preserve", "required", "omit"})
REASONING_REPLAY_PLACEHOLDER = (
    "Synthetic replay placeholder for thinking-mode resume compatibility."
)


def normalize_reasoning_replay(
    value: Any,
    *,
    default: ReasoningReplayPolicy = "preserve",
) -> ReasoningReplayPolicy:
    normalized = str(value or default).strip().lower()
    if normalized not in REASONING_REPLAY_POLICIES:
        choices = ", ".join(sorted(REASONING_REPLAY_POLICIES))
        raise ValueError(f"reasoning_replay must be one of: {choices}")
    return cast(ReasoningReplayPolicy, normalized)


def choose_reasoning_replay(
    policies: Mapping[str, ReasoningReplayPolicy],
    override: str | None = None,
) -> ReasoningReplayPolicy:
    if override is not None and str(override).strip():
        return normalize_reasoning_replay(override)
    unique = set(policies.values())
    if len(unique) != 1:
        detail = ", ".join(f"{alias}={policy}" for alias, policy in policies.items())
        raise ValueError("Selected model aliases must use one reasoning_replay policy: " + detail)
    return next(iter(unique))


def project_reasoning_messages(
    messages: Sequence[Mapping[str, Any]],
    policy: ReasoningReplayPolicy | str,
) -> tuple[Mapping[str, Any], ...]:
    selected = normalize_reasoning_replay(policy)
    projected: list[Mapping[str, Any]] = []
    for message in messages:
        row = dict(message)
        if row.get("role") == "assistant":
            if selected == "omit":
                row.pop("reasoning_content", None)
            elif selected == "required" and not str(row.get("reasoning_content") or "").strip():
                row["reasoning_content"] = REASONING_REPLAY_PLACEHOLDER
        projected.append(row)
    return tuple(projected)


@dataclass(frozen=True, slots=True)
class Usage:
    input_tokens: int = 0
    output_tokens: int = 0
    cached_input_tokens: int = 0


@dataclass(frozen=True, slots=True)
class CompletionRequest:
    messages: tuple[Mapping[str, Any], ...]
    model: str
    tools: tuple[Mapping[str, Any], ...] = field(default_factory=tuple)
    tool_choice: str | Mapping[str, Any] | None = "auto"
    temperature: float | None = None
    max_tokens: int | None = None
    timeout: float | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class CompletionResult:
    content: str = ""
    reasoning_content: str = ""
    tool_calls: tuple[Mapping[str, Any], ...] = field(default_factory=tuple)
    finish_reason: str = "unknown"
    usage: Usage = field(default_factory=Usage)
    raw: Any = field(default=None, repr=False, compare=False)
    pool_index: int | None = None


@dataclass(frozen=True, slots=True)
class StreamChunk:
    content: str = ""
    reasoning_content: str = ""
    tool_call_delta: Mapping[str, Any] | None = None
    finish_reason: str | None = None
    usage: Usage | None = None
    tool_call_preview: str = ""
    pool_index: int | None = None
