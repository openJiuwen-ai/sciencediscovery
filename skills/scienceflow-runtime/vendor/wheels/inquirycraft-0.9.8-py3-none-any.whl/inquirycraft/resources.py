from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

_NAME = re.compile(r"^[a-z0-9][a-z0-9_-]{0,63}$")
_VARIABLE = re.compile(r"\{\{\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*\}\}")


@dataclass(frozen=True, slots=True)
class ResourceDiagnostic:
    path: Path
    message: str


@dataclass(frozen=True, slots=True)
class SkillResource:
    name: str
    description: str
    path: Path

    def read(self) -> str:
        _, body = _frontmatter(self.path)
        return body


@dataclass(frozen=True, slots=True)
class PromptTemplate:
    name: str
    description: str
    body: str
    path: Path

    def render(self, arguments: Mapping[str, object]) -> str:
        missing = sorted(set(_VARIABLE.findall(self.body)) - set(arguments))
        if missing:
            raise ValueError(f"Missing template argument(s): {', '.join(missing)}")
        return _VARIABLE.sub(lambda match: str(arguments[match.group(1)]), self.body)


class ResourceTrustStore:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)

    def _values(self) -> set[str]:
        if not self.path.exists():
            return set()
        value = json.loads(self.path.read_text(encoding="utf-8"))
        return {str(Path(item).resolve()) for item in value.get("trusted_roots", [])}

    def trust(self, root: str | Path) -> None:
        values = self._values()
        values.add(str(Path(root).resolve()))
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(
            json.dumps({"trusted_roots": sorted(values)}, indent=2) + "\n",
            encoding="utf-8",
        )

    def is_trusted(self, root: str | Path) -> bool:
        return str(Path(root).resolve()) in self._values()


class ResourceLoader:
    """Discover declarative Markdown resources without importing project code."""

    def __init__(
        self,
        *,
        roots: tuple[str | Path, ...],
        trust_store: ResourceTrustStore | None = None,
        require_trust: bool = True,
    ) -> None:
        self.roots = tuple(Path(root).resolve() for root in roots)
        self.trust_store = trust_store
        self.require_trust = require_trust
        self.diagnostics: list[ResourceDiagnostic] = []

    def skills(self) -> tuple[SkillResource, ...]:
        resources: dict[str, SkillResource] = {}
        for root in self._allowed_roots():
            for path in sorted(root.glob("**/SKILL.md")):
                try:
                    self._ensure_contained(path, root)
                    metadata, _ = _frontmatter(path)
                    name, description = _identity(metadata, path)
                    resources[name] = SkillResource(name, description, path)
                except ValueError as exc:
                    self.diagnostics.append(ResourceDiagnostic(path, str(exc)))
        return tuple(resources.values())

    def templates(self) -> tuple[PromptTemplate, ...]:
        resources: dict[str, PromptTemplate] = {}
        for root in self._allowed_roots():
            for path in sorted(root.glob("**/*.prompt.md")):
                try:
                    self._ensure_contained(path, root)
                    metadata, body = _frontmatter(path)
                    name, description = _identity(metadata, path)
                    resources[name] = PromptTemplate(name, description, body, path)
                except ValueError as exc:
                    self.diagnostics.append(ResourceDiagnostic(path, str(exc)))
        return tuple(resources.values())

    def skill_catalog(self) -> str:
        return "\n".join(f"- {skill.name}: {skill.description}" for skill in self.skills())

    def _allowed_roots(self) -> tuple[Path, ...]:
        allowed = []
        for root in self.roots:
            if not self.require_trust or (
                self.trust_store is not None and self.trust_store.is_trusted(root)
            ):
                allowed.append(root)
            else:
                self.diagnostics.append(ResourceDiagnostic(root, "resource root is not trusted"))
        return tuple(allowed)

    @staticmethod
    def _ensure_contained(path: Path, root: Path) -> None:
        if not path.resolve().is_relative_to(root):
            raise ValueError("Resource symlink escapes its trusted root")


def _frontmatter(path: Path) -> tuple[dict[str, str], str]:
    text = path.read_text(encoding="utf-8")
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        raise ValueError("Markdown resource requires frontmatter")
    try:
        end = next(index for index, line in enumerate(lines[1:], start=1) if line.strip() == "---")
    except StopIteration as exc:
        raise ValueError("Markdown resource has unterminated frontmatter") from exc
    metadata: dict[str, str] = {}
    for line in lines[1:end]:
        if not line.strip():
            continue
        key, separator, value = line.partition(":")
        if not separator or not key.strip():
            raise ValueError(f"Invalid frontmatter line: {line!r}")
        metadata[key.strip()] = value.strip().strip("\"'")
    return metadata, "\n".join(lines[end + 1 :]).strip()


def _identity(metadata: Mapping[str, str], path: Path) -> tuple[str, str]:
    name = metadata.get("name", "")
    description = metadata.get("description", "")
    if not _NAME.fullmatch(name):
        raise ValueError(f"Invalid resource name: {name!r}")
    if not description:
        raise ValueError("Resource description is required")
    return name, description
