"""Optional Model Context Protocol integration.

Import this namespace only when ``inquirycraft[mcp]`` is installed.
"""

from .client import MCPClient, MCPRemoteTool

__all__ = ["MCPClient", "MCPRemoteTool"]
