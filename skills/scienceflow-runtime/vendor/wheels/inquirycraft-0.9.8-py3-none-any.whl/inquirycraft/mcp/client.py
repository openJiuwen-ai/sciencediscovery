from __future__ import annotations

import shutil
from contextlib import AsyncExitStack
from typing import Any, Mapping, Sequence

from inquirycraft.tools import BaseTool, ToolCollection, ToolContext, ToolResult

try:
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.sse import sse_client
    from mcp.client.stdio import stdio_client
    from mcp.types import TextContent
except ImportError as exc:  # pragma: no cover - exercised in minimal-wheel smoke
    raise ImportError("MCP support requires `pip install inquirycraft[mcp]`") from exc


class MCPRemoteTool(BaseTool):
    """Expose one remote MCP tool through InquiryCraft's normal tool contract."""

    def __init__(
        self,
        *,
        session: ClientSession,
        name: str,
        description: str,
        input_schema: Mapping[str, Any],
    ) -> None:
        self.session = session
        self.name = name
        self.description = description
        self.input_schema = dict(input_schema)

    async def execute(self, arguments: Mapping[str, Any], context: ToolContext) -> ToolResult:
        context.cancellation.raise_if_cancelled()
        try:
            result = await self.session.call_tool(self.name, dict(arguments))
        except Exception as exc:
            return ToolResult(error=f"MCP {type(exc).__name__}: {exc}")
        text = "\n".join(item.text for item in result.content if isinstance(item, TextContent))
        return ToolResult(
            output=text or "No text output returned.",
            metadata={"mcp_tool": self.name, "is_error": bool(getattr(result, "isError", False))},
        )


class MCPClient:
    """Own MCP transport lifetime and a discovered InquiryCraft ToolCollection."""

    def __init__(self, name: str = "mcp") -> None:
        self.name = name
        self.session: ClientSession | None = None
        self.tools = ToolCollection()
        self._stack = AsyncExitStack()
        self._entered = False

    async def _enter(self) -> None:
        if not self._entered:
            await self._stack.__aenter__()
            self._entered = True

    async def connect_stdio(
        self,
        command: str,
        args: Sequence[str] = (),
        env: Mapping[str, str] | None = None,
    ) -> ToolCollection:
        await self._enter()
        resolved = shutil.which("npx") if command == "npx" else command
        if not resolved:
            raise ValueError("MCP server command is required")
        params = StdioServerParameters(command=resolved, args=list(args), env=dict(env or {}))
        read, write = await self._stack.enter_async_context(stdio_client(params))
        self.session = await self._stack.enter_async_context(ClientSession(read, write))
        return await self.refresh_tools()

    async def connect_sse(self, server_url: str) -> ToolCollection:
        await self._enter()
        if not str(server_url or "").strip():
            raise ValueError("MCP server URL is required")
        streams = await self._stack.enter_async_context(sse_client(url=server_url))
        self.session = await self._stack.enter_async_context(ClientSession(*streams))
        return await self.refresh_tools()

    async def refresh_tools(self) -> ToolCollection:
        if self.session is None:
            raise RuntimeError("MCP client is not connected")
        await self.session.initialize()
        response = await self.session.list_tools()
        collection = ToolCollection()
        for remote in response.tools:
            collection.register(
                MCPRemoteTool(
                    session=self.session,
                    name=str(remote.name),
                    description=str(remote.description or ""),
                    input_schema=dict(remote.inputSchema or {}),
                )
            )
        self.tools = collection
        return collection

    async def aclose(self) -> None:
        self.session = None
        self.tools = ToolCollection()
        if self._entered:
            self._entered = False
            await self._stack.aclose()

    async def __aenter__(self) -> "MCPClient":
        await self._enter()
        return self

    async def __aexit__(self, *exc_info: Any) -> None:
        await self.aclose()
