"""InquiryCraft's lightweight, domain-independent agent runtime.

Every public symbol is resolved lazily. Importing the package does not initialize
the runtime, CLI, or provider adapters.
"""

from importlib import import_module
from importlib.metadata import PackageNotFoundError, version
from typing import Any

try:
    __version__ = version("inquirycraft")
except PackageNotFoundError:  # source checkout without an installed distribution
    __version__ = "0+unknown"

_EXPORTS = {
    "AgentHooks": ("inquirycraft.runtime", "AgentHooks"),
    "AgentRuntime": ("inquirycraft.runtime", "AgentRuntime"),
    "BaseTool": ("inquirycraft.tools", "BaseTool"),
    "CompletionRequest": ("inquirycraft.llm", "CompletionRequest"),
    "CompletionResult": ("inquirycraft.llm", "CompletionResult"),
    "CompositeEventSink": ("inquirycraft.events", "CompositeEventSink"),
    "CompactionPolicy": ("inquirycraft.runtime", "CompactionPolicy"),
    "Conversation": ("inquirycraft.memory", "Conversation"),
    "EventSink": ("inquirycraft.events", "EventSink"),
    "JsonlEventSink": ("inquirycraft.events", "JsonlEventSink"),
    "LLMClient": ("inquirycraft.llm", "LLMClient"),
    "Message": ("inquirycraft.memory", "Message"),
    "RecordingLLMClient": ("inquirycraft.events", "RecordingLLMClient"),
    "ReplayLLMClient": ("inquirycraft.events", "ReplayLLMClient"),
    "ResourceLoader": ("inquirycraft.resources", "ResourceLoader"),
    "ResourceTrustStore": ("inquirycraft.resources", "ResourceTrustStore"),
    "ResumeState": ("inquirycraft.runtime", "ResumeState"),
    "RuntimeContext": ("inquirycraft.runtime", "RuntimeContext"),
    "RuntimeEvent": ("inquirycraft.events", "RuntimeEvent"),
    "RuntimeOptions": ("inquirycraft.runtime", "RuntimeOptions"),
    "ToolCollection": ("inquirycraft.tools", "ToolCollection"),
    "ToolContext": ("inquirycraft.tools", "ToolContext"),
    "ToolOutputPolicy": ("inquirycraft.tools", "ToolOutputPolicy"),
    "ToolResult": ("inquirycraft.tools", "ToolResult"),
    "Usage": ("inquirycraft.llm", "Usage"),
}

__all__ = ["__version__", *_EXPORTS]


def __getattr__(name: str) -> Any:
    if name not in _EXPORTS:
        raise AttributeError(name)
    module_name, attribute = _EXPORTS[name]
    value = getattr(import_module(module_name), attribute)
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    return sorted(set(globals()) | set(__all__))
