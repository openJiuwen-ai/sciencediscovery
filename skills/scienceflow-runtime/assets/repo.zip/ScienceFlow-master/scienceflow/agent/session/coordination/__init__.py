"""Internal responsibility package."""
