"""Resource lease callbacks."""
