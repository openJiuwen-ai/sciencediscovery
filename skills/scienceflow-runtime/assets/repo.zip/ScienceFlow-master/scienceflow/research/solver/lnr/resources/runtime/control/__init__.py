"""Resource-runtime control policy."""
