"""Resource admission decisions."""
