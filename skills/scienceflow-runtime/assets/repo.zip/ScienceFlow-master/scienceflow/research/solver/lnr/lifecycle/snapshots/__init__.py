"""Recoverable workspace snapshots."""
