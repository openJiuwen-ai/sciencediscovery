"""Resource sharing decisions."""
